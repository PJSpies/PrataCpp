/*
 * pairs.cpp
 *
 *  Created on: 20.05.2024
 *      Author: peter
 */
#include <iostream>
#include <string>
//#include <valarray>

//@formatter:off
template<class T1, class T2>
  class Pair
  {
  private:
	T1 a;
	T2 b;
  public:
	T1& first();
	T2& second();
//	T1 first() const {return a;}
//	T2 second() const { return b; }
	Pair(const T1 &aval, const T2 &bval) : a(aval), b(bval)	{	}
	Pair(){  }
	~Pair(){  }
  };

//  Pair's 2 methods :
template<class T1, class T2>
  T1& Pair<T1, T2>::first() {return a;}

template<class T1, class T2>
  T2& Pair<T1, T2>::second() {return b;}

int main()
{
  using std::string;
  Pair<string, int> couple[3] =
  {
	  Pair<string, int>("text 1 - ", 1),
	  Pair<string, int>("text 2 - ", 2),
	  Pair<string, int>("text 3 - ", 3)
  };

  Pair<int, int> IntPair {1, 1};

  std::cout << " TEXT\t  number\n";
  for (int i = 0; i < 3; i++)
  {
	std::cout << couple[i].first() << " " << couple[i].second() << "\n";
  }
  return 0;
}
//@formatter:on

