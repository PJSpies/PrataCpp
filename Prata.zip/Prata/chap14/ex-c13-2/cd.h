/*
 * cd.h
 *
 *  Created on: 26.03.2024
 *      Author: peter
 */

#ifndef CD_H_
#define CD_H_
#include <iostream>
//base class
class Cd
{
private:
  char *performers;  //  performers[50];
  char *label; // label[20];
  int selections;
  double playtime;
public:
  Cd();  // default
  virtual ~Cd();
  Cd(const char *s1, const char *s2, int n, double x);
  Cd(const Cd &d);  // copy constructor
  virtual void Report() const
  {
	std::cout << performers << " , " << label << " , " << selections << " : " << playtime << std::endl;
  }
  Cd& operator=(const Cd &d);  // assignment operator Cd
};

#endif /* CD_H_ */
