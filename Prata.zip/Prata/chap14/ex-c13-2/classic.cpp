/*
 * classic.cpp
 *
 *  Created on: 26.03.2024
 *      Author: peter
 */
#include "classic.h"  //  includes "cd.h"
#include <cstring>

Cd::Cd(const Cd &c)  //  copy constructor for Cd
{
  performers = new char[std::strlen(c.performers) + 1];
  std::strcpy(performers, c.performers);
  label = new char[std::strlen(c.label) + 1];
  std::strcpy(label, c.label);
  selections = c.selections;
  playtime = c.playtime;
}

Cd::Cd()
{
  performers = nullptr;
  label = nullptr;
  playtime = 0.;
  selections = 0;
}
Cd::Cd(const char *s1, const char *s2, int n, double x)
{
  performers = new char[std::strlen(s1) + 1];
  std::strcpy(performers, s1);
  label = new char[std::strlen(s2) + 1];
  std::strcpy(label, s2);
  selections = n;
  playtime = x;
}
Cd& Cd::operator=(const Cd &c)
{
  if (this == &c) return *this;

  delete[] performers;
  performers = new char[std::strlen(c.performers) + 1];
  std::strcpy(performers, c.performers);

  delete[] label;
  label = new char[std::strlen(c.label) + 1];
  std::strcpy(label, c.label);

  selections = c.selections;
  playtime = c.playtime;
  return *this;
}

Cd::~Cd()
{
  delete[] performers;
  delete[] label;
}
Classic::Classic()
{
  primary = nullptr;
}
Classic::~Classic()
{
  delete[] primary;
}

Classic::Classic(const char *p, const char *s1, const char *s2, int n, double x) : Cd(s1, s2, n, x)
{
  primary = new char[std::strlen(p) + 1];
  std::strcpy(primary, p);
}

Classic::Classic(const char *p, const Cd &c) : Cd(c)
{
  primary = new char[std::strlen(p) + 1];
  std::strcpy(primary, p);
}
Classic::Classic(const Classic &c)
{
  primary = new char[std::strlen(c.primary) + 1];
  std::strcpy(primary, c.primary);
}

void Classic::Report() const
{
  std::cout << primary << " , "; //
  Cd::Report();
  std::cout << std::endl;
}

Classic& Classic::operator=(const Classic &c)  // uses assignment op of Cd.
{
  Cd::operator =(c);
  delete[] primary;
  primary = new char[std::strlen(c.primary) + 1];
  std::strcpy(primary, c.primary);
  return *this;
}
