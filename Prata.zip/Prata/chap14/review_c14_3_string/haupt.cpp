/*
 * haupt.cpp
 *
 *  Created on: 05.05.2024
 *      Author: peter
 */

#include <iostream>
#include <string>
class Frabjous
{
private:
  std::string fstr;

public:    //@formatter:off
  Frabjous(const std::string str = "Default F string") :	fstr(str)  {  };
  void tell()  { std::cout << " Frab's string:" << fstr << "\n";  };

};

class Gloam : private Frabjous
{
private:
    int gli ;
public :
    Gloam (int g = 0 , std::string s = "Gloam default ");
    Gloam (int g , const Frabjous& f);
    void tell();
};

Gloam::Gloam(int g, std::string s) : Frabjous(s), gli(g) {}      //initialise base class Frabjous through constructor for Gloam
Gloam::Gloam(int g, const Frabjous& f) : Frabjous(f), gli(g) {}  //...first initialise base class then derivate

void Gloam::tell()
{
  std::cout << " Gloam's Frabjous string: ";
  Frabjous::tell();  // base class scope resolved
  std::cout << " Gloam's integer: " << gli << std::endl;
}

//@formatter:on

int main()
{
  Frabjous f;
  f.tell();
  Gloam g;
  g.tell();
  Gloam gl(2, "initialised in Gloam");
  gl.tell();
  return 0;
}

