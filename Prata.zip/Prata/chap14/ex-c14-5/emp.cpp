/*
 * emp.cpp
 *
 *  Created on: 03.06.2024
 *      Author: peter
 */

#include <iostream>
#include "emp.h"
//@formatter:off

/*   abstract employee  methods  */

abstr_emp::abstr_emp(){}
//abstr_emp::abstr_emp() : fname(""), lname(""), job("") {}
abstr_emp::~abstr_emp(){}
abstr_emp::abstr_emp(const std::string &fn, const std::string &ln, const std::string &j)
  : fname(fn), lname(ln), job(j) { }

void abstr_emp::Set()
{
  std::cout << "\nNew entry!" << std::endl;

  std::cout << "Enter first name: ";
  getline(std::cin, fname);
  std::cout << "Enter last name : ";
  getline(std::cin, lname);
  std::cout << "Enter job title : ";
  getline(std::cin, job);
}

void abstr_emp::ShowAll() const
{
  std::cout << "Last name: " << lname << "\nFirst name: " << fname << "\nJob: " << job << std::endl;
}

std::ostream& operator<<(std::ostream &os, const abstr_emp &e)
{
  os << "\n"<< e.fname << " " << e.lname << " works as " << e.job << ".";
  return os;
}

/*   employee  methods  */

employee::employee() { }

employee::employee(const std::string &fn, const std::string &ln, const std::string &j)
  : abstr_emp(fn,ln,j) {}

void employee::ShowAll() const
{
  abstr_emp::ShowAll();
}
void employee::SetAll()
{
  abstr_emp::Set();
}

/*   manager methods  */

manager::manager()
  : abstr_emp() {inchargeof =0; }
manager::manager(const std::string &fn, const std::string &ln, const std::string &j, int ico )
  : abstr_emp(fn,ln,j), inchargeof(ico)  {}

// copy constructor
manager::manager(const manager & m) : abstr_emp(m)
  {inchargeof = m.InChargeOf();}

void manager::Show() const
{
  std::cout << "leading " << InChargeOf() << " people."<< std::endl;
}

void manager::ShowAll() const
{
  abstr_emp::ShowAll();
  Show();
}

void manager::SetAll()
{
  abstr_emp::Set();
  std::cout << "Enter No. of reports: ";
  std::cin >>  InChargeOf();
}

/*   fink methods  */

fink::fink()
  : abstr_emp() {ReportsTo()=""; }

fink::fink(const std::string &fn, const std::string &ln, const std::string &j, const std::string & rpo)
  : abstr_emp(fn, ln, j), reportsto(rpo)  { }

fink::fink(const abstr_emp & e, const std::string & rpo)
  : abstr_emp(e), reportsto(rpo) { }

fink::fink(const fink & f) : abstr_emp(f)  //  copy constructor
{   reportsto= f.ReportsTo(); }

void fink::Show() const
{
  std::cout << "reporting to " << ReportsTo() << "."<< std::endl;
}

void fink::ShowAll() const
{
  abstr_emp::ShowAll();
  Show();
}

void fink::SetAll()
{
  abstr_emp::Set();

  std::cout << "Enter line manager: ";
  getline(std::cin, reportsto);
}

/*   highfink methods  */

highfink::highfink():abstr_emp(), manager(), fink() {}

highfink::highfink(const std::string &fn, const std::string &ln, const std::string &j, const std::string & rpo, int ico)
  : abstr_emp(fn, ln, j), manager(fn, ln, j, ico), fink(fn, ln, j, rpo) { }

highfink::highfink(const manager & m, const std::string & rpo)
  : abstr_emp(m), manager(m), fink(m, rpo) { }

highfink::highfink(const fink & f, int ico)
  : abstr_emp(f) , fink(f) {}    // not needed: { InChargeOf() = ico ;}

//  copy constructor:
highfink::highfink(const highfink & h)
   : abstr_emp(h),manager(h),fink(h) { }

void highfink::Show() const
{
  manager::Show();
  fink::Show();
}
void highfink::ShowAll() const
{
  abstr_emp::ShowAll();
  Show();
}

void highfink::SetAll()
{
  abstr_emp::Set();

  std::cout << "Enter line manager: ";
  getline(std::cin, ReportsTo());

  std::cout << "Enter No. of reports: ";
  std::cin >> InChargeOf();

}
//@formatter:on
