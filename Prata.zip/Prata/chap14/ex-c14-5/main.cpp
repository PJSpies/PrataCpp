/*
 * main.cpp
 *
 *  Created on: 03.06.2024
 *      Author: peter
 */

#include <iostream>
using namespace std;
#include "emp.h"

int main()
{
//  /*
  employee em("Trip", "Harris", "Thumper");
  cout << em << endl;
//  em.ShowAll();

  manager ma("Amorphia", "Spindragon", "Nuancer", 5);
  cout << ma << endl;
//  ma.ShowAll();

  fink fi("Matt", "Oggs", "Oiler", "Juno Barr");
  cout << fi << endl;
//  fi.ShowAll();

  highfink hf("Hai", "Fink", "Gofor", "Brat Bean", 6);
  cout << hf << endl;
//  hf.ShowAll();

  std::cout << "\ntesting copy constructor for fink() \n";
  fink fi2(fi);
  cout << fi2 << endl;
  fi2.ShowAll();

  std::cout << "\ntesting copy constructor for manager() \n";
  manager ma2(ma);
  cout << ma2 << endl;
  ma2.ShowAll();

  std::cout << "\ntesting copy constructor for employee() \n";
  employee em2(em);
  cout << em2 << endl;
  em2.ShowAll();

  std::cout << "\ntesting copy constructor for highfink() \n";
//  highfink hf2(hf);
  highfink hf2 = hf;    //  implicit generation of 'hf2' through its copy constructor... as above with initialisation
  cout << hf2 << endl;
  hf2.ShowAll();

  std::cout << "\nusing pointer to abstr_emp\n";
  abstr_emp *tri[4] = {&em, &ma, &fi, &hf};
  for (int i = 0; i < 4; i++)
  {
	std::cout << std::endl;
	tri[i]->ShowAll();
  }

  /*  Interactive part  */

  employee e;
  e.SetAll();
  e.ShowAll();

  manager m;
  m.SetAll();
  m.ShowAll();

  fink f;
  f.SetAll();
  f.ShowAll();

  highfink h;
  h.SetAll();
  h.ShowAll();

  std::cout << "\n*** Program ends. **** " << std::endl;
  return 0;
}
