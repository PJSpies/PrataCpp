/*
 * main.cpp
 *
 *  Created on: 26.03.2024
 *      Author: peter
 */

#include <iostream>
#include "classic.h"

void Bravo(const Cd &disk);

int main()
{
  Cd c1("Beatles", "Capitol", 14, 35.5);
  Classic c2 = Classic("Piano Sonata in B flat, Fantasia in C", "Alfred Brendel", "Philips", 2, 57.17);

  c1.Report();  // use base class method
  c2.Report();  // use Classic method (derived)

  std::cout << "testing assignment Cd: ";
  Cd c3;
  c3 = c1;
  c3.Report();

  std::cout << " using type cd * pointer to objects:\n";
  Cd *pcd = &c1;
  pcd->Report();  //  use Cd method for CD object
  pcd = &c2;
  pcd->Report();  //  use Classic method for Classic object

  std::cout << " calling a function with a Cd reference argument:\n";
  Bravo(c1);
  Bravo(c2);

  std::cout << "testing assignment Classic: ";
  Classic copy;
  copy = c2;
  copy.Report();

  return 0;
}

void Bravo(const Cd &disk)
{
  disk.Report();
}
