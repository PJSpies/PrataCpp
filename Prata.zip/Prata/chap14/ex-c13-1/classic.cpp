/*
 * classic.cpp
 *
 *  Created on: 26.03.2024
 *      Author: peter
 */
#include "classic.h"  //  includes "cd.h"
#include <cstring>

Cd::Cd(const Cd &c)  //  copy constructor for Cd
{
  std::strncpy(performers, c.performers, 49);
  performers[49] = '\0';
  std::strncpy(label, c.label, 19);
  label[19] = '\0';
  selections = c.selections;
  playtime = c.playtime;
}

Cd::Cd()
{
  performers[0] = '\0';
  label[0] = '\0';
  playtime = 0.;
  selections = 0;
}
Cd::Cd(const char *s1, const char *s2, int n, double x)
{
  std::strncpy(performers, s1, 49);
  performers[49] = '\0';
  std::strncpy(label, s2, 19);
  label[19] = '\0';
  selections = n;
  playtime = x;
}
Cd& Cd::operator=(const Cd &c)
{
  std::strncpy(performers, c.performers, 49);
  performers[49] = '\0';
  std::strncpy(label, c.label, 19);
  label[19] = '\0';
  selections = c.selections;
  playtime = c.playtime;
  return *this;
}

Cd::~Cd()
{
}
Classic::Classic()
{
}
Classic::~Classic()
{
}

Classic::Classic(const char *p, const char *s1, const char *s2, int n, double x) : Cd(s1, s2, n, x)
{
  std::strncpy(primary, p, 39);
  primary[39] = '\0';
}

Classic::Classic(const char *p, const Cd &c) : Cd(c)
{
  std::strncpy(primary, p, 39);
  primary[39] = '\0';
}
Classic::Classic(const Classic &c)
{
  std::strncpy(primary, c.primary, 39);
  primary[39] = '\0';
}

void Classic::Report() const
{
  std::cout << primary << " , "; //
  Cd::Report();
  std::cout << std::endl;
}

Classic& Classic::operator=(const Classic &c)  // uses assignment op of Cd.
{
  Cd::operator =(c);
  std::strncpy(primary, c.primary, 39);
  primary[39] = '\0';
  return *this;
}
