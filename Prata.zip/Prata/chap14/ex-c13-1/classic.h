/*
 * classic.h
 *
 *  Created on: 26.03.2024
 *      Author: peter
 */

#ifndef CLASSIC_H_
#define CLASSIC_H_
#include "cd.h"
#include <iostream>

class Classic : public Cd
{
private:
  char primary[40];
public:
  Classic();
  ~Classic();

  Classic(const Classic &c);    // copy constructor

  Classic(const char *p, const char *s1, const char *s2, int n, double x);  // add the 'primary'
  Classic(const char *p, const Cd &c);  //  uses implicit copy constructor for Classic

  Classic& operator=(const Classic &c);  // assignment Classic

  void Report() const;
};
#endif /* CLASSIC_H_ */
