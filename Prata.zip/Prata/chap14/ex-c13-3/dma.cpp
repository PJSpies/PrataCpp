/*
 * dma.cpp
 *
 *  Created on: 24.03.2024
 *      Author: peter
 */

#include "dma.h"
#include <cstring>
//  ABC methods;
ABC::ABC(const char *t)
{
  text = new char[std::strlen(t) + 1];
  std::strcpy(text, t);
}

ABC::~ABC()
{
  delete text;
}
ABC::ABC(const ABC &abc)
{
  text = new char[std::strlen(abc.text) + 1];
  std::strcpy(text, abc.text);
}
std::ostream& operator<<(std::ostream &os, const ABC &abc)
{
  os << abc.text;
  return os;
}

// baseDMA methods
baseDMA::baseDMA(const char *l, int r) : ABC(l), rating(r)
{
}
baseDMA::baseDMA(const baseDMA &rs) : ABC(rs)
{
  rating = rs.rating;
}
baseDMA::~baseDMA()
{
}
void baseDMA::View()
{
//  std::cout << "<< in baseDMA View() Label: " <<  // std::endl;
//	  (const ABC&) *this;
  std::cout << *this;
//  std::cout << "  rating " << rating << "\n" << std::endl;
}

baseDMA& baseDMA::operator=(const baseDMA &rs)
{
  if (this == &rs) return *this;
  ABC::operator=(rs); // copy base portion
  rating = rs.rating;
  return *this;
}
std::ostream& operator<<(std::ostream &os, const baseDMA &rs)
{
  os << "Label: " << (const ABC&) rs << "  Rating: " << rs.rating; //<< std::endl;
  return os;
}

// lacksDMA methods
lacksDMA::lacksDMA(const char *c, const char *l, int r) : baseDMA(l, r)
{
  std::strncpy(color, c, COL_LEN - 1);
  color[COL_LEN - 1] = '\0';
}

lacksDMA::lacksDMA(const char *c, const baseDMA &rs) : baseDMA(rs)
{
  std::strncpy(color, c, COL_LEN - 1);
  color[COL_LEN - 1] = '\0';
}

lacksDMA::lacksDMA(const lacksDMA &rs) : baseDMA(rs)
{
  std::strncpy(color, rs.color, COL_LEN - 1);
  color[COL_LEN - 1] = '\0';
}

lacksDMA::~lacksDMA()
{
}

std::ostream& operator<<(std::ostream &os, const lacksDMA &ls)
{
  os << (const baseDMA&) ls;
  os << "Color: " << ls.color << std::endl;
  return os;
}
void lacksDMA::View()
{
  std::cout << "# lacksDMA item # " << (const baseDMA&) *this << " color: " << color << std::endl;
}

// hasDMA methods
hasDMA::hasDMA(const char *s, const char *l, int r) : baseDMA(l, r)
{
  style = new char[std::strlen(s) + 1];
  std::strcpy(style, s);
}

hasDMA::hasDMA(const char *s, const baseDMA &rs) : baseDMA(rs)
{
  style = new char[std::strlen(s) + 1];
  std::strcpy(style, s);
}
hasDMA::hasDMA(const hasDMA &hs) : baseDMA(hs) // invoke base class copy constructor
{
  style = new char[std::strlen(hs.style) + 1];
  std::strcpy(style, hs.style);
}
hasDMA::~hasDMA()
{
  delete style;
}
hasDMA& hasDMA::operator=(const hasDMA &hs)
{
  if (this == &hs) return *this;
  baseDMA::operator=(hs); // copy base portion
  style = new char[std::strlen(hs.style) + 1];
  std::strcpy(style, hs.style);
  return *this;
}
std::ostream& operator<<(std::ostream &os, const hasDMA &hs)
{
  os << (const baseDMA&) hs;
  os << "Style: " << hs.style << std::endl;
  return os;
}
void hasDMA::View()
{
  std::cout << "* hasDMA item * " << (const baseDMA&) *this << " style: " << style << std::endl;
}
