/*
 * usedma.cpp
 *
 *  Created on: 24.03.2024
 *      Author: peter
 */
#include <iostream>
#include "dma.h"

int main()
{
  using std::cout;
  using std::endl;

  baseDMA shirt("Portabelly", 8);
  /*
   baseDMA b;
   b.View();
   b=shirt;
   */
  lacksDMA balloon("red", "Blimpo", 4);
  /*
   lacksDMA l;
   l=balloon;
   l.View();
   */
  hasDMA map("Mercator", "Buffalo Keys", 5);
  /*
   hasDMA h;
   h.View();
   h = map;
   */
  const int LIM {3};
  ABC *p_abc[LIM];

  /*   test pointer array w/o loop  */
//  /*
  p_abc[0] = &shirt;
  p_abc[1] = &balloon;
  p_abc[2] = &map;
//   */
  /*
   char kind;
   for (int i {0}; i < LIM; i++)
   {
   std::cout << " enter type to create: (1) for BaseDMA, (2) for LacksDMA, (3) for hasDMA:";
   while (std::cin >> kind && (kind != '1' && kind != '2' && kind != '3'))
   std::cout << "enter 1, 2, or 3!";
   if (kind == '1')
   {
   std::cout << "Enter BaseDMA label: " << std::endl;
   char temp[10];
   std::cin >> temp;
   std::cout << "enter rating: " << std::endl;
   int rat;
   std::cin >> rat;
   baseDMA b(temp, rat);
   p_abc[i] = &b;  // &shirt;
   }
   else if (kind == '2')
   {
   std::cout << "Enter LacksDMA label: " << std::endl;
   char temp[10];
   std::cin >> temp;
   std::cout << "Enter LacksDMA color: " << std::endl;
   char col[10];
   std::cin >> col;
   std::cout << "enter rating: " << std::endl;
   int rat;
   std::cin >> rat;
   lacksDMA c(col, temp, rat);
   p_abc[i] = &c;  // &balloon;
   }
   else if (kind == '3')
   {
   std::cout << "Enter hasDMA label: " << std::endl;
   char temp[10];
   std::cin >> temp;
   std::cout << "Enter hasDMA style: " << std::endl;
   char col[10];
   std::cin >> col;
   std::cout << "enter rating: " << std::endl;
   int rat;
   std::cin >> rat;
   hasDMA c(col, temp, rat);
   p_abc[i] = &c;  // &map;
   }
   else
   std::cout << "oops!" << std::endl;

   while (std::cin.get() != '\n')
   continue;
   }
   */

  for (int i = 0; i < LIM; i++)
  {
	std::cout << "\n-----\n p_abc[" << i << "] \n";
	p_abc[i]->View();
  }
  std::cout << std::endl;

  /*  testing class functions
   cout << "Displaying baseDMA object:\n";
   cout << shirt << endl;
   cout << "Displaying lacksDMA object:\n";
   cout << balloon << endl;
   cout << "Displaying hasDMA object:\n";
   cout << map << endl;

   baseDMA shirt2(shirt);
   cout << "Result of baseDMA copy:\n";
   cout << shirt2 << endl;

   lacksDMA balloon2(balloon);
   cout << "Result of lacksDMA copy:\n";
   cout << balloon2 << endl;

   hasDMA map2(map);
   cout << "Result of hasDMA copy:\n";
   cout << map2 << endl;

   hasDMA map3;
   cout << map << endl;
   map3 = map;
   cout << "Result of hasDMA assignment:\n";
   cout << map3 << endl;
   */

  std::cout << "program ends.";
  return 0;
}

