/*
 * worktest.cpp
 *
 *  Created on: 13.05.2024
 *      Author: peter
 */

#include <iostream>
#include "worker0.h"

const int LIM = 4;

int main(int argc, char **argv)
{
  Waiter bob("Bobby", 314L, 5);
  Singer bev("Beverly", 522L, 3);
  Waiter wtemp;
  Singer stemp;

  Worker *pw[LIM] = {&bob, &bev, &wtemp, &stemp};

  int i;
  for (i = 2; i < LIM; i++)
	pw[i]->Set();
  for (i = 0; i < LIM; i++)
  {
	pw[i]->Show();
	std::cout << std::endl;
  }
  return 0;
}

