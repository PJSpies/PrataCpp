/*
 * main.cpp
 *
 *  Created on: 31.03.2024
 *      Author: peter
 */

#include <iostream>
#include "port.h"

int main(int argc, char **argv)
{
  Port p("Tawny", "smooth", 10);
  p.Show();
  VintagePort v("MyBrand", 7, "Old Oak", 1945);
  v.Show();
  v -= 6;
  std::cout << v << std::endl;

  p += 2;
  std::cout << p << std::endl;
  p -= 3;
  std::cout << p << std::endl;
  p = v;
  std::cout << p << std::endl;
  std::cout << v << std::endl;

  return 0;
}

