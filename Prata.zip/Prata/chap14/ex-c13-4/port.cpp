/*
 * port.cpp
 *
 *  Created on: 30.03.2024
 *      Author: peter
 */
#include <iostream>
#include <cstring>
#include "port.h"
Port::Port(const char *br, const char *st, int b)
{
  brand = new char[std::strlen(br) + 1];
  std::strcpy(brand, br);

  std::strncpy(style, st, 19);
  style[19] = '\0';

  bottles = b;
}

Port::Port(const Port &p)
{
  bottles = p.bottles;

  delete brand;
  brand = new char[std::strlen(p.brand) + 1];
  std::strcpy(brand, p.brand);

  std::strncpy(style, p.style, 19);
  style[19] = '\0';

}

//  destructor is already inline in header file   Port::~Port(){}

Port& Port::operator=(const Port &p)  //  assignment operator, cannot be virtual, is used in VintagePort.
{
  if (this == &p) return *this;
  bottles = p.bottles;
  delete brand;

  brand = new char[std::strlen(p.brand) + 1];
  std::strcpy(brand, p.brand);

  std::strncpy(style, p.style, 19);
  style[19] = '\0';
  return *this;
}

// why are +=, -= operators not redefined in VintagePort?
// because the bottles are inherited (contained) as Port in VintagePort objects. The operator works
// on Port-part.
Port& Port::operator+=(int b)  // adds b to bottles
{
  bottles += b;
  return *this;
}

Port& Port::operator-=(int b)  // subtracts b from bottles, if available
{
  if (bottles >= b)
	bottles -= b;
  else
	std::cout << "not enough in stock";
  return *this;
}
//  is already inline...  int BottleCount() const
void Port::Show() const
{
  std::cout << "--------\n";
  std::cout << "Brand   : " << brand << "\n";
  std::cout << "style   : " << style << "\n";
  std::cout << "bottles : " << bottles << "\n";
}
ostream& operator<<(ostream &os, const Port &p)
{
  os << p.brand << ", style: " << p.style << ", bottles: " << p.bottles;
  return os;
}

VintagePort::VintagePort(const char *br, int b, const char *nn, int y) : Port(br, "vintage", b)
{
  nickname = new char[std::strlen(nn) + 1];
  std::strcpy(nickname, nn);
  year = y;
}
VintagePort::VintagePort(const VintagePort &vp) : Port(vp)
{
  delete nickname;
  nickname = new char[std::strlen(vp.nickname) + 1];
  std::strcpy(nickname, vp.nickname);
  year = vp.year;
}

VintagePort& VintagePort::operator=(const VintagePort &vp)
{
  if (this == &vp) return *this;
  Port::operator =(vp);   //  operator=() für base kann nicht virtual sein, weil ich ihn hier brauche
  delete nickname;
  nickname = new char[std::strlen(vp.nickname) + 1];
  std::strcpy(nickname, vp.nickname);
  year = vp.year;
  return *this;
}
void VintagePort::Show() const
{
  Port::Show();
  std::cout << "Nickname: " << nickname << "\n";
  std::cout << "year    : " << year << "\n";
}
// operator<<()  cannot be virtual because I need base's <<() in the overloaded, inherited version
ostream& operator<<(ostream &os, const VintagePort &vp)
{
  os << (const Port&) vp << ", \"" << vp.nickname << "\" (" << vp.year << ")";
  return os;
}

