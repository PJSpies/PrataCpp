/*
 * studentc.h
 *
 *  Created on: 31.03.2024
 *      Author: peter
 */
// studentc.h -- defining a Student class using containment
#ifndef STUDENTC_H_
#define STUDENTC_H_
#include <iostream>
#include <string>
#include <valarray>
class Student
{
private:
  std::string name;    // contained object
  typedef std::valarray<double> ArrayDb;
  ArrayDb scores;    // contained object

// private method for scores output
  std::ostream& arr_out(std::ostream &os) const;

public:    //@formatter:off
//instantiate with contained member names in initialiser list
//  	  -----v                 -----v
  Student() : name("Null Student"), scores()  {  }
  explicit Student(const std::string &s) : name(s), scores()  {  }
  explicit Student(int n) : name("Nully"), scores(n)  {  }
  Student(const std::string &s, int n) : name(s), scores(n)  {  }
  Student(const std::string &s, const ArrayDb &a) : name(s), scores(a)  {  }
  Student(const char *str, const double *pd, int n) : name(str), scores(pd, n)  {  }
  ~Student()  {  }

  double Average() const;
  const std::string& Name() const;
  double& operator[](int i);
  double operator[](int i) const;
// friends
  // input
  friend std::istream& operator>>(std::istream &is, Student &stu);    // 1 word
  friend std::istream& getline(std::istream &is, Student &stu);			// 1 line
  // output
  friend std::ostream& operator<<(std::ostream &os, const Student &stu);
//@formatter:on

};

#endif /* STUDENTC_H_ */
