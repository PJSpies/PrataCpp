/*
 * main.cpp
 *
 *  Created on: 04.05.2024
 *      Author: peter
 */

#include <iostream>
#include <string>
class Frabjous
{
private:
  std::string fstr;

public:    //@formatter:off
  Frabjous(const std::string str = "Default F string") :	fstr(str)  {  };
  virtual void tell()  { std::cout << " Frab's string:" << fstr << "\n";  };

};

class Gloam : private Frabjous
{
private:
    int gli ;
    Frabjous fb  ;
public :
    Gloam (int g = 0 , std::string s = "Gloam default ");
    Gloam (int g , const Frabjous&	f);
    void tell();
};

void Gloam::tell()
{
  std::cout << " Gloam's Frabjous string: ";
  fb.tell();
  std::cout << " Gloam's integer: " << gli << std::endl;
}
Gloam::Gloam(int g, std::string s) : gli(g), fb(s) {}
Gloam::Gloam(int g, const Frabjous & f) : gli(g), fb(f) {}
//@formatter:on

int main(int argc, char **argv)
{
  Frabjous f;
  f.tell();
  Gloam g;
  g.tell();
  Gloam gl(2, "initialised in Gloam");
  gl.tell();
  return 0;
}
