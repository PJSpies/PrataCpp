/*
 * tempmemb.cpp
 *
 *  Created on: 15.05.2024
 *      Author: peter
 */

#include <iostream>
using std::cout;
using std::endl;

//@formatter:off
template<typename T>
  class beta
  {
  private:
	template<typename V>
	class hold
	{
	private:
	 V val;
	public:
	 hold(V v = 0) : val(v)	{ }
	 void show() const {  cout << val << endl; }
	 V Value() const { return val;}
	};
	hold<T> q;    // template object
	hold<int> n;    // template object
  public:
	beta(T t, int i) : q(t), n(i)	{	}
	template<typename U>
	  U blab(U u, T t) { return (n.Value() + q.Value()) * u / t; }   // template method (function)
	void Show() const {  q.show();  n.show();	}
  };

int main() {
  beta<double> guy(3.5, 3);

  guy.Show();
  cout << guy.blab(10, 2.3) << endl;
  cout << "end.\n";
  return 0;

}

//@formatter:on
