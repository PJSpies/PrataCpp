/*
 * main.cpp
 *
 * Prata 6th ed. ; Review Question  14.3
 *
 *  Created on: 11.05.2024
 *      Author: peter
 */

#include <iostream>
#include <cstring>

//@formatter:off

class F{
private:
  char fc[10];
public:
  F(const char * str = "Base") {
	std::strcpy(fc, str);
  }
  virtual ~F(){}
  virtual void tell()
  {
	std::cout << " [base class member: \'" <<  fc << "\']";
  }
};    // end of class declaration F

class G : private F{
private:
  int i;
public:
//  G(){};
  G(int j=1, const char *st = "Derv G") : F(st), i(j) {}
  G(int j, const F& f ) :  F(f), i(j)  {}
  void tell() override{
	  std::cout << " ( derived class member i: " << i << "; with " ;
	  F::tell();
	  std::cout << "  )";
	};
};

int main()
{
  char c[12] = "Review 14.3";
  std::cout << c << "\n";

  std::cout << "\nDefault instantiation of base class\n" ;
  F f;  // default instantiation
  f.tell();

  std::cout << "\nInstantiation of base class w/ string\n" ;
  F f2("base f2");  // instantiate with a string
  f2.tell();

  std::cout << "\nDefault instantiation of derived class \n" ;
  G g;
  g.tell();

  std::cout << "\nInstantiation of derived class w/ string\n" ;
  G g2(4, "Drvd g2");   //  instantiate with string for derived class
  g2.tell();

  std::cout << "\nInstantiation of derived class w/ base\n" ;
  G g3(6,f);  //  instantiate with base object f
  g3.tell();

  return 0;
}

//@formatter:on
