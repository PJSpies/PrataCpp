/*
 * golf.h
 *
 *  Created on: 29.02.2024
 *      Author: peter
 */

#ifndef GOLF_H_
#define GOLF_H_

const int Len = 25;
struct golf
{
  char fullname[Len];
  int handicap;
};

void setgolf(golf &g, const char *name, int hc);
int setgolf(golf &g); //  returns 1 if name is entered,  0 if name is empty (string)

void handicap(golf &g, int hc);
void showgolf(const golf &g);

#endif /* GOLF_H_ */
