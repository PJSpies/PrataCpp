/*
 * golf.cpp
 *
 *  Created on: 29.02.2024
 *      Author: peter
 */

#include "golf.h"
#include <iostream>

void setgolf(golf &g, const char *name, int hc)
{
  int i = 0;
  while (*name)
  {
	g.fullname[i] = *name;
	name++;
	i++;
  }
  g.fullname[i] = '\0';
  g.handicap = hc;
}

int setgolf(golf &g) //  returns 1 if name is entered,  0 if name is empty (string)
{

  std::cout << "Enter Name: ";
  int i {0};
  std::cin.get(g.fullname[i]);
  while (g.fullname[i] != '\n')
  {
	i++;
	std::cin.get(g.fullname[i]);
  }
  g.fullname[i] = '\0';
  std::cout << g.fullname << std::endl;

  if (g.fullname[0] == '\0')
  {
	return 0;
  }
  else
  {
	std::cout << "Enter Handicap: ";
	std::cin >> g.handicap;
//	std::cout << "\n";
	return 1;
  }
}

void handicap(const golf &g, int hc)
{
  g.handicap = hc;
}

void showgolf(const golf &g)
{
  std::cout << "Name: " << g.fullname << " , Handicap: " << g.handicap
	  << std::endl;
}
