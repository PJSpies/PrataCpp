/*
 * main.cpp
 *
 *  Created on: 29.02.2024
 *      Author: peter
 */
#include <iostream>
#include "golf.h"

int main(int argc, char **argv)
{
  golf ana;
  setgolf(ana, "Ana", 5);
  showgolf(ana);

  golf pal;
  int i = setgolf(pal);
  if (i == 1)
  {
//	std::cout << "Name entered. Thanks." << std::endl;
	showgolf(pal);
  }
  else if (i == 0)
	std::cout << "no name given--abort\n";
  else
  {
	std::cout << "something else went wrong --arrgghh" << std::endl;
	return 1;
  }

  handicap(ana, 6);
  showgolf(ana);

  return 0;
}
