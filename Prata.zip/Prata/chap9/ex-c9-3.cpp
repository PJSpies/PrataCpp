/*
 * ex-c9-3.cpp
 *
 *  Created on: 01.03.2024
 *      Author: peter
 */

#include <iostream>
#include <cstring>
#include <new>

struct chaff
{
  char dross[20];
  int slag;
};
const int BUF = 512;
const int N = 2;

char buffer[BUF];

int main()
{
  chaff *pheap, *pbuffer;

  pheap = new chaff[N];
  strcpy(pheap[0].dross, "pheap text1");
  pheap[0].slag = 11;
  strcpy(pheap[1].dross, "pheap text2");
  pheap[1].slag = 22;

  pbuffer = new (buffer) chaff[N];
  strcpy(pbuffer[0].dross, "pbuffer text1");
  pbuffer[0].slag = 12;
  strcpy(pbuffer[1].dross, "pbuffer text2");
  pbuffer[1].slag = 23;

  for (int i {0}; i < N; i++)
  {
	std::cout << pbuffer[i].dross << " : " << pbuffer[i].slag << "at address " << &pbuffer[i] << "\n";
  }
  for (int i {0}; i < N; i++)
  {
	std::cout << pheap[i].dross << " : " << pheap[i].slag << "at address " << &pheap[i] << "\n";
  }

}
