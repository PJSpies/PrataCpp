/*
 * review_c9_52.cpp compile and linke with review_c9_51.cpp, contains remote()
 * Solution 1 of 2:  two separate files with same-name functions
 * The other solution are two unnamed namespaces...
 *
 *  Created on: 22.02.2024
 *      Author: peter
 */
#include <iostream>
static int average(int, int);
extern void remote(); //  remote() calls the other file's code -- with the second average() function

int main(int argc, char **argv)
{
  std::cout << average(3, 6);
  std::cout << "\n";
  remote();
  return 0;
}

int average(int a, int b)
{
  return (a + b) / 2;
}
