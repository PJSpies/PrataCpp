/*
 * review_c9_51.cpp  compile and linke with review_c9_52.cpp, the main() pgm
 * Solution 1 of 2:  two separate files with same-name functions
 * The other solution are two unnamed namespaces...
 *
 *  Created on: 22.02.2024
 *      Author: peter
 */
#include <iostream>

static double average(int a, int b)
{
  return 0.5 * (a + b);
}

void remote()
{
  double x { 3 };
  double y { 6 };
  std::cout << average(x, y);
}

