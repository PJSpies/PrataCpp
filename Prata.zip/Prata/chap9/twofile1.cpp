/*
 * twofile1.cpp
 *
 *  Created on: 19.02.2024
 *      Author: peter
 */

#include <iostream>
int tom { 3 };
int dick { 30 };
static int harry { 300 };
void remote_access();

int main(int argc, char **argv)
{
  using namespace std;
  cout << "main() reports these addresses: \n";
  cout << &tom << " =&tom, " << &dick << " =&dick, ";
  cout << &harry << " =&harry\n";
  remote_access();
  return 0;
}
