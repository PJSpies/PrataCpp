/*
 * review_c9_61.cpp
 *
 *  Created on: 29.02.2024
 *      Author: peter
 */
#include <iostream>
using namespace std;
void other();
void another();

int x {10};
int y;

int main(int argc, char **argv)
{
  cout << x << endl;
  {
	int x {4};
	cout << x << endl;
	cout << y << endl;
  }
  other();
  another();
  return 0;
}

void other()
{
  int y {1};
  cout << "Other: " << x << ", " << y << endl;
}
