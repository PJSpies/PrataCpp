/*
 * review_c9_62.cpp
 *
 *  Created on: 29.02.2024
 *      Author: peter
 */

#include <iostream>
using namespace std;
extern int x;
namespace
{
  int y {-4};
}

void another()
{
  cout << "another(): " << x << ", " << y << endl;
}
