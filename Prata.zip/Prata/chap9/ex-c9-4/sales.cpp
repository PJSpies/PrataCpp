/*
 * sales.cpp
 *
 *  Created on: 01.03.2024
 *      Author: peter
 */

#include <iostream>
#include "sales.h"

namespace SALES
{
  void setSales(Sales &s)
  {
	double sum {0};
	s.max = 0.0;
	s.min = 1000000.0;
	for (int i {0}; i < QUARTERS; i++)
	{
	  std::cout << "Enter sales Q[" << i << "]: ";
	  std::cin >> s.sales[i];
	  sum += s.sales[i];
	  s.max = s.sales[i] > s.max ? s.sales[i] : s.max;
	  s.min = s.sales[i] < s.min ? s.sales[i] : s.min;
	}
	std::cout << std::endl;

	s.average = sum / QUARTERS;
  }  //  end of interactive setSales()

  void setSales(Sales &s, const double ar[], int n)
  {
	double sum {0};
	s.max = 0.0;
	s.min = 1000000.0;
	for (int i {0}; i < QUARTERS; i++)
	  s.sales[i] = 0.0;
	for (int i {0}; i < n; i++)
	{
	  s.sales[i] = ar[i];
	  sum += s.sales[i];
	  s.max = s.sales[i] > s.max ? s.sales[i] : s.max;
	  s.min = s.sales[i] < s.min ? s.sales[i] : s.min;
	}
	s.average = sum / QUARTERS;
  }  //  end of setSales()  non-interactive

  void showSales(const Sales &s)
  {
	for (int i {0}; i < QUARTERS; i++)
	{
	  std::cout << "Quartal " << i << " sales $" << s.sales[i] << std::endl;
	}
	std::cout << "average $" << s.average << std::endl;
	std::cout << "min     $" << s.min << std::endl;
	std::cout << "max     $" << s.max << std::endl;
  }
}
