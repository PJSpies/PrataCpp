/*
 * main.cpp
 *
 *  Created on: 01.03.2024
 *      Author: peter
 */
#include <iostream>
#include "sales.h"
using SALES::QUARTERS;

int main()
{
  SALES::Sales verkauf;
  double quartal[QUARTERS] {1., 2., 3., 4.};
  setSales(verkauf, quartal, QUARTERS);
  showSales(verkauf);

  SALES::Sales v2;
  setSales(v2);
  SALES::showSales(v2);

  return 0;
}
