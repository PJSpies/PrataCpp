/*
 * ex-c9-2.cpp
 *
 *  Created on: 01.03.2024
 *      Author: peter
 */

#include <iostream>
#include <string>

void strcount(const std::string &s);

int main()
{
  using namespace std;
  std::string s;

  cout << "Enter a line:\n";
  getline(std::cin, s);
  strcount(s);
  while (s.size() > 0)
  {
	cout << "Enter next line (empty line to quit):\n";
	getline(std::cin, s);
	strcount(s);
  }

  cout << "bye.\n";
  return 0;
}

void strcount(const std::string &s)
{
  using namespace std;
  static int total {0};

  total += s.size();

  cout << s.size() << " characters.\n";
  cout << total << " characters total.\n";
}
