/*
 * ex-c8-1.cpp
 *
 *  Created on: 16.02.2024
 *      Author: peter
 */
#include <iostream>
#include <string>

void func(const std::string *s, int n=0);
//void func(const std::string s);

int main()
{
	std::string s {"test"};
	std::string * ps = &s;
	func(ps);
	func(ps);

	*ps = "another test";
	func(ps, 1);
	func(ps, 3);

	return 0;
}

void func(const std::string *s, int n)
{
	static int cnt =0;   //  thought it was "static" !  :-)
	if (!n) std::cout << cnt << " " << *s << std::endl;
	else //  n>0
	{
		for (int i=0;i<cnt;i++)
			std::cout << cnt << " " << *s << std::endl;
//		func(s,n-1);
	}
	cnt++;
}
/*
void func(const std::string s)
{
	std::cout << s << std::endl;
}
*/
