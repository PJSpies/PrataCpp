/*
 * review_c8_8.cpp    template function max for a structure 'box'
 *
 *  Created on: 14.02.2024
 *      Author: peter
 */
#include <iostream>
#include <string>
struct box
{
  std::string title;
  double length, width, height;
  double volume = length * width * height;
};

template<typename T>
  T max(const T &b1, const T &b2)
  {
    if (b2.volume > b1.volume)
      return b2;
    return b1;
  }

int main()
{
  box schachtel1 = { "Schachtel1", 1, 2, 3 };   //  vol =  6
  box schachtel2 = { "Schachtel2", 2, 3, 4 };   //  vol = 24

  std::cout << max(schachtel1, schachtel2).title
      << " is the larger box (LxWxH):\n";
  std::cout << max(schachtel1, schachtel2).length << " x "
      << max(schachtel1, schachtel2).width << " x "
      << max(schachtel1, schachtel2).height << " = "
      << max(schachtel1, schachtel2).volume << std::endl;

  return 0;
}
