/*
 * ex-c8-5.cpp
 *
 *  Created on: 18.02.2024
 *      Author: peter
 */

#include <iostream>

template<typename T>
  T max5(T val[5])
  {
    T res;
    res = val[0];
    for (int i = 1; i < 5; i++)
    {
      if (val[i] > res)
	res = val[i];
    }
    return res;
  }

int main(int argc, char **argv)
{
  double d[5] = { 1.2, 3.4, 4.5, 5.1, 0.2 };
  int i[5] = { 5, 3, 7, 2, 1 };
  std::cout << "max5(1.2, 3.4, 4.5, 5.1, 0.2)= " << max5(d) << std::endl;
  std::cout << "max5(5, 3, 7, 2, 1 )= " << max5(i) << std::endl;

}
