/*
    template instantiation
    template specialisation

    Prata 6ed,  Ch 8
*/
#include<iostream>

struct job
{
    char name[40];
    double salary;
    int floor;
};

template <typename T> 
void Swap(T &a, T &b);   //  template for Swap() functions

template <> 
void Swap<job>(job &, job &);   //  explicit specialisation

void Show(job &j);

void Swap(float &a, float &b)  
{
    std::cout << "f'on for float" << std::endl; 
    float temp;
    temp = a;
    a = b;  
    b = temp;
};

int main()
{
    std::cout.precision(2);
    std::cout.setf(std::ios::fixed, std::ios::floatfield);

    int i {10};
    int j {20};

    std::cout << "Start  i,j : " << i << ", " << j << "\n";
    Swap(i,j);          //  use template: implicit instantiation
    std::cout << "Swap1  i,j : " << i << ", " << j << "\n";
    Swap<int>(i,j);     //  explicit instantiation ( equivalent code to above )
    std::cout << "Swap2  i,j : " << i << ", " << j << "\n";

    float x {1.1};
    float y {2.2};
    std::cout << "Start  x,y : " << x << ", " << y << "\n";
    Swap(x,y);           //  explicit specialisation / function (no template), because it is defined for float
    std::cout << "Swap1  x,y : " << x << ", " << y << "\n";
    Swap<float>(x,y);    //  explicit instantiation:  Swap(float &x, float &y)
    std::cout << "Swap2  x,y : " << x << ", " << y << "\n";

    char g {'g'};
    char h {'h'};
    std::cout << "Start  g,h : " << g << ", " << h << "\n";
    Swap<char>(g,h);
    std::cout << "Swap   g,h : " << g << ", " << h << "\n";

    
    double xx {1.1};
    double yy = double(y);
    std::cout << "Start xx,yy : " << xx << ", " << yy << "\n";
    Swap<double>(xx,yy); //  explicit instantiation:  Swap(double &x, double &y)   
    std::cout << "Swap1 xx,yy : " << xx << ", " << yy << "\n";

//    template void Swap<char>(char &; char &);

    job sue {"Sue Y.", 73000.60, 7};
    job sidney {"Sidney M.", 65000, 2};
    Show(sue);
    Show(sidney);

    Swap(sue, sidney);
    Show(sue);
    Show(sidney);

    return 0;
}

template <typename T>
void Swap(T &a, T &b)
{
    T temp;
    temp = a;
    a = b;
    b = temp;
}

template <> void Swap<job>(job &j1, job &j2)  //  explicit specialisation
{
    double t1;
    int t2;
    t1 = j1.salary;
    j1.salary = j2.salary;
    j2.salary = t1;
    t2 = j1.floor;
    j1.floor = j2.floor;
    j2.floor = t2;
}

void Show(const job &j)
{
    std::cout << j.name << ": $" << j.salary
            << " on floor " << j.floor << std::endl; 
}
