/*
 * review_c8_5.cpp     from listing 7.15
 *
 *  Created on: 14.02.2024
 *      Author: peter
 */
#include<iostream>
#include<array>
#include<string>

const int Seasons { 4 };
const std::array<std::string, Seasons> snames = { "spring", "summer", "autumn",
    "winter" };

void show(const std::array<double, Seasons> &da);
void fill(std::array<double, Seasons> &exp);

int main()
{
  std::array<double, Seasons> expenses;
//    expenses = {100.,200.,300.,400.};
  fill(expenses);
  show(expenses);

  return 0;
}
void show(const std::array<double, Seasons> &da)
{
  double total { 0 };
  for (int i = 0; i < Seasons; i++)
  {
    std::cout << snames[i] << ": $" << da[i] << std::endl;
    total += da[i];
  }
  ;
  std::cout << "Total= $" << total << std::endl;
}

void fill(std::array<double, Seasons> &exp)
{
  for (int i = 0; i < Seasons; i++)
  {
    std::cout << "enter val. #" << i + 1 << " ";
    std::cin >> exp.at(i);   /// at() is the address in array!
  }
}
