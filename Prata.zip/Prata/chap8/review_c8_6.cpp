/*
 * review_c8_6.cpp
 *
 *  Created on: 14.02.2024
 *      Author: peter
 */
#include <iostream>

double mass(double dens, double vol =1.);
int average(int i1, int i2);
double average(double d1, double d2);  // Overlaoad with double

//  overload repeat)(
void repeat(int n, const char * s);
void repeat(const char * s);

int main()
{

	std::cout << "m(rho=2.1, v=2.): " << mass(2.1, 2.) << " ..m(rho=3, v=1): " << mass(3.) << std::endl;
	std::cout << "avrg(3,6): " << average(3,6) << "   avrg(3., 6.): " << average(3.,6.) << std::endl;
	repeat(10,"All good.");
	repeat("exactly");

}
void repeat(int n, const char * s)
{
	for (int i {0}; i<n; i++)
		std::cout << s << "\n";
}
void repeat(const char * s)
{
	for (int i {0}; i<5; i++)
		std::cout << s << "\n";
}

double mass(double dens, double vol )
{
	return dens * vol;
}
int average(int i1, int i2){
	return (i1+i2)/2;
}
double average(double d1, double d2){
	return 0.5*(d1+d2);
}
