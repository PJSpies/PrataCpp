/*
 * ex-c8-4.cpp
 *
 *  Created on: 18.02.2024
 *      Author: peter
 */

#include <iostream>
#include <cstring>

struct stringy
{
  char *str;
  int ct;
};

void show(stringy &st, int c = 1);
void show(const char *st, int c = 1);
void set(stringy &st, char *ss);

int main(int argc, char **argv)
{
  stringy beany;
  char testing[] = "Reality isn't what it used to be.";
  set(beany, testing);

  show(beany);
  show(beany, 2);

  testing[0] = 'D';
  testing[1] = 'u';

  show(testing);
  show(testing, 3);

  show("Done.");
  return 0;
}

void show(stringy &st, int c)
{
  for (int i = 0; i < c; i++)
  {
    std::cout << st.str << std::endl;
  }
}
void show(const char *st, int c)
{
  for (int i = 0; i < c; i++)
  {
    std::cout << st << std::endl;
  }
}
void set(stringy &st, char *s)
{
  char *pstr = new char[50];
  int i = 0;
  while (*s)
  {
    pstr[i] = *s;
    s++;
    i++;
  }
  pstr[i] = '\0';

  st.str = pstr;
  st.ct = i;
  delete[] pstr;
}
