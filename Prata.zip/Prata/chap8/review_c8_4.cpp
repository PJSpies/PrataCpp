/*
 * review_c8_4.cpp
 *
 *  Created on: 14.02.2024
 *      Author: peter
 */
#include<iostream>
// #include<cstring>  //  strlen()  excse  7.3
#include<string>

struct box
{
    char maker[40];
    std::string title;
    float height;
    float width;
    float length;
    float volume;
};

void show_box(const box&);
//void set_box(box*, std::string t);  //  found in exercise 7.3
void set_volume(box &b);

int main(){
    box b {"Testbox","Testbox",3, 4, 5};
    show_box(b);
//    set_box(&b, "Boxtest");
    set_volume(b);
    show_box(b);
return 0;
}

void show_box(const box &b){
    std::cout << "Box    : " << b.title << ", ";
    std::cout << "maker  : " << b.maker << ", ";
    std::cout << "height : " << b.height << ", ";
    std::cout << "width  : " << b.width << ", ";
    std::cout << "length : " << b.length << "= ";
    std::cout << "volume : " << b.volume << "\n";
};

void set_volume(box &b)
{
    b.volume = b.height * b.width * b.length;
};
/*
void set_box(box* pb, std::string t)
{
//    char * name = "test" ;  //  not  ISO C++ !!
    char name[5] {"test"};    //  this is OK

    std::cout << name << "\n";
    std::cout << pb->maker << "\n";
    pb->title = t;

//    pb->maker = "test";   //  not a modifiable lvalue? Weil maker ein char* und "test" ein const char.
//  workaround: modify char-array one-by-one character in the array.
    for (int i {0}; i<strlen(name); i++)
        pb->maker[i] = name[i];
    pb->maker[strlen(name)]='\0';

    pb->volume = pb->height * pb->width * pb->length;

};
*/
