/*
 * review_c8_7.cpp
 *
 *  Created on: 14.02.2024
 *      Author: peter
 */

#include <iostream>

template <typename T>
T max(T a, T b){
	return a > b ? a : b;
}

int main(int argc, char **argv)
{
	double a {5.5};
	double b {6.6};
	std::cout << "max("<<a<<","<<b<<"): " << max(a,b)<< std::endl;
	int i {5};
	int j {6};
	std::cout << "max("<<i<<","<<j<<"): " << max(i,j)<< std::endl;

	return 0;
}

