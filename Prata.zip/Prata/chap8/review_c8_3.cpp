/*
 * review_c8_3.cpp
 *
 *  Created on: 14.02.2024
 *      Author: peter
 */

#include <iostream>
#include <string>

void iquote(double);
void iquote(int);
void iquote(std::string);

int main(int argc, char **argv)
{
	iquote(13.1);
	iquote(7);
	iquote("string");
	return 0;
}

void iquote(double arg)
{
	using namespace std;
	cout << "\"" << arg << "\"" << endl;

};
void iquote(int arg)
{
	using namespace std;
	cout << "\'" << arg << "\'" << endl;
}
void iquote(std::string arg)
{
	using namespace std;
	cout << "<<" << arg << ">>" << endl;
}
