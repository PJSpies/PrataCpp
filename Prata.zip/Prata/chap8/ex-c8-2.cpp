/*
 * ex-c8-2.cpp
 *
 *  Created on: 16.02.2024
 *      Author: peter
 */

#include <iostream>
#include <string>

struct CandyBar
{
  std::string name;
  char nick[20];
  float weight;
  int cals;
};

void setCandy(CandyBar &candy, char * str="Munchy", std::string s="Munchy Power", float w=235.5, int c = 100);
void showCandy(const CandyBar &b);

int main()
{
  CandyBar candy;
  CandyBar &bar = candy;
  setCandy(bar);
  showCandy(bar);

  setCandy(bar, "Monster", "Monster Bar", 300.1, 400);
  showCandy(bar);

  return 0;
}
void showCandy(const CandyBar &b)
{
  std::cout << "Name: \"" << b.name << "\"\t  weight: "<< b.weight << " calories: " << b.cals << std::endl;
}

void setCandy(CandyBar &candy, char * str, std::string s, float w, int c )
{
  candy.name = s;
  int i=0;
  while (*str && i<20)
  {
     candy.nick[i] = *str;
     str++; i++;
  }
  candy.nick[i]='\0';
  candy.weight = w;
  candy.cals = c;
}
