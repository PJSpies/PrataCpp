/*
 *	Prata 6th ed., Chapter 8 on functions, template functions, etc.
 * ex-c8-7.cpp
 *
 *  Created on: 18.02.2024
 *      Author: peter
 *
 *  from   listing_c8_14.cpp
 */
#include<iostream>

template<typename T>
  void ShowArray(T a[], int n);
///*
template<typename T>
  void ShowArray(T *a[], int n);
//*/
struct debts
{
  char name[20];
  double amount;
};

int main()
{
  using namespace std;
  int things[6] = { 13, 31, 109, 201, 310, 499 };
  debts mr_E[3] { { "Ima Wolfe", 2400.00 }, { "Ura Fox", 3800.00 }, {
      "Iby Stour", 1400.00 } };

  double *pd[3];
  for (int i { 0 }; i < 3; i++)
    pd[i] = &mr_E[i].amount;

  cout << "List of things:\n";
  ShowArray(things, 6);
  cout << "List of  debts:\n";
  ShowArray(pd, 3);

  return 0;
}

template<typename T>
  void ShowArray(T arr[], int n)
  {
    using namespace std;
    T sum { 0 };
    cout << "template A\n";
    for (int i { 0 }; i < n; i++)
      sum += arr[i];
    cout << "sum: " << sum << " n: " << n << endl;
  }

template<typename T>
  void ShowArray(T *arr[], int n)
  {
    using namespace std;
    cout << "template B\n";
    T sum { 0 };
    for (int i { 0 }; i < n; i++)
      sum += *arr[i];
    cout << "sum: " << sum << " n: " << n << endl;
  }
/**/
