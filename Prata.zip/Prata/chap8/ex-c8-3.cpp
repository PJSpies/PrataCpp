/*
 * ex-c8-3.cpp
 *
 *  Created on: 17.02.2024
 *      Author: peter
 */
#include <iostream>
#include <string>	//  getline()
#include <cctype>   //  toupper()

void f(std::string &s) {
	for (int i { 0 }; i < s.length(); i++) {
		s[i] = std::toupper(s[i]);
	}
}

int main() {
	std::string str;

	std::cout << "Enter string: ";
	std::getline(std::cin, str);

	while (str != "q") {
		f(str);
		std::cout << str << std::endl;
		std::cout << "Enter string: ";
		std::getline(std::cin, str);
	}

	return 0;
}

