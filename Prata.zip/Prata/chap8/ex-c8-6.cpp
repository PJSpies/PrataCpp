/*
 * ex-c8-6.cpp
 *
 *  Created on: 18.02.2024
 *      Author: peter
 */
#include <iostream>
#include <cstring>   //  strlen()

template<typename T>
  T maxn(T val[], int n)
//  {
//    T res = val[0];
//    for (int i = 1; i < n; i++)
//    {
//      if (val[i] > res)
//	res = val[i];
//    }
//    return res;
//  }
  {
    T res = val[0];
    for (int i = 1; i < n; i++)
      res = res < val[i] ? val[i] : res;
    return res;
  }

template<>
  char* maxn(char *val[], int n)
  {
    char *res = val[0];
    for (int i = 1; i < n; i++)
      res = strlen(res) < strlen(val[i]) ? val[i] : res;
    std::cout << &res << "\n";
    return res; // returns the longest string // type const char*
  }

int main(int argc, char **argv)
{
  double d[4] = { 3.4, 4.5, 5.1, 0.2 };
  int i[6] = { 5, 3, 7, 2, 1, 9 };
  std::cout << "maxn(3.4, 4.5, 5.1, 0.2)= " << maxn(d, 4) << std::endl;
  std::cout << "maxn(5, 3, 7, 2, 1, 9 )= " << maxn(i, 6) << std::endl;

  char *s1[5] = { "Test", "Longtest", "Evenlongertest", "s", "" };
  char *longstring = maxn(s1, 5);
  std::cout << maxn(s1, 5);

  std::cout << &longstring << " " << longstring << std::endl;

  return 0;
}
