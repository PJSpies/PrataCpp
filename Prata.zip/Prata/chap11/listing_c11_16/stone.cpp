/*
 * stone.cpp
 *
 *  Created on: 10.03.2024
 *      Author: peter
 */

#include <iostream>
#include "stonewt.h"
void display(const Stonewt &s);

int main(int argc, char **argv)
{
  using std::cout;
  Stonewt ich { 2 * 83.5 };
  ich.show_stn();
  ich.show_lbs();
  display(179);

  Stonewt you(9, 2.8);

  // ***  I removed  conversion functions 'operator double()' and 'operator int()'
  // ***  they would cause ambiguous addition to choose from:  Stonewt object -> double  or  double -> Stonewt
  // ***  Prata 5th ed, p.554

  // double your_wt = you;  //  implicit conversion
  // cout << "Your weight= " << your_wt << " pounds\n";
  // cout << "convert to int: " << int(you) << " pounds.\n";

  Stonewt s = ich + you;
  s.show_lbs();
  // cout << "s: " << int(s) << " stone\n";

  Stonewt st(4, 3);
  double d = 120.;
  // using the friend function only:
  Stonewt t = st + d;   //  t=  operator+(double , Stonewt (double) )
  t.show_stn();
  t = d + st;   //  t= operator+(double d, Stonewt st)
  t.show_stn(); //  t == (12, 11)

  Stonewt n(10, 8);
  t = n * 2.;   //  t == (21, 2)
  t.show_stn();
  Stonewt m(10, 8);
  t = 2 * m;	//  t == (21, 2)
  t.show_stn();

  return 0;
}

void display(const Stonewt &s)
{
  s.show_stn();
}
