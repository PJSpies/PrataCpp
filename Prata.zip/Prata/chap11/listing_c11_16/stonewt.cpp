/*
 * stonewt.cpp
 *
 *  Created on: 10.03.2024
 *      Author: peter
 */
#include <iostream>
#include "stonewt.h"

using std::cout;
Stonewt::Stonewt(double lbs)
{
  stone = int(lbs) / Lbs_per_stn;
  pds_left = int(lbs) % Lbs_per_stn + lbs - int(lbs);
  pounds = lbs;
}
Stonewt::Stonewt(int stn, double lbs)
{
  stone = stn;
  pds_left = lbs;
  pounds = stn * Lbs_per_stn + lbs;
}
Stonewt::Stonewt()
{
  stone = pounds = pds_left = 0.;
}

Stonewt::~Stonewt()
{
  ;
}

void Stonewt::show_stn() const
{
  cout << stone << " stone, " << pds_left << " pounds.\n";
}

void Stonewt::show_lbs() const
{
  cout << pounds << " pounds.\n";
}
/*
 Stonewt::operator int() const
 {
 return int(pounds + 0.5);
 }

 Stonewt::operator double() const
 {
 return pounds;
 }
 */
/*
 Stonewt Stonewt::operator+(const Stonewt &s1) const
 {
 double sum = pounds + s1.pounds;
 Stonewt s(sum);  //  invokes constructor  Stonewt(double lbs);
 return s;
 }
 */

//  friend operator+
Stonewt operator+(const Stonewt &s1, const Stonewt &s2)
{
  double sum = s2.pounds + s1.pounds;
  Stonewt s(sum);  //  invokes constructor  Stonewt(double lbs);
  return s;
}

//  review question 11.1   Use a member function to overload operator*()
Stonewt Stonewt::operator*(double d)
{
//  double lbs = pounds * d;
//  Stonewt s(lbs);
//  return s;
  return Stonewt(pounds * d);
}

//  review question 11.4   Use a friend function to overload operator*()
Stonewt operator*(double d, const Stonewt &s)
{
//  double lbs = d * s.pounds;
//  Stonewt x(lbs);
//  return x;
  return Stonewt(s.pounds * d);
}
