/*
 * stonewt.cpp
 *
 *  Created on: 10.03.2024
 *      Author: peter
 */
#include <iostream>
#include "stonewt.h"

using std::cout;
Stonewt::Stonewt(double lbs)
{
  stone = int(lbs) / Lbs_per_stn;
  pds_left = int(lbs) % Lbs_per_stn + lbs - int(lbs);
  pounds = lbs;
  mode = fpnd;
}
Stonewt::Stonewt(int stn, double lbs)
{
  stone = stn;
  pds_left = lbs;
  pounds = stn * Lbs_per_stn + lbs;
  mode = fpnd;
}
Stonewt::Stonewt()
{
  stone = pounds = pds_left = 0.;
  mode = fpnd;
}

Stonewt::~Stonewt()
{
  ;
}
void Stonewt::set_mode(Mode m)
{
  mode = m;
}

/*
 void Stonewt::show_stn() const
 {
 cout << stone << " stone, " << pds_left << " pounds.\n";
 }

 void Stonewt::show_lbs() const
 {
 cout << pounds << " pounds.\n";
 }
 */
//  friend operator+
Stonewt operator+(const Stonewt &s1, const Stonewt &s2)
{
  double sum = s1.pounds + s2.pounds;
  Stonewt s(sum);  //  invokes constructor  Stonewt(double lbs); ...and default mode is fpnd
  return s;
}
//  friend operator-
Stonewt operator-(const Stonewt &s1, const Stonewt &s2)
{
  double sum = s1.pounds - s2.pounds;
  Stonewt s(sum);  //  invokes constructor  Stonewt(double lbs); ...and default mode is fpnd
  return s;
}
//  friend operator*
Stonewt operator*(const Stonewt &s1, const Stonewt &s2)
{
  double product = s2.pounds * s1.pounds;
  Stonewt s(product);  //  invokes constructor  Stonewt(double lbs); ...and default mode is fpnd
  return s;
}

//  review question 11.1   Use a member function to overload operator*()
Stonewt Stonewt::operator*(double d)
{
//  double lbs = pounds * d;
//  Stonewt s(lbs);
//  return s;
  return Stonewt(pounds * d);
}

//  review question 11.4   Use a friend function to overload operator*()
Stonewt operator*(double d, const Stonewt &s)
{
//  double lbs = d * s.pounds;
//  Stonewt x(lbs);
//  return x;
  return Stonewt(s.pounds * d);
}

std::ostream& operator<<(std::ostream &os, const Stonewt &s)
{
  if (s.mode == Stonewt::st)
	os << s.stone << " stone , " << s.pds_left << " pds";
  else if (s.mode == Stonewt::ipnd)
	os << s.stone * Stonewt::Lbs_per_stn + (int) (s.pds_left + 0.5) << " pounds";
  else if (s.mode == Stonewt::fpnd)
	os << s.pounds << " pounds";
  else
	std::cout << "Oops!" << std::endl;
  return os;
}
