/*
 * stonewt.h
 *
 *  Created on: 10.03.2024
 *      Author: peter
 */

#ifndef STONEWT_H_
#define STONEWT_H_
#include <iostream>

class Stonewt
{
public:
  enum Mode
  {
	st, ipnd, fpnd
  };
private:
  static const int Lbs_per_stn = 14;
  int stone;
  double pds_left;
  double pounds;
  Mode mode;

public:

  Stonewt(double lbs);
  Stonewt(int stn, double lbs);
  Stonewt();
  ~Stonewt();

//  11.5
  void set_mode(Mode m);
//11.5  void show_lbs() const;
//11.5  void show_stn() const;

  /*  implicit conversion functions */
//  operator int() const;
//  operator double() const;
//  Stonewt operator+(const Stonewt &s1) const;
  friend Stonewt operator+(const Stonewt &s1, const Stonewt &s2);
  friend Stonewt operator-(const Stonewt &s1, const Stonewt &s2);
  friend Stonewt operator*(const Stonewt &s1, const Stonewt &s2);

//  review question 11.1   Use a member function to overload operator*()
  Stonewt operator*(double d);
//  review question 11.4   Use a friend function to overload operator*()
  friend Stonewt operator*(double d, const Stonewt &s);

  //  11.5
  friend std::ostream& operator<<(std::ostream &os, const Stonewt &s);

};

#endif /* STONEWT_H_ */
