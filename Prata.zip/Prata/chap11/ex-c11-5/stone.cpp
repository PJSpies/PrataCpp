/*
 * stone.cpp
 *
 *  Created on: 10.03.2024
 *      Author: peter
 */

#include <iostream>
#include "stonewt.h"

int main()
{
  using std::cout;
  using std::endl;
  Stonewt ich { 2 * 83.5 };
  Stonewt you(9, 2.8);

  // double your_wt = you;  //  implicit conversion
  // cout << "Your weight= " << your_wt << " pounds\n";
  // cout << "convert to int: " << int(you) << " pounds.\n";

  Stonewt s;
  cout << "ich      : " << ich << endl;
  cout << "you      : " << you << endl;
  cout << "ich + you: " << ich + you << endl;
  cout << "ich - you: " << ich - you << endl;

  cout << "Testing *\n";
  Stonewt u { 14.4 };  //  should be 1 stone, 0.6 pds_left  or  15 Pounds
  u.set_mode(Stonewt::st);
  cout << "Stonewt u(1, 1); u.set_mode(Stonewt::st);   " << u << endl;
  u.set_mode(Stonewt::fpnd);
  cout << "Stonewt u(1, 1); u.set_mode(Stonewt::fpnd); " << u << endl;
  u.set_mode(Stonewt::ipnd);
  cout << "Stonewt u(1, 1); u.set_mode(Stonewt::ipnd); " << u << endl;

  s = 1;
  cout << "s = 1; (fpnd)   " << s << endl;
  u = s * u;
  cout << "u = s*u; (fpnd) " << u << endl;

  // using the friend function only:
  double d = 14.;
  Stonewt t;
  t = d + u;   //  t= operator+(double d, Stonewt st)
  cout << "d = 14.;  t = u + d; (default) " << t << endl;
  t.set_mode(Stonewt::ipnd);
  cout << "d = 14.;  t = u + d; (ipnd   ) " << t << endl;

  Stonewt n(10, 8);
  t = n * 2.;   //  t == (21, 2)  ..  this oper*() re-sets mode to default (=fpnd)!
  t.set_mode(Stonewt::st);
  cout << t << endl;
  Stonewt m(10, 8);
  t = 2 * m;	//  t == (21, 2)  ..  this oper*() re-sets mode to default (=fpnd)!
  t.set_mode(Stonewt::st);
  cout << t << endl;

  return 0;
}

