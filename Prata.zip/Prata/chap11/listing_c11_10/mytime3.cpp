/*
 * mytime3.cpp
 *
 *  Created on: 08.03.2024
 *      Author: peter
 */

#include <iostream>
#include "mytime3.h"

Time::Time()
{
  hours = 0;
  minutes = 0;
}

Time::Time(int h, int m)
{
  hours = h;
  minutes = m;
}

void Time::AddMin(int m)
{
  minutes += m;
  hours += minutes / 60;
  minutes %= 60;
}

void Time::AddHr(int h)
{
  hours += h;
}

void Time::Reset(int h, int m)
{
  hours = h;
  minutes = m;
}

Time Time::operator+(const Time &t) const
{
  Time sum;
  sum.minutes = minutes + t.minutes;
  sum.hours = hours + t.hours + sum.minutes / 60;
  sum.minutes %= 60;
  return sum;
}

Time Time::operator-(const Time &t) const
{
  Time diff;
  int tot1, tot2;
  tot1 = t.minutes + 60 * t.hours;
  tot2 = minutes + 60 * hours;
  diff.minutes = (tot2 - tot1) % 60;
  diff.hours = (tot2 - tot1) / 60;
  return diff;
}

Time Time::operator*(double mult) const
{
  Time result;
  long totalminutes = hours * mult * 60 + minutes * mult;
  result.hours = totalminutes / 60;
  result.minutes = totalminutes % 60;
  return result;
}

Time operator*(double mult, const Time &t)
{
  return t * mult;
}

/*  A friend function (no class qualifier '::' used in definition!!!
 Time operator*(double mult, const Time &t) //   this is a friend function, allows multiplication time1 = 1.4* time2  versus 'time2*1.4'
 {
 Time result;
 long totalminutes = t.hours * mult * 60 + t.minutes * mult; //  use t. explicitly-- must be a friend function. It is not a class member
 result.hours = totalminutes / 60;
 result.minutes = totalminutes % 60;
 return result;
 }
 */
void Time::Show() const
{
  std::cout << hours << " hours, " << minutes << " minutes.";
}

std::ostream& operator<<(std::ostream &os, const Time &t)
{
  os << t.hours << " hours, " << t.minutes << " minutes.";
  return os;
}
