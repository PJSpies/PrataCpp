/*
 * mytime3.h
 *
 *  Created on: 08.03.2024
 *      Author: peter
 */

#ifndef MYTIME3_H_
#define MYTIME3_H_

class Time
{
private:
  int hours;
  int minutes;
public:
  Time();
  Time(int h, int m = 0);
  void AddMin(int m);
  void AddHr(int h);
  void Reset(int h = 0, int m = 0);

//  addition
  Time operator+(const Time &t) const;

//  difference
  Time operator-(const Time &t) const;

//  multiplication
  Time operator*(double n) const;
  friend Time operator*(double m, const Time &t);

//  others
  friend std::ostream& operator<<(std::ostream &os, const Time &t);

  void Show() const;
};

#endif /* MYTIME3_H_ */
