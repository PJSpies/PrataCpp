/*
 * main.cpp
 *
 *  Created on: 08.03.2024
 *      Author: peter
 */

#include <iostream>
#include "mytime3.h"

int main(int argc, char **argv)
{
  Time weeding(4, 35);
  Time waxing(2, 47);
  Time total;
  Time diff;
  Time adjusted;

  std::cout << "weeding time= ";
  weeding.Show();
  std::cout << std::endl;

  std::cout << "waxing time= ";
  waxing.Show();
  std::cout << std::endl;

  std::cout << "total work time= ";
  total = weeding + waxing;
  total.Show();
  std::cout << std::endl;

  std::cout << "weeding - waxing time= ";
  diff = weeding - waxing;
  diff.Show();
  std::cout << std::endl;

  std::cout << "adjusted time = ";
  adjusted = total * 1.5;	//  Here '*' invokes member function  'A.operator*(B, 1.5)'
  adjusted.Show();
  std::cout << std::endl;
  std::cout << "adjusted time2= ";
  adjusted = 1.5 * total;   //  Here '*' uses a friend function to invoke 'A.operator*(1.5, B)'
  adjusted.Show();
  std::cout << std::endl;

  std::cout << "total " << total << std::endl;
  return 0;
}

