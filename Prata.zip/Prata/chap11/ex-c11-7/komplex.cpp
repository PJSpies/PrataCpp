/*
 * komplex.cpp
 *
 *  Created on: 12.03.2024
 *      Author: peter
 */

#include <iostream>
#include "komplex.h"

complex::complex()
{
  re = 0.;
  im = 0.;
}
complex::complex(double r, double i) :
	re { r }, im { i }
{
}
complex::~complex()
{
}

complex complex::operator+(const complex &c)
{
  return complex(c.re + re, c.im + im);
}

complex complex::operator-(const complex &c)
{
  return complex(re - c.re, im - c.im);;
}

complex complex::operator*(double m) const  //  member op*()
{
  return complex(m * re, m * im);
}

complex complex::operator*(const complex &z2) const //  member op* (z1, z2)
{
  return complex(re * z2.re - im * z2.im, (re * z2.im) + (im * z2.re));
}

//  the friend function  to multiply z with m  ( m*z )  ruft constructor für z, dann z.operator*(double m)
complex operator*(double m, const complex &z) //  non-member op*()
{
  return z * m;  //  geht nur so rum!  nicht:  m*z
}

complex complex::operator~() //  member complement(z)
{
  return complex(re, -im);
}

std::ostream& operator<<(std::ostream &os, const complex &c)
{
  os << "(" << c.re << ", " << c.im << "i)";
  return os;
}

std::istream& operator>>(std::istream &is, complex &z)
{
  std::cout << "Real: ";
  is >> z.re;

  std::cout << "Img : ";
  is >> z.im;
  return is;
}
