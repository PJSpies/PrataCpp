/*
 * komplex.h
 *
 *  Created on: 12.03.2024
 *      Author: peter
 */

#ifndef KOMPLEX_H_
#define KOMPLEX_H_

#include <iostream>
class complex
{
private:
  double re;
  double im;
public:
  complex();
  complex(double r, double i);
  ~complex();

  complex operator+(const complex &z);
  complex operator-(const complex &z);

  complex operator*(double m) const;  //   returns = c.operator*(m)

  complex operator*(const complex &z2) const;  // returns  = z.operator*(z2)  is  z x z2

  friend complex operator*(double m, const complex &z1);  // returns  =

  complex operator~();

  friend std::ostream& operator<<(std::ostream &os, const complex &z);
  friend std::istream& operator>>(std::istream &is, complex &z);
};

#endif /* KOMPLEX_H_ */
