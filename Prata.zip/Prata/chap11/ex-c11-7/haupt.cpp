/*
 * haupt.cpp
 *
 *  Created on: 12.03.2024
 *      Author: peter
 */
#include <iostream>
#include "komplex.h"

int main()
{
  complex z1 { 1, 1 };
  std::cout << "z1   : " << z1 << std::endl;
  complex z2 { -1, 1 };
  std::cout << "z2   : " << z2 << std::endl;

  std::cout << "z1+z2: " << z1 + z2 << std::endl;
  std::cout << "z1-z2: " << z1 - z2 << std::endl;
  std::cout << "z1*z2: " << z1 * z2 << std::endl;
  std::cout << "3.*z2: " << 3. * z2 << std::endl;
  std::cout << "~z1  : " << ~z1 << std::endl;

  complex z3;
  std::cin >> z3;
  std::cout << "z3   : " << z3 << std::endl;

  std::cout << "bye." << std::endl;
  return 0;
}
