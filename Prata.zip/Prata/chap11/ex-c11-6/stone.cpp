/*
 * stone.cpp
 *
 *  Created on: 10.03.2024
 *      Author: peter
 */

#include <iostream>
#include "stonewt.h"

int main()
{
  using std::cout;
  using std::endl;
  Stonewt weights[6] { { 11, 0 }, { 200.4 }, { 315.1 }, {}, {}, {} };

//  simple intake of weights 3 to 5
  int i = 3;
  double p;
  cout << "enter weights[" << i << "]: ";
  while (i < 6 && std::cin >> p)   //  check i before reading input!!
  {
	weights[i] = p;
	i++;
	cout << "enter weights[" << i << "]: ";
  }

  Stonewt largest { 0. };
  Stonewt smallest { 100000. };
  Stonewt ten(10, 0);  //  140.0 pounds
  int count_ge { 0 };
  for (int i { 0 }; i < 6; i++)
  {
	largest = weights[i] > largest ? weights[i] : largest;
	smallest = weights[i] < smallest ? weights[i] : smallest;
	if (weights[i] >= ten) count_ge = i;
  }
  cout << "Largest " << largest << "   smallest: " << smallest << "  Number greater or equal to 10 stn: " << count_ge << endl;

  cout << "Testing output\n--------------\n";
  Stonewt u { 14.4 };  //  should be 1 stone, 0.6 pds_left  or  15 Pounds
  u.set_mode(Stonewt::st);
  cout << "Stonewt u(1, 1); u.set_mode(Stonewt::st);   " << u << endl;
  u.set_mode(Stonewt::fpnd);
  cout << "Stonewt u(1, 1); u.set_mode(Stonewt::fpnd); " << u << endl;
  u.set_mode(Stonewt::ipnd);
  cout << "Stonewt u(1, 1); u.set_mode(Stonewt::ipnd); " << u << endl;

  return 0;
}

