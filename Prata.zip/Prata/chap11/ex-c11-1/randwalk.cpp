/*
 * randwalk.cpp
 * modified for 11.2 and 11.3
 *
 *  Created on: 10.03.2024
 *      Author: peter
 */
#include <iostream>
#include <cstdlib>  // rand(), srand()
#include <ctime>	// time()
#include <fstream>  // fout

#include "vect.h"

int main()
{
  using namespace std;
  using VECTOR::Vector;
  unsigned long LARGE { 1000000 };

  srand(time(0));
  double direction;
  Vector step;

  Vector result(0., 0.);
  int trials { 0 };
  unsigned long steps { 0 };
  unsigned long total_steps { 0 };
  unsigned long high { 0 };
  unsigned long avrg { 0 };
  unsigned long low { LARGE };

  //11.1  ofstream fout;
  //11.1  fout.open("steps.txt");
  //11.1    if (fout.fail())
  //11.1    {
  //11.1  	cout << " ERR opening file steps.txt!" << endl;
  //11.1    }

  double target;
  double dstep;
  cout << "enter target distance (q to quit): ";
  if (!(cin >> target)) return 1;

  cout << "enter step length dstep (q to quit): ";
  if (!(cin >> dstep)) return 2;

  cout << "enter number of trials N (q to quit): ";
  if (!(cin >> trials)) return 3;

  for (int iter = 0; iter < trials; iter++)
  {
	//11.1  	fout << "target= " << target << endl;
	//11.1  	fout << "dstep= " << dstep << endl;

	while (result.magval() < target && steps < LARGE)  //  run the trial
	{
	  direction = rand() % 360;
	  step.set(dstep, direction, 'p');
	  result = result + step;
// 11.2	  cout << steps << ": " << result << endl;
	  //11.1  	  fout << steps << ": " << result << endl;
	  steps++;
	}
	total_steps += steps;
	low = steps < low ? steps : low;
	high = steps > high ? steps : high;

// 11.2	cout << "Trial " << iter << " Number of steps " << steps << ". Location: " << result << endl;
// 11.2 	cout << "after " << steps << " steps, the subject has the following location:\n";
	//11.1  	fout << "after " << steps << " steps, the subject has the following location:\n";
	//11.1  	fout << result << endl;

// 11.2	result.polar_mode();
	// 11.2	cout << " or\n" << result << endl;
	//11.1  	fout << " or\n" << result << endl;
	// 11.2	cout << "Average outward distance per step = " << result.magval() / steps << endl;
	//11.1  	fout << "Average outward distance per step = " << result.magval() / steps << endl;
	steps = 0;
	result.set(0., 0.);
// 11.2	cout << "enter target distance (q to quit): ";

  }  //  trials
  avrg = total_steps / trials;
  cout << "From " << trials << " trials the average number of steps is " << avrg << " vs. theoretical :"
	  << target * target / dstep / dstep;
  cout << "	fewest steps: " << low << "  most steps: " << high << endl;

  cout << "Bye.\n";
  //11.1    fout.close();
  return 0;
}

