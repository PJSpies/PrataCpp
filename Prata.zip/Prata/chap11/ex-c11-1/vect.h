/*
 * vect.h
 *
 *  Created on: 10.03.2024
 *      Author: peter
 */

#ifndef VECT_H_
#define VECT_H_
#include <iostream>
#include <cmath>

namespace VECTOR
{
  class Vector
  {
  private:
	double x;
	double y;
	double mag;
	double ang;
	char mode;  // 'r' for rectangular, 'p' for polar coordinates
// methods
	void set_mag(double x, double y);  //  changed for 11.2.   in main call as  result.magval()
	void set_ang(double x, double y);  //  changed for 11.2
	void set_x();
	void set_y();
  public:
	Vector();
	Vector(double n1, double n2, char form = 'r');
	void set(double n1, double n2, char form = 'r');
	~Vector();

	double xval() const
	{
	  return x;
	}
	double yval() const
	{
	  return y;
	}
	double magval() const
	{
	  return mag;
	}
	double angval() const
	{
	  return ang;
	}

	void polar_mode();
	void rect_mode();

	Vector operator+(const Vector &b) const;
	Vector operator-(const Vector &b) const;
	Vector operator-() const;
	Vector operator*(double n) const;

	//  friends
	friend Vector operator*(double n, const Vector &a);
	friend std::ostream& operator<<(std::ostream &os, const Vector &v);

//  review question 11.7   define conversion double magnitude(const Vector &v)
	operator double() const;

  };
}
#endif /* VECT_H_ */

