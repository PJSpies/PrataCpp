#include<iostream>
using namespace std;

int main(){
    char c;
    int cnt1 {0};
    int cnt2 {0};

goto Q4;  // skip forward

    cout << "Enter text:\n";

    while( (c=cin.get() != '$') )
    {
        cout << c;
        cnt1++;
        if (c == '$') // cnt2 never gets updated.
                      // with typo (c='$') the condition is always true!
            cnt2++;
        cout << c;
    }
    cout << "cnt1= " << cnt1 << "   cnt2= " << cnt2 << "\n";

Q4: //  next question.
    // logical expressions
    float weight {120.};
    if (weight >= 115. && weight < 125)
        cout << " 115 <= " << weight << "< 125.\n";

    c = 'q';
    if (c == 'q' || c == 'Q') 
        cout << " c is q or Q.\n";

    int x{8};
    if ( x % 2 ==0 && x != 26)
        cout << " x is " << x << " even and not 26.\n";

    x = x*2 + 4;
    if ( (x % 2 ==0) && (x >=26) && (x /26 != 0) )
        cout << " x is " << x << " even and not multiple of 26.\n";

    float donation {1500};
    int guest {2};
    if (guest == 1 || (donation > 1000. && donation < 2000.))
        cout << "guest ==" << guest << " || (donation > 1000. && donation < 2000.)" << endl;

//  Questions 5 and 6:
    bool nein {false};
    cout << " gesetzt                 : " << nein << endl;;
    cout << " Nagation           !nein: " << !nein << endl;
    cout << " doppelte Negation !!nein: " << !!nein << endl;

//  abolute value of y
        float y {-10.};
        if (y < 0.)  y = -y;  //   y *= -1.
        cout << "y " << y << endl;

        y = -4.;
        float b = y < 0 ? -y : 0.;
        cout << "y " << y<< "   b " << b << endl;

//  question 7
goto Q8;
    cin >> c;
    switch (c)
    {
    case 'a':
    case 'A':
        cout << c <<" a or A";
        break;
    case 'B':
    case 'b':
        cout << c <<" b or B";
    
    default:
        cout << c <<" neither!";
        break;
    }
Q8:
    int line {0};
    while (cin.get(c) && c != 'Q' )
    {
        if (c == '\n') line++;
    }
    cout << line << endl;
    
return 0;
}