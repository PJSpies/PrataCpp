/*   Prata 6th ed, Chp.6  Exercise 6  */
#include<iostream>

struct Patron
{
std::string name;
double amnt;

};

int main(){

    int num;
    std::cout << "Enter number of entries: ";
    std::cin >> num;
    Patron* patron = new Patron [num];
    
    for (int i=0; i<num;i++)
    {
        std::cout << i+1 << " Enter patron's name: ";
        std::cin >> patron[i].name;
        std::cout << i+1 << " Enter donation made: ";
        std::cin >> patron[i].amnt;
    }

    std::cout << "\n++++++ Grand Patrons ++++++\n";
    bool gpfound {false};
    for (int i=0; i<num;i++)
    {
        if (patron[i].amnt > 10000.)
            gpfound = true;
    }
    if (gpfound)
    {
        for (int i=0; i<num;i++)
        {
            if (patron[i].amnt >= 10000.)
                std::cout << patron[i].name << " : " << patron[i].amnt <<"\n";
        }
    }
    else
        std::cout << "none.\n";

    std::cout << "\n______ Patrons ______\n";
    gpfound =false;
    for (int i=0; i<num;i++)
    {
        if (patron[i].amnt > 0. && patron[i].amnt < 10000.)
            gpfound = true;
    }
    if (gpfound)
    {
        for (int i=0; i<num;i++)
        {
            if (patron[i].amnt > 0. && patron[i].amnt < 10000.)
            {           
                std::cout << patron[i].name << " : " << patron[i].amnt <<"\n";
            }
        }
    }
    else
        std::cout << "none.\n";

    std::cout << "\n";
return 0;
}