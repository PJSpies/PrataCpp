#include<iostream>
//  declare functions
void showmenu();
void carnivore();
void pianist();
void tree();
void game();

int main(){
    showmenu();
    char choice;
    std::cin >> choice;
    while (choice!='q')
    {
        switch (choice)
        {
        case 'c':  
                carnivore();
                break;
        case 'p': 
                pianist();
                break;
        case 't': 
                tree();
                break;
        case 'g': 
                game();
                break;
        default: std::cout << "Enter g, p, c, or t.  q to quit!\n";
        }
        showmenu();
        std::cin >> choice;
    }
    std::cout << "Bye.\n";

    return 0;
}
void showmenu()
{
    std::cout   << "\nChoose from menu:\n"
                << "c) carnivore    p) pianist\n"
                << "t) tree         g) game\n"
                << "q) quit\n";
}
void pianist()
{
    std::cout << "Pianist Beethoven...\n";
}
void tree()
{
    std::cout << "Tree fur\n";
}
void game()
{
    std::cout << "Game Tic-Tac-Toe\n";
}
void carnivore()
{
    std::cout << "Carnivore dog.\n";
}