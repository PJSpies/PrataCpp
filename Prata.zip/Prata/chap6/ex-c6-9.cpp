/*   Prata 6th ed, Chp.6  Exercise 6  */
#include<iostream>
#include<fstream>
#include<cstdlib>
#include<string>

struct Patron
{
    std::string name;
    double amnt;
};

int main(){
  
    std::ifstream inFile;
    inFile.open("patrons.txt");
    if (!inFile.is_open())
    {
        std::cout << "Error opening file.\n";
        exit(EXIT_FAILURE);
    }

    int num;
//    inFile >> num;  // leaves '\n' in input queue!!
//    std::getline(inFile,num,'\n'); // can't read numbers with getline.
    (inFile >> num).get();  

    Patron* patron = new Patron [num];
    
    for (int i=0; i<num;i++)
    {
          std::getline(inFile,patron[i].name);
          inFile >> patron[i].amnt;
          inFile.get();
//  put above two lines into one:
//          ( inFile >> patron[i].amnt ).get();
//      
    }
    inFile.close();

    std::cout << "\n++++++ Grand Patrons ++++++\n";
    bool gpfound {false};
    for (int i=0; i<num;i++)
    {
        if (patron[i].amnt > 10000.)
            gpfound = true;
    }
    if (gpfound)
    {
        for (int i=0; i<num;i++)
        {
            if (patron[i].amnt >= 10000.)
                std::cout << patron[i].name << " : " << patron[i].amnt <<"\n";
        }
    }
    else
        std::cout << "none.\n";

    std::cout << "\n______ Patrons ______\n";
    gpfound =false;
    for (int i=0; i<num;i++)
    {
        if (patron[i].amnt > 0. && patron[i].amnt < 10000.)
            gpfound = true;
    }
    if (gpfound)
    {
        for (int i=0; i<num;i++)
        {
            if (patron[i].amnt > 0. && patron[i].amnt < 10000.)
            {           
                std::cout << patron[i].name << " : " << patron[i].amnt <<"\n";
            }
        }
    }
    else
        std::cout << "none.\n";

    std::cout << "\n";
return 0;
}