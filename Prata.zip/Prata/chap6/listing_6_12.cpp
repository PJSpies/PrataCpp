#include<iostream>

constexpr int ArSz {80};

int main(){
    char line[ArSz];
    int spaces {0};

    std::cout << "Enter a line of text:\n";
    std::cin.get(line, ArSz);
    std::cout << "complete line:\n" << line << "\n";

    std::cout << "line through first period:\n" ;  // check each character in line
    for (int i = 0; line[i]!='\0';i++)
    {
        std::cout << line[i];
        if (line[i] =='.')
            break;          // stop at period
        if (line[i] !=' ')
            continue;       // skip space, on to next character
        spaces++;
    }    
    std::cout << "\n" << spaces << " spaces\n";
    std::cout << "done." << std::endl;

return 0;
}