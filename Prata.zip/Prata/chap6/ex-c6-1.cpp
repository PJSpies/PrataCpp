#include<iostream>
#include<cctype>

//  tricky !!   assign, else needed!

int main(){
    char ch;
    std::cin.get(ch);       //  get first character
    while (ch != '@' )      //  not the sentinel ?
    {
        if (!std::isdigit(ch))  // ignore digits
        {
            if(std::islower(ch))
                ch = std::toupper(ch);  // change to upper case letter
            else if(std::isupper(ch))   // must be 'else if' since I change upper case and the next would be true
                ch = std::tolower(ch);
            std::cout.put(ch);          // output
        }

        std::cin.get(ch);               // get next char from instream.
    }

return 0;

}