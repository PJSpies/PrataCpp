/*   Prata 6th ed.  Exercise  6.5  " Kingdom Neutronia taxes  "*/
#include<iostream>
//#include<cmath>

int main(){
    std::cout << "Enter your income in tvarps: ";
    double income;
    std::cin >> income;
    while (income > 0. && !std::cin.fail() )
    {
//        tax = 0.2*std::max(0., (income - 35000.) );
        double tax {0.};
        if (income > 5000. && income <= 15000.)
            tax = .1* (income - 5000.) ;  // max: 1000
        else if (income > 15000. && income <= 35000. )
            tax = 0.15*(income -15000.) + 1000.;  // max: 3000+1000
        else if (income > 35000)
            tax = 0.2*(income-35000.)+ 4000.; 
        std::cout << "Tax due: " << tax << std::endl;

        std::cout << "Enter your income in tvarps: ";
        std::cin >> income;
    }
    std::cout << "No income? End!\n";

return 0;
}