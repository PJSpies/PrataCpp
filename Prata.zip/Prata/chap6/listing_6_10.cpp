#include<iostream>
//  declare functions
void showmenu();
void report();
void comfort();

int main(){
    showmenu();
    int choice;
    std::cin >> choice;
    while (choice!=5)
    {
        switch (choice)
        {
        case 1: std::cout << "\a\n";
                break;
        case 2: report();
                break;
        case 3: std::cout << "Boss was in.\n";
                break;
        case 4: comfort();
                break;
        default: std::cout << "That is not a choice!\n";
        }
        showmenu();
        std::cin >> choice;
    }
    std::cout << "Bye\n";

    return 0;
}
void showmenu()
{
    std::cout   << "\nEnter 1, 2, 3, 4, or 5:\n"
                << "1) alarm    2) report\n"
                << "3) alibi    4) comfort\n"
                << "5) quit\n";
}
void report()
{
    std::cout << "Report text here...\n" "...more report text";
}
void comfort()
{
    std::cout << "Comforting text here...\n" "...more comforting text";
}