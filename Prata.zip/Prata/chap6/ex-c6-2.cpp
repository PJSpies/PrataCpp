#include<iostream>

int main(){

    constexpr int MAX=5;
    double donations[MAX];  

    int i {0};
    double sum {0};
    while (i<MAX && !std::cin.fail() )
    {
        std::cout << "Enter value #"<<i+1<< ": ";
        std::cin >> donations[i];
        sum += donations[i];
        i++;
    }
    
    if (i>0 && !std::cin.fail()) 
    {
        double avrg = sum/i;

        int cnt {0};
        for (int j=0; j< i; j++)
            if (donations[j] > avrg)
                cnt++;

        std::cout << "Total of " << i << " values entered.  Average: " << avrg << std::endl;
        std::cout << "Number of entries larger than average: " << cnt << std::endl;
    }

    std::cout << "\n";

return 0;
}