#include<iostream>
constexpr int MAX {5};

int main(){
    int golf[MAX];
    std::cout << "Enter your golf scores.\n";
    std::cout << "Yout must enter " << MAX << " rounds.\n";
    int i;
    for (i = 0; i < MAX; i++) 
    {
        std::cout << "Round #" << i+1 << ": ";
        while (!(std::cin >> golf[i]))
        {
            std::cin.clear();
            while (std::cin.get()!='\n')
            {
                continue;
            }
            std::cout << "Enter a number! ";
        }
    }
    double total {0};
    for (i=0; i<MAX; i++)
        total += golf[i];
    std::cout << "Average is: " << total / MAX << " of " << MAX << " rounds.\n";
return 0;


}