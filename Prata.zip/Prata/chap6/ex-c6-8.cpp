#include<iostream>
#include<string>
#include<fstream>

int main(){
    std::string filename;
    std::ifstream inFile;
    
    std::cout << "Enter file to read from: ";
    std::cin >> filename;
    inFile.open(filename);

    if (!inFile)
    {
        std::cout << "error reading file " << filename << "\n";
        exit(EXIT_FAILURE);
    }
    char c;
    int cnt{0};
    inFile >> c;
    while (inFile)
    {
        cnt++;
        inFile >> c;
    }
    std::cout << cnt << " characters read.\n ";
return 0;
}