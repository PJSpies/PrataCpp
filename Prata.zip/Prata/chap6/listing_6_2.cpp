#include<iostream>

int main(){
    using namespace std;
    char c;

    cout << "enter character:\n ";
    cin.get(c);
    while (c != ' ')
    {
        if (c == '\n')
            cout << c;
        else
            cout << ++c;
        cin.get(c);
    }
    cout << "\nprogram ends." << endl;
    return 0;
}   
