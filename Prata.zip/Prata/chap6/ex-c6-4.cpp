#include<iostream>
//  declare functions
void showmenu();

int main(){
    constexpr int strsz=20;
    struct bop{
        char fullname[strsz];
        char bopname[strsz];
        char title[strsz];
        int preference;
    };

    constexpr int MSZ=5;
    bop* members = new bop[MSZ] {
        {"Freddy", "The Hack", "CIO", 0},
        {"Charlie", "Typo", "CEO", 2},
        {"John", "Loopy", "Snr Mgr", 1},
        {"Jacky", "While", "Snr Director", 3}
    };

    showmenu();
    char choice;
    std::cin >> choice;
    while (choice!='q')
    {
        switch (choice)
        {
        case 'a':  
                for (int i=0; i< MSZ; i++)
                    std::cout << members[i].fullname << "\n";
                break;
        case 'b': 
                for (int i=0; i< MSZ; i++)
                    std::cout << members[i].bopname << "\n";
                break;
        case 'c': 
                for (int i=0; i< MSZ; i++)
                    std::cout << members[i].title << "\n";
                break;
        case 'd': 
                for (int i=0; i< MSZ; i++)
                {
                    switch (members[i].preference)
                    {
                    case 0:
                        std::cout << members[i].fullname<< "\n";
                        break;
                    case 1:
                        std::cout << members[i].bopname<< "\n";
                        break;
                    case 2:
                        std::cout << members[i].title<< "\n";
                        break;

                    default:
                        std::cout << members[i].fullname << ": preference flawed!!\n";
                        break;
                    } 
                }
                break;
        default: std::cout << "Enter a, b, c, or d.  q to quit!\n";
        }
        showmenu();
        std::cin >> choice;
    }
    std::cout << "Bye.\n";
    delete [] members;
    return 0;
}
void showmenu()
{
    std::cout   << "\nDisplay members by...:\n"
                << "a) name    b) bop name\n"
                << "c) title   d) display preference\n"
                << "q) quit\n";
}