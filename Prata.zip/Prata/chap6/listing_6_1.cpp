#include<iostream>
#include <string>
#include<fstream>
std::ofstream fout; std::ifstream fin;

int main(){
    std::string file1 {"myfile.txt"};
    fout.open(file1);
    fout << "this is a line of text in file " << file1;
    int a {256};
    fout << "\n" << a<< std::endl ;
    fout.close();
//  now open a different file 
    fout.open("other.txt");
    fout << "this is also a line of text.";
    int b {128};
    double pi {3.14159};
    fout << "\nb: " << b << "  pi: " << pi<< std::endl ;
    fout.close();
//  using a C-style string.
    char f[10];
    std::cout << "Enter third file's name: ";
    std::cin >> f;
    fout.open(f);
    fout << "this is a third file with its line of text.";
    float c {1024};
    fout << "\n:c " << c << std::endl ;
    fout.close();

//  reading files
    fin.open(file1);
    if (!fin.is_open())
    {
        std::cout << "ERR - could not open file! ";   
        exit (EXIT_FAILURE);
    };
    std::cout << "Reading from file " << file1 << std::endl;
    char line[80];
    int i {1};
    while (fin.good())
    {
        fin.getline(line, 81);
        std::cout << i << ": " << line <<std::endl;
        i++;
    }
    fin.close();


return 0;
}