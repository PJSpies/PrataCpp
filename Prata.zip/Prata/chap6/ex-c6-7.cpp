#include<iostream>
#include<string>
#include<cctype>

int main(){

std::string word;
int other {0};
int vowels {0};
int consonants {0};

std::cout << "Enter words, finish with \' q \':\n";
do
{
    std::cin >> word;
/*  Here fairly elaborate if statements */
    
    if (   word[0] == 'a' || word[0] == 'A'
        || word[0] == 'e' || word[0] == 'E'
        || word[0] == 'i' || word[0] == 'I'
        || word[0] == 'o' || word[0] == 'O'
        || word[0] == 'u' || word[0] == 'U'
        )
        vowels++;
    else if (std::isalpha(word[0]))
    {
        consonants++;
    }
    else 
        other++;
    
}
while (word != "q"); 

std::cout << "words starting with vowel     : " << vowels <<"\n";
std::cout << "words starting with consonants: " << consonants-1 <<" (w/o \'q\') \n";  // subtract 1 for entered 'q' 
std::cout << "other words entered           : " << other  <<"\n";


return 0;
}