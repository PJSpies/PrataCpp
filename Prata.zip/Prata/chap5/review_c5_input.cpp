
/*  Input checks Chapter 5  Review section  */
#include<iostream>
int main(){

   std::cout << "Enter characters; ^D to quit:\n" ;
   int count {0};
   int c;   //  don't read before while
   c = std::cin.get();
   while ( c != EOF && c != '\10')
   {
      std::cout.put(c);
      if(c!='\n') ++count;
      c = std::cin.get();
   };
   std::cout << "\n" << count << " character(s) read.\n" << std::endl;
   std::cin.clear();

return 0;
}