/*
  Review Chapter 5,  Prata 6th ed.

*/
#include<ctime>
#include<iostream>

int main(){

//std::cout << "enter delay time (sec): " << std::endl;
float secs {3}; 
//std::cin >> secs;

std::cout << CLOCKS_PER_SEC <<"\n";
clock_t delay = secs * CLOCKS_PER_SEC;  // 3 Millionen

clock_t start = clock();
std::cout << "started waiting at " << start <<" cycles.\n"; 
while (clock() - start < delay)
{
    if ( (clock()-start) % CLOCKS_PER_SEC  ==  0)
        std::cout << (clock()-start) / CLOCKS_PER_SEC << " " <<std::flush ;
    ;
}
std::cout << ""<< std::endl;
std::cout << "Done waiting, stopped at " << clock()<< " cycles" << std::endl;

//  this version convert clock to seconds within the while loop. (time consuming, but doesn't matter here)
int s {0};
int sold {0};
clock_t start1 = clock();
while (s < secs)   
{
    s = int( (clock() - start1) / CLOCKS_PER_SEC );
    if ( s > sold ) 
    {
        std::cout << s << " " <<std::flush ;
        sold = s;
    }
    ;
}
std::cout << ""<< std::endl;
std::cout << "Done waiting, stopped at " << clock()<< " cycles" << std::endl;

//  A do-while loop for trials
std::cout <<" A do-while loop for trials:" << std::endl;
int n {10};
do {
   std::cout << n << "\t " ;
   n--;
} while(0<=n);
std::cout << "\n\n";
//std::cout << " \r";

/* 
  A range-based for loop with real 
*/
float data[5] {1.2, 2.3, 3.4, 4.5, 5.6};
for (float &x : data) 
    std::cout << " " << x * 0.1;
std::cout << "\n";



clock_t stop = clock();
std::cout << "The program ran for " << (stop-start) / CLOCKS_PER_SEC <<"s"<< (stop-start) % CLOCKS_PER_SEC << "ms" << std::endl;
return 0;
}