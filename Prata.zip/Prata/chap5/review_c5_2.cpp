/*
   more trials from chapter 5, Prata 6th ed.
*/
#include<iostream>
#include<cmath>

int main(){
/*  Question #8 
   comma operator: sequence of assignments. The last one sticks. 
*/
    int i = (1, 11, 12);  // i == 12
/*  Here '1' gets assigned, then follows a true statement '2345' without effect.  */
    i = 1,2345;           // i == 1

/*  Question #5  ... never loops, prints k once */
   int k {8};
   do
   {
      std::cout << " k: " << k << std::endl;
   } while ( k++ < 5);
   
/*  Question #4  increments j and checks against 9, then increments j and prints. Two loops print 7 and 9 */
   int j {5};
   while (++j<9)
   {
      std::cout << "++j= " << ++j << std::endl; 
   }
/*  Question #6  */
   for (int n = 0; n != 3; n++)   //  beware: test condition must be true for loop to run.
      std::cout << n << std::endl;//  instead of n==3 (end condition) must use n!=3 'as long as this is true'

   for (int n = 0; n < 7; n++)
      std::cout << pow(2,n) << std::endl;
   
   for (int n = 1; n < 65; n*=2)
      std::cout << n << std::endl;


return 0;
}