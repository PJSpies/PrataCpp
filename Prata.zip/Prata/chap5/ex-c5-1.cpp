/*   Exercises from Prata 6th ed. (not 5th!) , Chapter 5,  page 251  */

#include<iostream>
#include<array>

int main()
{
/*  exercise #1   */
std::cout << "Summing integers between [a, b].\nEnter a, then b: " << std::endl;
int a {2}; int b {9};
int s {0};
//std::cin >> a;
//std::cin >> b;
for (int i = a; i <=b; i++)
    s = s + i;
std::cout << "sum of integers between " << a << " and " << b << " is: " << s << std::endl;

/*  exercise #2   Factorials  using array object and long double */

constexpr int sz = 5;
int num = sz -1 ; 
std::array<long double, sz> factorial;  // I need size one larger than num, because array size includes index 0 for 0!.
factorial[0] = 1;
int i;
for (i =1; i <= num; i++)
    factorial[i] = factorial[i-1] * i; 
std::cout << "Fakultät "<< num << "! = " << factorial[num] << "\n"; 

/*  Exercise #3  */
int sum {0};
std::cout << "enter chars:\t" << std::endl;
char ch;
//std::cin.get(ch);
while ( (ch=std::cin.get()) != '0' && ch != '\n')  // exclude CR from input and '0' which terminates pgm
{
    sum += int(ch)-48;   //  convert char to integer (subtract 48) and add up 
    std::cout << "sum: " << sum  << "\n\t";
    ch=std::cin.get();
}
//std::cout << "Total is: " << sum << "\n";
std::cout << "\n";
// */
/* The best approach 
std::cout << "enter numbers, end with 0:\t" << std::endl;
int sum = 0;
std::cout << "sum: " << sum  << "\n\t";
std::cin >> i;
while ( i != 0 )
{
    sum += i;  
    std::cout << "sum: " << sum  << "\t";
    std::cin >> i;
}
*/

/*  Exercise #4   interest rates comparison  */
//  simple interest  10%   versus  compound interest 5%  on  $100
//  simple:   100, 110, 120, ...  = $100 + n * $10
//  compound: 100, 105, 110.25 ... = $100*(1.05)^n
//  When is  compound larger than simple?
float simple {100.};
float compound {100.};
int year {0}; 
do 
{
    ++year;
    simple += 10;
    compound += .05*compound;
    std::cout << "year: " << year << " simple: " << simple << " compound: " << compound << "\n";
}
while (compound < simple);
std::cout << std::endl;

/*  Exercise #5  Enter integers, store in an array, sum total  */
const char* month[12] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};

int books[12];  // monthly sales (No. of books)
i = 1;  // counter for array
std::cout << "Enter books sold per month:\n" << std::endl;
int bookstotal {0};
while ( i <= 12 )  //  no  Cntrl-D checked. No sum calculated.
{
    std::cout << month[i-1] << ": " ;
    std::cin >> books[i-1];
    bookstotal += books[i-1];
    i++;
}
std::cout << std::endl;
for (int i = 0; i <= 11; i++)
    std::cout << books[i] <<", " ; 
std::cout <<"\nBooks sold this year: " << bookstotal << std::endl;

/*   re-set for following do-loop trial:  */
for (int i = 0; i <= 11; i++)
    books[i] = 0;
bookstotal = 0;

i=1;
do 
{
    std::cout << month[i-1] << ": " ;
    std::cin >> books[i-1];
    bookstotal += books[i-1];
    i++;
}
while (std::cin.get()!=EOF && i <= 12);  //  I can CTRL-D to stop entering, books entered are kept.

std::cout << std::endl;
for (int i = 0; i <= 11; i++)
    std::cout << books[i] <<", " ;
std::cout <<"\nBooks sold this year: " << bookstotal << std::endl;

return 0;
}