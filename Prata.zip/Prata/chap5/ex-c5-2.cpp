/*   Exercises from Prata 6th ed. (not 5th!) , Chapter 5,  page 251  */

#include<iostream>
#include<array>
#include<string>

int main()
{
/*  
    Exercise #6   2-D array for 3 years , sum per year, sum total
*/
const char* month[12] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
int mybooks[12][3];  //  12 months, 3 years

for (int i = 0; i < 12; i++)
    for (int j = 0; j < 3; j++)
        mybooks[i][j] = i+j*12;   //  books per month
int bookstotal {0};

/*  display table  */
for (int i=0; i<12; i++)
    std::cout << month[i] <<"\t";    //  table header: months
std::cout << "Total\n";

int sales, total;
total =0;
for (int j=0; j<3;j++)
{
    sales = 0;
    for (int i=0; i<12; i++)
    {
        sales += mybooks[i][j];
        std::cout << mybooks[i][j] << "\t";
    };
    std::cout << sales << "\n";
    total += sales;
};
std::cout <<"Grand Total: " << total << std::endl;

/*   
    Exercise  7  array of struct in Heap.
*/
struct car {
    std::string make;
    int year; 
};

int i, qnty;
std::cout <<"How many cars to catalog? "; 
(std::cin >> qnty).get();
// ---  std::cin >> num;

car *collection = new car[qnty];

i= 0;
do
{
// ---   std::cin.get(); //  eat the last <CR>  is needed, but why?
    std::cout << "Car #" << i+1<< ":\nMake:";
// ---   std::cin >> autos[i].make;    cin doesn't take white space
    std::getline(std::cin,collection[i].make); 

    std::cout << "year:";
// ---   std::cin >> autos[i].year;
    (std::cin >> collection[i].year).get();
    std::cout << "\n";
    i++;
} while (i < qnty);

for (int i = 0; i < qnty; i++)
    std::cout << collection[i].year << "  " << collection[i].make << "\n";

delete [] collection;

return 0;
} 