/*   Exercises from Prata 6th ed. (not 5th!) , Chapter 5,  page 251  */

#include<iostream>
#include<array>
#include<cstring>
#include<sstream> 
#include<string>  

int main(){

/*  Exercise  #9  */
std::string word;
int wc {0};

std::cout << "Enter words, finish with \'done\':\n";
do
{
    std::cin >> word;
    wc++;
}
while (word != "done"); 
std::cout << "words entered: " << wc-1 <<"\n";

/*  Exercise  #8 */
/*
std::string sentinel {"done"};
constexpr int SZ {strlen(sentinel)+1};
char wort[std::max(20, SZ)];
*/
char wort[100];
wc = 0;
std::cout << "Gib Wörter, beende mit \'done\':\n";

do
{
    std::cin >> wort;  //  funktioniert nur wenn wort[] ausreichend gross ist.
    wc++;
}
while ( std::strcmp(wort,"done") != 0 );

std::cout << "words entered: " << wc-1 <<"\n";

/* 
    Exercise 10 
        ask for No. of rows, display first with one * , next with 2,... fille preceeding chars with '.'
*/

std::cout << "Enter No. of rows: " << std::endl;
int rows;
std::cin >> rows;
char str[rows+1] ;

for (int i=0; i < rows; i++)
{
    int j;
    for (j = 0; j < rows-i-1; j++)
    {
        str[j] = '.';
    }
    int k ;
    for (k = j; k < rows; k++)
        str[k] = '*';
    str[k] = '\0';
    std::cout << str << "\n";
}    
return 0;
}