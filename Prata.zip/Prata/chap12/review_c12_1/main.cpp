/*
 * main.cpp
 *
 *  Created on: 15.03.2024
 *      Author: peter
 */

class S
{
private:
  char *str;
  int len;
public:
  S()
  {/**/
  }
};

int main()
{
  S s;
}

