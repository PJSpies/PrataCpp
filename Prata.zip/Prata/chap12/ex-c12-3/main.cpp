/*
 * main.cpp
 *
 *  Created on: 15.03.2024
 *      Author: peter
 */

#include <iostream>
#include "stock1.h"

int main(int argc, char **argv)
{
  using std::cout;
  using std::ios_base;
  cout.precision(2);   // format #.##
  cout.setf(ios_base::fixed, ios_base::floatfield);  // format #.##
  cout.setf(ios_base::showpoint);  // format #.##

  Stock Eins = Stock("Erste Firma", 10, 1000.);
  Stock Zwei = Stock("Zweite Firma", 20, 1000.);
  Stock Drei = Stock("Dritte Firma", 30, 1500.);
  Stock Vier = Stock("Vierte Firma", 40, 100.);

  const int STOCKS {4};
  Stock stocks[STOCKS] {Eins, Zwei, Drei, Vier};  // temporary rvalue Stock objects are assigned (and deleted).

  for (int i {0}; i < STOCKS; i++)
	std::cout << stocks[i];
  Stock topstock = stocks[0];
  for (int i {0}; i < STOCKS; i++)
	topstock = topstock.topval(stocks[i]);
  cout << "most valuable holding: " << topstock;

  return 0;
}
