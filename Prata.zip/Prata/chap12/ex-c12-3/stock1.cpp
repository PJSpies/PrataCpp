/*
 * stock1.cpp
 *
 *  Created on: 02.03.2024
 *      Author: peter
 */

#include <iostream>
#include "stock1.h"   //  class definition
#include <cstring>    //  strcpy()  and strncpy()

Stock::Stock()
{
  std::cout << "default constructor called\n";

  company = new char[1];
  company[0] = '\0';
  shares = 0;
  share_val = 0.0;
  total_val = 0.0;
}

Stock::Stock(const char *co, int n, double pr)
{
  std::cout << "Constructor for " << co << " called\n";
  int len = std::strlen(co);
  company = new char[len + 1];
  std::strcpy(company, co);

  if (n < 0)
  {
	std::cerr << "Number of shares cannot be negative! " << company << " shares set to 0.\n";
	shares = 0;
  }
  else
	shares = n;

  share_val = pr;
  set_total();
}
/*  I need the copy constructor for placing stock object into an array of stock objects. Otherwise delete[] company name won't work*/
Stock::Stock(const Stock &s)
{
  int len = std::strlen(s.company);
  company = new char[len + 1];
  shares = s.shares;
  share_val = s.share_val;
  total_val = s.total_val;
}

Stock& Stock::operator=(const Stock &s)
{
  if (this == &s) return *this;
  delete[] company;
  int len = std::strlen(s.company);
  company = new char[len + 1];
  std::strcpy(company, s.company);
  return *this;
}

Stock::~Stock()    //  destructor
{
  std::cout << "Bye, " << company << "!\n";
  delete[] company;
}

void Stock::buy(int num, double price)
{
  if (num < 0)
  {
	std::cerr << "Number of shares cannot be negative! Abort.";
  }
  else
  {
	shares += num;
	share_val = price;
	set_total();
  }
}

void Stock::sell(int num, double price)
{
  using std::cerr;
  if (num < 0)
  {
	cerr << "Number of shares sold cannot be negative. Abort.";
  }
  else if (num > shares)
  {
	cerr << "cannot sell more than you have! Abort.";
  }
  else
  {
	shares -= num;
	share_val = price;
	set_total();
  }
}

void Stock::update(double price)
{
  share_val = price;
  set_total();
}

/*
 void Stock::show()
 {
 using std::cout;
 using std::endl;
 cout << "Company: " << company << " Shares: " << shares << " Share price: " << share_val << " Total: " << total_val
 << endl;
 }
 */

std::ostream& operator<<(std::ostream &os, const Stock &s)
{
  using std::cout;
  using std::endl;
  os << "Company: " << s.company << " Shares: " << s.shares << " Share price: " << s.share_val << " Total: " << s.total_val << endl;
  return os;
}

const Stock& Stock::topval(const Stock &s) const
{
  if (s.total_val > total_val)   //  total_val is member of the invoking object,  s.total_val is explicit (argument to the function)
	return s;  //  explicit object s
  else
	return *this;  // invoking object '*this'  ('this' is the pointer)
}
