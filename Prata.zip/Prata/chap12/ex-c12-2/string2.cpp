/*
 * string2.cpp
 *
 *  Created on: 14.03.2024
 *      Author: peter
 */
#include "string2.h"

#include <iostream>
#include <cstring>
#include <cctype>
using std::cin;
using std::cout;

//  Initializing static class member

int String::num_strings = 0;

//  static method
int String::HowMany()
{
  return num_strings;
}

//  class methods

String::String(const char *s)
{
  len = std::strlen(s);
  str = new char[len + 1];
  std::strcpy(str, s);
  num_strings++;
}

String::String()
{
  len = 4;
  str = new char[1];
//  str[0]='\0';        //  try also  nullptr.
  str = nullptr;
  num_strings++;
}

String::String(const String &st)
{
  num_strings++;
  len = st.len;
  str = new char[len + 1];
  std::strcpy(str, st.str);
}

String::~String()
{
  --num_strings;
  delete[] str;
}

//  overloaded operator methods

String& String::operator=(const String &st)
{
  if (this == &st) return *this;
  delete[] str;
  len = st.len;
  str = new char[len + 1];
  std::strcpy(str, st.str);
  return *this;
}
String& String::operator=(const char *s)
{
  delete[] str;
  len = std::strlen(s);
  str = new char[len + 1];
  std::strcpy(str, s);
  return *this;
}

String& String::operator+(const String &s)
{
  len += s.len;
  char *temp = new char[len + 1];
  std::strncpy(temp, str, len);
//  len += s.len;
  std::strcat(temp, s.str);
  str = temp;
  return *this;
}

//friend?
String operator+(const String &s, const String &st)
{
  String newstring;
  newstring.len = s.len + st.len;
  char *temp = new char[newstring.len + 1];
  std::strncpy(temp, s.str, s.len);

  std::strcat(temp, st.str);
  newstring.str = temp;
  return newstring;
}

int String::has(char c)
{
  int count = 0;
  for (int i = 0; i < len; i++)
	if (str[i] == c) count++;
  return count;
}

String& String::stringup()
{
  for (int i = 0; i < len; i++)
	str[i] = std::toupper(str[i]);

  return *this;
}

String& String::stringlow()
{
  for (int i = 0; i < len; i++)
	str[i] = std::tolower(str[i]);

  return *this;
}

char& String::operator[](int i)
{
  return str[i];
}

const char& String::operator[](int i) const
{
  return str[i];
}
// overloaded operator friends
bool operator<(const String &st1, const String &st2)
{
  return (std::strcmp(st1.str, st2.str) < 0);
}
bool operator>(const String &st1, const String &st2)
{
  return (std::strcmp(st2.str, st1.str) < 0);
}
bool operator==(const String &st1, const String &st2)
{
  return (std::strcmp(st1.str, st2.str) == 0);
}

//simple string output
std::ostream& operator<<(std::ostream &os, const String &st)
{
  os << st.str;
  return os;
}

std::istream& operator>>(std::istream &is, String &st)
{
  char temp[String::CINLIM];
  is.get(temp, String::CINLIM);
  if (is) st = temp;
  while (is && is.get() != '\n')
	continue;
  return is;
}

