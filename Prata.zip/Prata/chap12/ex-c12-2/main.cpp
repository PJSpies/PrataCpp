/*
 * main.cpp
 *
 *  Created on: 16.03.2024
 *      Author: peter
 */
#include <iostream>
#include "string2.h"
using namespace std;
int main()
{
  String s1("kleiner Test");
  String s2(" -- Test zweiter Teil\n");
  String s3 = s1 + s2;
  std::cout << s3 << std::endl;

  cout << s2; // overloaded << operator
  cout << "enter your name:\n";
  cin >> s3; // overloaded >> operator

  s2 = "My name is " + s3; // overloaded =, + operators
  cout << s2 << ".\n";

  s2 = s2 + s1;
  s2.stringup(); // converts string to uppercase
  cout << s2; // overloaded << operator

  cout << "The string\n" << s2 << "\ncontains " << s2.has('A') << " 'A' characters in it.\n";

  // then String & operator=(const String&)
  s1 = "red"; // String(const char *),
  String rgb[3] = {String(s1), String("green"), String("blue")};
  cout << "Enter the name of a primary color for mixing light: ";
  String ans;
  bool success = false;
  while (cin >> ans)
  {
	ans.stringlow(); // converts string to lowercase
	for (int i = 0; i < 3; i++)
	{
	  if (ans == rgb[i]) // overloaded == operator
	  {
		cout << "That's right!\n";
		success = true;
		break;
	  }
	}
	if (success)
	  break;
	else
	  cout << "try again\n";
  }
  cout << "bye.\n";
  return 0;
}
