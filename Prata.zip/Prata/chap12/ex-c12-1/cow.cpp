/*
 * cow.cpp
 *
 *  Created on: 16.03.2024
 *      Author: peter
 */
#include <iostream>
#include <cstring>
#include "cow.h"

Cow::Cow()
{
  name[0] = '\0';
  hobby = new char[1];
  hobby[0] = '\0';
  weight = 0.;
  std::cout << "entity for a cow created\n";
}

Cow::~Cow()
{
//  delete name;   NO!
  delete[] hobby;
  std::cout << "Cow " << name << " deleted" << std::endl;
}

Cow::Cow(const char *nm, const char *ho, double wt)
{
  int len;
  len = std::strlen(nm);
  std::strncpy(name, nm, len);
  name[len] = '\0';

  len = std::strlen(ho);
  hobby = new char[len];
  std::strncpy(hobby, ho, len);

  weight = wt;

  std::cout << " created cow " << name << std::endl;
}

//  copy constructor?
Cow::Cow(const Cow &c)
{
  int len;
  len = std::strlen(c.name);
  std::strncpy(name, c.name, len);
  name[len] = '\0';

  len = std::strlen(c.hobby);
  hobby = new char[len];
  std::strncpy(hobby, c.hobby, len);
  hobby[len] = '\0';

  weight = c.weight;
  std::cout << " copied cow " << name << " to " << c.name << std::endl;
}
// assignment operator
Cow& Cow::operator=(const Cow &c)
{
  if (this == &c) return *this;
//  delete[] name;  NO!
  int len = std::strlen(c.name);
//  name = new char[len];    NO!
  std::strncpy(name, c.name, len);
  name[len] = '\0';

  delete[] hobby;
  len = std::strlen(c.hobby);
  hobby = new char[len];        //   hier ist noch etwas falsch
  std::strncpy(hobby, c.hobby, len);  // c.hobby ist länger als hobby ...
  hobby[len] = '\0';

  weight = c.weight;
  std::cout << " assigned cow " << c.name << " to " << name << std::endl;
  return *this;
}
void Cow::ShowCow() const
{
  std::cout << "Cow " << name << ", Hobby " << hobby << ", weight " << weight << std::endl;
}
