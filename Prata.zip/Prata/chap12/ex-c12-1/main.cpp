/*
 * main.cpp
 *
 *  Created on: 16.03.2024
 *      Author: peter
 */

#include <iostream>
#include "cow.h"

int main(int argc, char **argv)
{
  {
	Cow c {"Berta", "sleep", 300.};
	c.ShowCow();
	Cow b("Susi", "chew", 240.);
	b.ShowCow();
	c = b;
	c.ShowCow();
	Cow d = Cow(c);
	d.ShowCow();
  }
  Cow e;

}

