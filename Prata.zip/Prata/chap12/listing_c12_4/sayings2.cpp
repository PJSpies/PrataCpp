/*
 * sayings2.cpp
 *
 *  Created on: 15.03.2024
 *      Author: peter
 */
#include <iostream>
#include <cstdlib>
#include <ctime>

#include "string1.h"
const int ArSize { 10 };
const int MaxLen { 81 };

int main(int argc, char **argv)
{
  using std::cout;
  using std::cin;
  using std::endl;
  String name;

  cout << "Enter name: \n";
  cin >> name;

  cout << name << ", enter up to " << ArSize << " text lines. (empty line to quit):\n";
  String sayings[ArSize];
  char temp[MaxLen];
  int i;
  for (i = 0; i < ArSize; i++)
  {
	cout << i + 1 << ": ";
	cin.get(temp, MaxLen);
	while (cin && cin.get() != '\n')
	  continue;
	if (!cin || temp[0] == '\0')   //  empty line?
	  break;
	else
	  sayings[i] = temp;
  }
  int total = i;

  if (total > 0)
  {

	cout << " You entered: \n";
	for (i = 0; i < total; i++)
	  cout << sayings[i][0] << ": " << sayings[i] << endl;

	String *shortest = &sayings[0];
	String *first = &sayings[0];

	for (i = 0; i < total; i++)
	{
	  if (sayings[i] < *first) first = &sayings[i];
	  if (sayings[i].length() < shortest->length()) shortest = &sayings[i];
	}

	cout << "Shortest text:\n" << *shortest << endl;
	cout << "First alphabetically:\n" << *first << endl;
	cout << "This program used " << String::HowMany() << " String objects. Ciao." << endl;

	srand(time(0));
	int choice = rand() % total;
	String *favorite = new String(sayings[choice]);
	cout << "Favourite text:\n" << *favorite << endl;
	delete favorite;
	return 0;
  }
  else
	cout << "nothing entered?!\n";
  cout << "Ciao.\n";
}
