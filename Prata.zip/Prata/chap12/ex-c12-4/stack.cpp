/*
 * stack.cpp
 *
 *  Created on: 18.03.2024
 *      Author: peter
 */
#include <iostream>
#include "stack.h"

Stack::Stack(int n)
{
  pitems = new Item[n];
  size = 0;
  top = 0;
}
Stack::Stack(const Stack &s)
{
  size = s.size;
  top = s.top;
  pitems = new Item[s.size];
  for (int i = 0; i < s.size; i++)
	pitems[i] = s.pitems[i];

  std::cout << "Stack copied with copy constructor. size= " << size << std::endl;
}
Stack::~Stack()
{
  delete[] pitems;
  std::cout << "Stack deleted. " << std::endl;
}

bool Stack::isempty() const
{
  return top == 0;
}
bool Stack::isfull() const
{
  return top == MAX;
}

bool Stack::push(const Item &item)
{
  if (top < MAX)
  {
	pitems[top++] = item;
	size++;
	return true;
  }
  else
	return false;
}
bool Stack::pop(Item &item)
{
  if (top > 0)
  {
	item = pitems[--top];
	pitems[top] = 0;
	size--;
	return true;
  }
  else
	return false;
}
Stack& Stack::operator=(const Stack &s)
{
  if (this == &s) return *this;
  size = s.size;
  top = s.top;
  delete[] pitems;
  pitems = new Item[MAX];
  for (int i = 0; i < s.size; i++)
	pitems[i] = s.pitems[i];
  return *this;
}

std::ostream& operator<<(std::ostream &os, Stack &s)
{
  std::cout << "-------- STACK ------\n";
  for (int i = 0; i < s.size; i++)
	os << "pos: " << i << " item: " << s.pitems[i] << "  top= " << s.top << std::endl;

  return os;
}
