/*
 * stack.h
 *
 *  Created on: 18.03.2024
 *      Author: peter
 */

#ifndef STACK_H_
#define STACK_H_
#include <iostream>
typedef unsigned long Item;

class Stack
{
private:
  static int const MAX {3};
  Item *pitems;
  int size;
  int top;
public:
  Stack(int n = MAX);
  Stack(const Stack &s);
  ~Stack();
  bool isempty() const;
  bool isfull() const;

  bool push(const Item &item);
  bool pop(Item &item);
  Stack& operator=(const Stack &s);
  friend std::ostream& operator<<(std::ostream &os, Stack &s);
};

#endif /* STACK_H_ */
