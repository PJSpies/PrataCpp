/*
 * main.cpp
 *
 *  Created on: 18.03.2024
 *      Author: peter
 */

#include <iostream>
#include "stack.h"
int main(int argc, char **argv)
{
  Stack stack(5);
  Stack stack1 = Stack(stack);

  Item eins {1};
  Item zwei {22};
  Item drei {333};

  stack.push(eins);
  stack.push(zwei);
  stack.push(drei);
  stack.push(4444);
  stack1 = stack;   //  assignment operator works
  std::cout << stack1 << " + + + + + + +\n";

  Stack (stack2);  // empty new stack works
  std::cout << stack2 << stack1;

  Stack stack3 = Stack(stack1);
  std::cout << stack3;

  Item i;
  stack.pop(i);
  std::cout << "popped item " << i << "  stack now: \n";
  std::cout << stack << "- - - - - - -\n";
  if (stack.push(zwei))
  {
	std::cout << "pushed zwei " << "  stack now: \n";
	std::cout << stack << "- - - - - - -\n";
  }
  if (stack.push(zwei))
  {
	std::cout << "pushed zwei " << "  stack now: \n";
	std::cout << stack << "- - - - - - -\n";
  }
  else
	std::cout << " *** STACK FULL! *** \n";
  stack.pop(i);
  std::cout << "popped item " << i << "  stack now: \n";
  std::cout << stack << "- - - - - - -\n";
  stack.pop(i);
  std::cout << "popped item " << i << "  stack now: \n";
  std::cout << stack << "- - - - - - -\n";
  if (stack.pop(i))
  {
	std::cout << "popped item " << i << "  stack now: \n";
	std::cout << stack << "- - - - - - -\n";
  }
  else
	std::cout << " stack already empty";
  stack.pop(i);

  return 0;
}
