/*
 * list.h
 *
 *  Created on: 06.03.2024
 *      Author: peter
 */

#ifndef LIST_H_
#define LIST_H_

typedef unsigned short Item;
static const int LIST_SIZE { 10 };

class List
{
private:
  Item items[LIST_SIZE];
  int top;  // first free place in list
public:
  List();
  bool add(const Item &i);
  void select(int i);
  bool is_empty();
  bool is_full();
  void visit(void (*pf)(Item&));  //  use function pf on ALL items in the list!
};

#endif /* LIST_H_ */
