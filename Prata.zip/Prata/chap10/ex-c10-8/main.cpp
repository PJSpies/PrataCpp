/*
 * main.cpp
 *
 *  Created on: 06.03.2024
 *      Author: peter
 */
#include <iostream>
#include "list.h"

void fc(Item &it);
void func(Item &it);

int main()
{
  List liste;
  Item myitem { 1 };

  liste.visit(fc);  //  use func() on all list items.
  liste.add(myitem);
  liste.add(2);
  liste.add(4);
  liste.add(8);
  liste.add(16);

  for (int j { 0 }; j < LIST_SIZE; j++)
	liste.select(j); // Shows list element No. 'index'

  std::cout << std::endl;
  liste.visit(func);  //  use func() on all list items.

  return 0;
}

void fc(Item &it)
{
  it = 0;
}
void func(Item &it)
{
  std::cout << it * 2 << std::endl;
}
