/*
 * list.cpp
 *
 *  Created on: 06.03.2024
 *      Author: peter
 */
#include <iostream>
#include "list.h"
List::List() // create an empty list
{
  top = 0;
}
bool List::add(const Item &i)
{
  if (top < LIST_SIZE)
  {
	items[top++] = i;
	return true;
  }
  else
	return false;
}

void List::select(int i)
{
  std::cout << "selected item[" << i << "] " << items[i] << std::endl;
}

bool List::is_empty()
{
  return top == 0;
}
bool List::is_full()
{
  return top == LIST_SIZE;
}
void List::visit(void (*pf)(Item&))   //  use function pf on ALL items in the list!
{
  for (int i { 0 }; i < LIST_SIZE; i++)
  {
	pf(items[i]);
  }
}
