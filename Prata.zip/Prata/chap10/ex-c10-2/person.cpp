/*
 * person.cpp
 *
 *  Created on: 03.03.2024
 *      Author: peter
 */

#include <iostream>
#include <cstring>
#include "person.h"

Person::Person()
{
  lname = "<surname>";
  fname[0] = '\0';
} // #1

/*
 Person::Person(const std::string &ln)  //  default first name
 {
 lname = ln;
 strcpy(fname, "Heyyou");
 }
 */
Person::Person(const std::string &ln, const char *fn)  //  default first name is defined in header!!
{
  lname = ln;
  strcpy(fname, fn);
  fname[LIMIT - 1] = '\0';
}

Person::~Person()
{
  ;
}

void Person::Show()
{
  std::cout << fname << " " << lname << std::endl;
}
;
void Person::FormalShow()
{
  std::cout << lname << ", " << fname << std::endl;
}
