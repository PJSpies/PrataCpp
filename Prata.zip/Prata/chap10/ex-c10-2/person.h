/*
 * person.h
 *
 *  Created on: 03.03.2024
 *      Author: peter
 */

#ifndef PERSON_H_
#define PERSON_H_

#include <string>
class Person
{
private:
  static int const LIMIT = 25;
  std::string lname; // Person's last name
  char fname[LIMIT]; // Person's first name

public:
  Person();   //  #1 default constructor.
//  Person(const std::string &ln);  // #2
  Person(const std::string &ln, const char *fn = "Heyyou");  // #3
  ~Person();

  void Show();       // firstname lastname format
  void FormalShow(); // lastname, firstname format
};

#endif /* PERSON_H_ */
