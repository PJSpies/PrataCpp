/*
 * main.cpp
 *
 *  Created on: 03.03.2024
 *      Author: peter
 */

#include <iostream>
#include "person.h"

int main()
{
  Person one;  //  invokes default constructor with empty last name=<surname>.
  one.Show();
  one.FormalShow();
  Person two {"Spies"};   // iniitialises with single-argument constructor.
  two.Show();
  two.FormalShow();
  Person zwei("Testname");   //  calls constructor explicitly
  zwei.Show();
  zwei.FormalShow();
  Person three {"Spies", "Eva"};
  three.FormalShow();
  three.Show();

}

