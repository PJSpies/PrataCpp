/*
 * main.cpp
 *
 *  Created on: 02.03.2024
 *      Author: peter
 */

#include <iostream>
#include "stock1.h"

int main(int argc, char **argv)
{
  using std::cout;
  using std::ios_base;
  cout.precision(2);   // format #.##
  cout.setf(ios_base::fixed, ios_base::floatfield);  // format #.##
  cout.setf(ios_base::showpoint);  // format #.##
	  /*
	   * these lines were first version, only two objects, filled and tested.
	   *
	   cout << "using constructors \n";
	   Stock s1("NanoSmart", 12, 20.0);
	   s1.show();

	   Stock s2 = Stock {"NewCo", -1};
	   s2.show();
	   s2 = s1;
	   s2.show();
	   */
  const int STOCKS {4};
  Stock stocks[STOCKS] {
	  Stock("Erste Firma", 10, 1000.),
	  Stock("Zweite Firma", 20, 1000.),
	  Stock("Dritte Firma", 30, 1500.),
	  Stock("Vierte Firma", 40, 100.)
  };
  for (int i {0}; i < STOCKS; i++)
	stocks[i].show();

  Stock topstock = stocks[0];
  for (int i {0}; i < STOCKS; i++)
	topstock = topstock.topval(stocks[i]);

  cout << "most valuable holding:\n";
  topstock.show();

  return 0;
}
