/*
 * main.cpp
 *
 *  Created on: 03.03.2024
 *      Author: peter
 */

#include <iostream>
#include <cctype>
#include "stack.h"

int main(int argc, char **argv)
{
  using namespace std;
  Stack st;
  char ch;
  unsigned long po;
  cout << "Enter A to add a PO, \n" << "P to process a PO, Q to quit.\n";
  while (cin >> ch && toupper(ch) != 'Q')
  {
	while (cin.get() != '\n')
	  continue;
	if (!isalpha(ch))
	{
	  cout << "OOPS";  //'\a';   //  alarm?
	  continue;
	}
	switch (ch)
	{
	  case 'A':
	  case 'a':
		cout << "Enter PO number to add:";
		cin >> po;
		if (st.isfull())
		  cout << "stack is full\n";
		else
		  st.push(po);
		break;
	  case 'P':
	  case 'p':
		if (st.isempty())
		  cout << "stack is already empty.\n";
		else
		{
		  st.pop(po);
		  cout << "PO #" << po << " popped.\n";
		}
		break;
	}  //  switch
	cout << "Enter A to add a PO, \n" << "P to process a PO, Q to quit.\n";
  } // while
  cout << "Bye.\n";
  return 0;
}
