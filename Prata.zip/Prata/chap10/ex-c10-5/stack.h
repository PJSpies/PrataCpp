/*
 * stack.h
 *
 *  Created on: 05.03.2024
 *      Author: peter
 */

#ifndef STACK_H_
#define STACK_H_

#include <string>

struct customer
{
  std::string name_;
  double balance_;
};

typedef customer Item;

class Stack
{
private:
  static const int MAX { 3 };
  Item items[MAX];
  int top;
public:
  Stack();
  bool isempty() const;
  bool isfull() const;
  bool push(const Item &item);
  bool pop(Item &item);
};

#endif /* STACK_H_ */
