/*
 * move.h
 *
 *  Created on: 05.03.2024
 *      Author: peter
 */

#ifndef MOVE_H_
#define MOVE_H_

class Move
{
private:
  double x;
  double y;
public:

  Move(double a = 0, double b = 0);

  Move add(const Move &m) const;
  void show() const;
  void reset(double a = 0, double b = 0);
  Move operator+(const Move &m) const;

};

#endif /* MOVE_H_ */
