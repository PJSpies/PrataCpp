/*
 * haupt.cpp
 *
 *  Created on: 05.03.2024
 *      Author: peter
 */
#include <iostream>
#include "move.h"

int main()
{
  Move start { 1., 1. };
  std::cout << "start: ";
  start.show();

  Move delta { 2., 3. };
  std::cout << "delta: ";
  delta.show();

  Move neu = start.add(delta);
  std::cout << "neu = start.add(delta): ";
  neu.show();

  start.reset(5., 5.);
  std::cout << "start.reset(5., 5.): ";
  start.show();

  Move ganzneu;
  ganzneu = start + delta;
  std::cout << "start + delta: ";
  ganzneu.show();

  neu = start.operator+(delta);
  std::cout << "start.operator+(delta): ";
  neu.show();
  return 0;
}

