/*
 * move.cpp
 *
 *  Created on: 05.03.2024
 *      Author: peter
 */
#include <iostream>
#include "move.h"

Move::Move(double a, double b)
{
  x = a;
  y = b;
}

Move Move::operator+(const Move &m) const
{
  Move t;
  t.x = m.x + x;
  t.y = m.y + y;
  return t;
}

Move Move::add(const Move &m) const
{
  Move t;
  t.x = x + m.x;
  t.y = y + m.y;

  return t;
}

void Move::show() const
{
  std::cout << "x: " << x << ", y: " << y << std::endl;
}

void Move::reset(double a, double b)
{
  x = a;
  y = b;
}
