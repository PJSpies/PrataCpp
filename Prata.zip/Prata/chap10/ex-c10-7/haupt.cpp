/*
 * haupt.cpp
 *
 *  Created on: 06.03.2024
 *      Author: peter
 */
#include <iostream>
#include "plorg.h"

int main()
{
  Plorg p;
  p.show();
  p.change(-30);
  p.show();

  return 0;
}

