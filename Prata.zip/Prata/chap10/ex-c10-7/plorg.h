/*
 * plorg.h
 *
 *  Created on: 06.03.2024
 *      Author: peter
 */

#ifndef PLORG_H_
#define PLORG_H_

class Plorg
{
private:
  char name_[20];
  int ci_;
public:
  Plorg(const char *n = "Plorga", int i = 50);
  void change(int c);
  void show() const;

};

#endif /* PLORG_H_ */
