/*
 * plorg.cpp
 *
 *  Created on: 06.03.2024
 *      Author: peter
 */

#include <iostream>
#include <cstring>
#include "plorg.h"

Plorg::Plorg(const char *n, int i)
{
  std::strncpy(name_, n, 19);
  name_[19] = '\0';
  ci_ = i;
}

void Plorg::change(int i)
{
  ci_ += i;
}

void Plorg::show() const
{
  std::cout << " Plorg " << name_ << " has a Ci= " << ci_ << std::endl;
}
