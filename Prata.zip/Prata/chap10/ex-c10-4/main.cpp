/*
 * main.cpp
 *
 *  Created on: 05.03.2024
 *      Author: peter
 */

#include <iostream>
#include "sales.h"
using SALES::QUARTERS;

int main()
{
  SALES::Sales verkauf;
  double quartal[QUARTERS] { 1., 2., 3., 4. };
  verkauf.setSales(quartal, QUARTERS);
  verkauf.showSales();

  SALES::Sales v2;
  v2.setSales();
  v2.showSales();

  return 0;
}

