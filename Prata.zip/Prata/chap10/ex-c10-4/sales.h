/*
 * sales.h
 *
 *  Created on: 05.03.2024
 *      Author: peter
 */

#ifndef SALES_H_
#define SALES_H_

namespace SALES
{
  const int QUARTERS { 4 };
  class Sales
  {
  private:
	double sales_[QUARTERS];
	double average_;
	double min_;
	double max_;
  public:
	void setSales(const double ar[], int n);
	void setSales();   //  interactive
	void showSales();
  };

}

#endif /* SALES_H_ */
