/*
 * sales.cpp
 *
 *  Created on: 05.03.2024
 *      Author: peter
 */
#include <iostream>
#include "sales.h"

namespace SALES
{

  void Sales::setSales()  //  interactive
  {
	double sum { 0 };
	max_ = 0.0;
	min_ = 1000000.0;
	for (int i { 0 }; i < QUARTERS; i++)
	{
	  std::cout << "Enter sales Q[" << i << "]: ";
	  std::cin >> sales_[i];
	  sum += sales_[i];
	  max_ = sales_[i] > max_ ? sales_[i] : max_;
	  min_ = sales_[i] < min_ ? sales_[i] : min_;
	}
	std::cout << std::endl;

	average_ = sum / QUARTERS;
  }  //  end of interactive setSales()

  void Sales::setSales(const double ar[], int n)
  {
	double sum { 0 };
//	Sales s;
	max_ = 0.0;
	min_ = 1000000.0;
	for (int i { 0 }; i < QUARTERS; i++)
	  sales_[i] = 0.0;
	for (int i { 0 }; i < n; i++)
	{
	  sales_[i] = ar[i];
	  sum += sales_[i];
	  max_ = sales_[i] > max_ ? sales_[i] : max_;
	  min_ = sales_[i] < min_ ? sales_[i] : min_;
	}
	average_ = sum / QUARTERS;
  }  //  end of setSales()  non-interactive

  void Sales::showSales()
  {
	for (int i { 0 }; i < QUARTERS; i++)
	{
	  std::cout << "Quartal " << i << " sales $" << sales_[i] << std::endl;
	}
	std::cout << "average $" << average_ << std::endl;
	std::cout << "min     $" << min_ << std::endl;
	std::cout << "max     $" << max_ << std::endl;
  }
}
