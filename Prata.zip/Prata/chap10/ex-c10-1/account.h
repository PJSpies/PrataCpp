/*
 * account.h
 *
 *  Created on: 03.03.2024
 *      Author: peter
 */

#ifndef ACCOUNT_H_
#define ACCOUNT_H_

#include <string>

class Account
{
private:
  std::string lastname;
  std::string name;
  std::string number;
  double balance;
  public:
  Account();
  Account(std::string lastname_, std::string name_, std::string number_);
  ~Account();
  void showAccount() const;  // display accnt holder and balance
  void deposit(double val);   // adds val to balance
  bool withdraw(double val); // subtracts val from balance
};

#endif /* ACCOUNT_H_ */
