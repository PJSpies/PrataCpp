/*
 * main.cpp
 *
 *  Created on: 03.03.2024
 *      Author: peter
 */

#include <iostream>
#include "account.h"

int main(int argc, char **argv)
{
  Account easy;
  easy.showAccount();

  Account myaccount("Spies", "Peter", "23.334");
  myaccount.deposit(1000.);
  myaccount.showAccount();
  myaccount.withdraw(900.);
  myaccount.showAccount();

  myaccount.withdraw(101.);
  myaccount.showAccount();

}
