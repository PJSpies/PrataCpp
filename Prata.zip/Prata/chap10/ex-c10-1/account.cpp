/*
 * account.cpp
 *
 *  Created on: 03.03.2024
 *      Author: peter
 */

#include <iostream>
#include "account.h"

Account::Account()
{
  balance = 0;
  lastname = "N.";
  name = "N.";
  number = "no number";
}

Account::Account(std::string lastname_, std::string name_, std::string number_)
{
  balance = 0;
  lastname = lastname_;
  name = name_;
  number = number_;
}
Account::~Account()
{
}

void Account::showAccount() const  // display accnt holder and balance
{
  std::cout << "Name: " << name << " " << lastname << "\n  Acct number: " << number << " balance: $" << balance << "\n";
}
void Account::deposit(double val)   // adds val to balance
{
  balance += val;
}
bool Account::withdraw(double val) // subtracts val from balance
{
  if (balance > val)
  {
	balance -= val;
	return true;
  }
  else
  {
	std::cout << "  Balance is less than withdrawal request! Aborted.\n";
	return false;
  }
}
