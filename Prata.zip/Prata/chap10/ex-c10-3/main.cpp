/*
 * main.cpp
 *
 *  Created on: 29.02.2024
 *      Author: peter
 */
#include <iostream>
#include "golf2.h"

int main()
{
  Golf golfer1 { };  //  this initialises the object with defaults
  golfer1.show();

  Golf golfer2 { "Charles", 4 };   // this initialises the object with given values
  golfer2.show();

  Golf golfer3;
  golfer3.setgolf();
  golfer3.show();

  return 0;
}
