/*
 * golf2.h
 *
 *  Created on: 04.03.2024
 *      Author: peter
 */

#ifndef GOLF2_H_
#define GOLF2_H_
#include <string>

class Golf
{
private:
  std::string name_;
  int handicap_;
public:

  Golf(const std::string &n = "N.N.", int hc = 0);  //  constructor

  Golf& setgolf();

  void show() const;

};

#endif /* GOLF2_H_ */
