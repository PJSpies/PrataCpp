/*
 * golf2.cpp
 *
 *  Created on: 04.03.2024
 *      Author: peter
 */

#include <iostream>
#include "golf2.h"

Golf::Golf(const std::string &n, int hc)
{
  name_ = n;
  handicap_ = hc;
}

Golf& Golf::setgolf()
{
  /*  using the private data members to initialise an object of type Golf. The constructor is called implicitly */

  std::cout << "enter name: ";
  std::cin >> name_;
  std::cout << "enter handicap: ";
  std::cin >> handicap_;

  return *this;
}

void Golf::show() const
{
  std::cout << name_ << " has handicap of " << handicap_ << std::endl;
}
