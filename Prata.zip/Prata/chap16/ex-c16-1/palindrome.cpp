/*
 * palindrome.cpp
 * Prata exercise 16.1 and 16.2
 *  Created on: 16.07.2024
 *      Author: peter
 */

#include <iostream>
#include <string>
#include <cctype>  //  tolower(), isalpha()

bool is_palindrome(const std::string &w)    //  letter-by-letter check
{
  long unsigned int i = 0;
  long unsigned int j = w.size() - 1;

  while (i != j && i < w.length() / 2)
  {
	if (w[i] != w[j]) return false;
	i++;
	j--;
  }
  return true;
}

std::string strip(const std::string &test)    //  convert to only lower case letters, omit punctuation and blank spaces
{
  std::string stripped_phrase {test};
  long unsigned int i = 0;
  long unsigned int j = 0;

  while (i < test.length() && test[i] != '\0')
  {
	if (isalpha(test[i]))
	{
	  stripped_phrase[j] = tolower(test[i]);
	  j++;
	}
	i++;
  }
  return stripped_phrase.erase(j, i);
}

int main(int argc, char **argv)
{

  std::cout << "Enter a phrase:\n";
  //  getline(std::cin, test1);
  std::string test1 = "Madam, I'm Adam";

  std::string s = is_palindrome(strip(test1)) ? " " : " not ";
  std::cout << "\'" << test1 << "\'" << " is" << s << "a palindrome.\n";

  std::string test2 = "Madam, I am Adam";
//  all in one line
  std::cout << "\'" << test2 << "\'" << " is" << (is_palindrome(strip(test2)) ? " " : " not ") << "a palindrome.\n";

  return 0;
}

