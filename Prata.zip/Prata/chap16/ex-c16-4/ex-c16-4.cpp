/*
 * ex-c16-4.cpp
 *
 *  Created on: 23.07.2024
 *      Author: peter
 *
 Write a function with an old-style interface that has this prototype:
 int reduce(long ar[], int n);
 The actual arguments should be the name of an array and the number of elements
 in the array. The function should sort an array, remove duplicate values, and return a
 value equal to the number of elements in the reduced array. Write the function
 using STL functions. (If you decide to use the general unique() function, note that
 it returns the end of the resulting range.) Test the function in a short program.

 */
#include <iostream>
#include <algorithm>
//#include <vector>
#include <list>
void Show(int v)
{
  std::cout << v << ' ';
}
int reduce(long ar[], int n)
{
  /*    vector is not the best solution here!
   std::vector<long> a(ar, ar + n);
   sort(a.begin(), a.end());
   for_each(a.begin(), a.end(), Show);
   std::cout << std::endl;
   */

  std::list<long> l(ar, ar + n);
  l.unique();    //  eliminatest dublicates if list is sorted.
  for_each(l.begin(), l.end(), Show);
  l.sort();
  for_each(l.begin(), l.end(), Show);

  return l.size();
}

int main(int argc, char **argv)
{
  const int static N = 5;
  long int a[N] = {4, 2, 2, 5, 0};
  int b = reduce(a, N);
  std::cout << "\nsize of reduced list: " << b << std::endl;
  return 0;
}

