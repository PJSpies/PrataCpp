//@formatter:off
/*
 * ex-c16-8.cpp
 *
 *  Created on: 31.07.2024
 *      Author: peter
 *  Mat and Pat want to invite their friends to a party.They ask you to write a program that does the following:
 Allows Mat to enter a list of his friends’ names.The names are stored in a container and then displayed in sorted order.
 Allows Pat to enter a list of her friends’ names.The names are stored in a second container and then displayed in sorted order.
 Creates a third container that merges the two lists, eliminates duplicates, and displays the contents of this container.
 *
 */
#include <iostream>
#include <list>
#include <algorithm>
#include <string>
#include <ranges>
#include <cctype>

/*
struct Friend
{
  std::string lastname;
  std::string firstname;
};

bool by_LastName(const Friend& li, const Friend& re)
{
  if (li.lastname !< re.lastname) return false;
  return true;
}
*/
void ShowList(std::list<std::string> &fl)
{
  fl.sort();
  fl.unique();
  for (auto &l : fl)
	std::cout << l << "\n";
}

int main()
{
  std::list<std::string> MatFriends {"Mike", "Charlie", "Peter", "Carl", "Fred", "Reve"};
  std::list<std::string> PatFriends {"Ana", "Kelly", "Reve", "April", "Fred"};
  std::list<std::string> BothFriends ;

//  enter Mat's friends
//  sort and display
  ShowList(MatFriends);

//  enter Pat's friends
//  sort and display
  ShowList(PatFriends);

//	merge only uniques
//  (sort, then) display
  MatFriends.merge(PatFriends);
  MatFriends.unique();
  std::cout << " combined:\n";
  ShowList(MatFriends);


}
//@formatter:on
