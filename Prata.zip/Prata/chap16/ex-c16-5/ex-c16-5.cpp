/*
 * ex-c16-5.cpp
 *
 *  Created on: 23.07.2024
 *      Author: peter
 *
 * Do the same problem as described in Programming Exercise 4, except make it a template function:
 *  template <class T>
 *  int reduce(T ar[], int n);
 * Test the function in a short program, using both a long instantiation and a string instantiation.
 */
#include <iostream>
#include <algorithm>
#include <string>
#include <list>
#include <vector>

template<typename T>
  int reduce(T ar[], int n)
  {
	std::list<T> l(ar, ar + n);
	l.sort();		// lexicographic sorting   drei drei eins vier zwei
	l.unique();    //  eliminatest dublicates  		drei eins vier zwei

	for (auto i : l)
	  std::cout << i << " ";

	return l.size();
  }

int main(int argc, char **argv)
{
  const int static N = 5;
  long int a[N] = {4, 2, 2, 5, 0};
  int b = reduce(a, N);
  std::cout << "\nsize of reduced list: " << b << std::endl;

  std::string str[N] = {"eins", "zwei", "drei", "drei", "vier"};
  int c = reduce(str, N);
  std::cout << "\nsize of reduced strings: " << c << std::endl;

  return 0;
}

