//@formatter:off
/*
 * ex-c16-7.cpp
 *
 *  Created on: 26.07.2024
 *      Author: peter

 Write a Lotto() function that takes two arguments.The function should return a vector<int> object
 that contains, in sorted order, the numbers selected at random. For example, you could use the function as
 follows:
	   vector<int> winners;
	   winners = Lotto(51,6);

 Note that simply using rand() doesn’t quite do the job because it may produce duplicate values.
 Suggestion: Have the function create a vector that contains all the possible values, use random_shuffle(),
 and then use the beginning of the shuffled vector to obtain the values.
 */

#include <algorithm> // copy algorithm
//#include <fmt/format.h> // C++20: This will be #include <format>
#include <format> // C++20: This will be #include <format>
#include <iostream>
#include <ranges>
#include <iterator> // ostream_iterator iterator
#include <vector>
#include <random>

//+++ int f()
//+++ {
//+++   static int i;
//+++   return ++i;
//+++ }

std::vector<int> Lotto(const int M, const int sz)
{
  std::vector<int> all(M);

  //  fill vector all with M numbers. Three possibilities.

/* 1)   classic
  for (int i{0}; i <M; i++)
  	all[i] = i+1;
*/

/* 2) using a named function 'f()'    */
//+++  std::generate(all.begin(), all.end(), f);

/* 3) A lambda function in generate:  */
  std::generate(all.begin(), all.end(), [n=1]() mutable {return n++; } );

  std::default_random_engine randomEngine{std::random_device{}()};
  std::ranges::shuffle(all, randomEngine); // randomly order elements,  C++20
//  random_shuffle(all.begin(), all.end());  //  C++11

//  try #1  copy first sz numbers into result vector
//  std::vector<int> res;
//  res.assign(all.begin(), all.begin()+sz );

//  try #2  erase all but first sz numbers from all
  all.erase(all.cbegin()+sz, all.cend() );
  std::ranges::sort(all);  //  C++20

  return all;
}

int main()
{
  std::vector<int> winner = Lotto(49,6);

  for (auto const& w : winner)
    std::cout << w << " ";
  std::cout << std::endl;
  return 0;
}

//@formatter:on
