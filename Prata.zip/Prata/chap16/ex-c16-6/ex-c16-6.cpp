/*
 * ex-c16-6.cpp
 *
 *  Created on: 24.07.2024
 *      Author: peter
 *
 *  Redo the example shown in Listing 12.12, using the STL queue template class
 *  instead of the Queue class described in Chapter 12.
 */
/*
 * bank.cpp
 *
 *  Created on: 15.03.2024
 *      Author: peter
 */
#include <iostream>
#include <cstdlib>  //  random functions
#include <ctime>	//  time()
#include <queue>

const int MIN_PER_HR = 60;
bool newcustomer(double x);
class Customer
{
private:
  long arrive;
  int processtime;
public:
  Customer()
  {
	arrive = processtime = 0;
  }
  void set(int n, long when);
  long when() const
  {
	return arrive;
  }
  int ptime()
  {
	return processtime;
  }
};
// customer method
// when is the time at which the customer arrives? The arrival time is set to when and the
// processing time set to a random value in the range 1 - n (cycles==minutes)
void Customer::set(int n, long when)
{
  processtime = std::rand() % n + 1;
  arrive = when;
}

int main()
{
  using std::cin;
  using std::cout;
  using std::endl;
  using std::ios_base;

  std::srand(std::time(0));

  cout << "Enter max size of queue (integer): ";
  int qs;
  cin >> qs;
//  int qs = 5;    //  for tests
//  create a queue called 'line'
  std::queue<Customer> line;    // this was: line(qs);  STL's <queue> cannot be given size

  cout << "Enter hours to simulate (integer): ";
  int hours;
  cin >> hours;
//  hours = 200;

  long cyclelimit = MIN_PER_HR * hours;    //  max number of cycles to simulate

  cout << "Enter average number of customers per hour (double): ";
  double perhour;
  cin >> perhour;
//  perhour = 6;

  cout << "Enter number of cycles to serve a customer (integer): ";
  int avrg_ptime;
  cin >> avrg_ptime;

  double min_per_cust;
  min_per_cust = MIN_PER_HR / perhour;    //  arrivals average

  Customer temp;	//  items to queue: customers. Have start time, durations, etc.
					//	I only need a temporary Customer variable to fill the queue / count integers

  /*  these for statistics */
  long turnaways = 0;
  long customers = 0;
  long served = 0;
  long sum_line = 0;
  int wait_time = 0;
  long line_wait = 0;

  for (int cycle = 0; cycle < cyclelimit; cycle++)    // iterating through all cycles...
  {
	if (newcustomer(min_per_cust))    //  create a new customer by chance
	{
	  if (line.size() > qs)    //  this was  ... !line.empty()  )  for a fixed line size
		turnaways++;
	  else
	  {
		customers++;
		temp.set(avrg_ptime, cycle);    //  Customer.set  creates arrival time 'when' and logs 'process time'
		line.push(temp);    //  keep it in queue (at end)
	  }
	}
//	continue with the last customer created = 'temp'
	if (wait_time <= 0 && !line.empty())    //  'temp' gets served...
	{
	  line.pop();		//  ...and leaves the queue
	  wait_time = temp.ptime();    //  temp's processing time (hold-up of next customer)
	  line_wait += cycle - temp.when();    // this cylce minus arrival cycle
	  served++;
	}

	if (wait_time > 0) wait_time--;

	sum_line += line.size();
  }

  if (customers > 0)
  {
	cout << endl;
	cout.setf(ios_base::fixed);
	cout << "customers accepted: " << customers << endl;
	cout << "  customers served: " << served << endl;
	cout << "         turnaways: " << turnaways << endl;
	cout << "    average Q size: ";
	cout.precision(2);
	cout.setf(ios_base::fixed, ios_base::floatfield);
	cout.setf(ios_base::showpoint);
	cout << (double) sum_line / cyclelimit << endl;
	cout << "average wait time : " << (double) line_wait / served << endl;
  }
  else
	cout << "\nno customers\n";
  cout << "** Prg ends. **" << endl;

  return 0;
}

bool newcustomer(double x)
{
  return (std::rand() * x / RAND_MAX < 1);
}

