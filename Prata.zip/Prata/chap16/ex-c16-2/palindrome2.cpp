/*
 * palindrome2.cpp
 *
 *  Created on: 17.07.2024
 *      Author: peter
 */

#include <iostream>
#include <string>
#include <cctype>  //  tolower(), isalpha()

bool is_palindrome(const std::string &test)    //  convert to only lower case letters, omit punctuation and blank spaces
{
  std::string str {test};
  long unsigned int i = 0;    //  iterates through test phrase
  long unsigned int k = 0;    //  iterates along stripped string:  k <= i

  while (i < test.length())
  {
	  if (isalpha(test[i]))
	  {
	    str[k] = tolower(test[i]);
	    k++;
	  }
	  i++;
  }
  str.erase(k, i);    //  discard space in str beyond last letter: clip string to size.
  k--;      //  set k to last letter
  i = 0;    //  reset i to beginning of str
  // compare letters marching from begin() to half and end() to half. k points to end of str.
  while (i != k && i < str.length() / 2)
  {
	  if (str[i] != str[k]) return false;    //  first mismatch found -->  cannot be a palindrome
	  i++;
	  k--;
  }
  return true;
}

int main(int argc, char **argv)
{
  /*
   std::string test1 = "Madam, I'm Adam";
   std::string s = is_palindrome(test1) ? " " : " not ";    //   s is either " " or " not "
   std::cout << "\'" << test1 << "\'" << " is" << s << "a palindrome.\n";

   std::string test2 = "Madam, I am Adam";
   //  all in one line
   std::cout << "\'" << test2 << "\'" << " is" << (is_palindrome(test2) ? " " : " not ") << "a palindrome.\n";
   */

  std::cout << "\'Palindrome, palindrome... where do you roam?" << std::endl;
  std::cout << " Palindrome, palindrome... far, far from home.\'\n" << std::endl;
  std::cout << "An example: ";
//I can even submit just the string:
  std::cout << "\'" << "Regallager" << "\'" << " is" << (is_palindrome("Regallager") ? " " : " not ") << " a palindrome.\n";

  std::string test;
  std::cout << "Enter a phrase to test for palindrome <empty string to end>:\n";
  getline(std::cin, test);

  while (test != "")
  {
    std::cout << "\'" << test << "\'"  
      << (is_palindrome(test) ? " \x1b[32;1mis\x1b[0m" : " \x1b[31;1mis not\x1b[0m") 
      << " a palindrome.\n";
    std::cout << "Enter a phrase to test for palindrome <empty string to end>:\n";
    getline(std::cin, test);
  }

  std::cout << "Bye!\n";
  return 0;
}

