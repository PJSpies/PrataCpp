/*
Modify Listing 16.9 (vect3.cpp, 16.7 in 5th edition) as follows:
    a. Add a price member to the Review structure.
    b. Instead of using a vector of Review objects to hold the input, use a vector
        of shared_ptr<Review> objects. Remember that a shared_ptr has to be
        initialized with a pointer returned by new.
    c. Follow the input stage with a loop that allows the user the following options
        for displaying books: in original order, in alphabetical order, in order of
        increasing ratings, in order of decreasing ratings, in order of increasing price,
        in order of decreasing price, and quitting.

Here’s one possible approach. After getting the initial input, create another vector of
shared_ptrs initialized to the original array. Define an operator<() function that compares
pointed-to structures and use it to sort the second vector so that the shared_ptrs are in
the order of the book names stored in the pointed-to objects. Repeat the process to get
vectors of shared_ptrs sorted by rating and by price. Note that rbegin() and rend() save you
the trouble of also creating vectors of reversed order.

PJS-2024:
Why keep three extra vectors with sorted data?  The block commented portion works with rearranging 
the original vector

*/
// vect3.cpp -- using STL functions
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <memory>
struct Review
{
    std::string title;
    int rating;
    float price;
};
bool operator<(std::shared_ptr<Review> rl, std::shared_ptr<Review> rr);
bool worseThan(std::shared_ptr<Review> rl, std::shared_ptr<Review> rr);
bool cheaperThan(std::shared_ptr<Review> rl, std::shared_ptr<Review> rr);
bool FillReview(Review& rr);
void ShowReview(std::shared_ptr<Review> rr);

int main()
{
    using namespace std;
    vector<shared_ptr<Review>> books;
    Review temp;

    while (FillReview(temp)) 
    {
        shared_ptr<Review> ptmp (new Review) ;
        *ptmp = temp;
        books.push_back(ptmp);
    }

    if (books.size() > 0)
    {
        cout << "Thank you. You entered the following "
             << books.size() << " ratings:\n"
             << "Rating\tTitle\tPrice\n";
        for_each(books.begin(), books.end(), ShowReview);

        vector<shared_ptr<Review>> sorted_books_byTitle(books);
        sort(books.begin(), books.end());
        sorted_books_byTitle = books;
        for_each(sorted_books_byTitle.begin(), sorted_books_byTitle.end(), ShowReview);

        vector<shared_ptr<Review>> sorted_books_byRating(books);
        sort(books.begin(), books.end(), worseThan);
        sorted_books_byRating = books;
        cout << "Sorted by rating:\nRating\tTitle\tPrice\n";
        for_each(sorted_books_byRating.begin(), sorted_books_byRating.end(), ShowReview);
        cout << "Sorted by rev. rating:\nRating\tTitle\tPrice\n";
        for_each(sorted_books_byRating.rbegin(), sorted_books_byRating.rend(), ShowReview);

        vector<shared_ptr<Review>> sorted_books_byPrice(books);
        sort(books.begin(), books.end(), cheaperThan);
        cout << "Sorted by price:\nRating\tTitle\tPrice\n";
        for_each(books.begin(), books.end(), ShowReview);
        cout << "Sorted by rev. price:\nRating\tTitle\tPrice\n";
        for_each(books.rbegin(), books.rend(), ShowReview);

/*
        sort(books.begin(), books.end());
        cout << "Sorted by title:\nRating\tTitle\tPrice\n";
        for_each(books.begin(), books.end(), ShowReview);

        sort(books.begin(), books.end(), worseThan);
        cout << "Sorted by reverse rating:\nRating\tTitle\tPrice\n";
        for_each(books.begin(), books.end(), ShowReview);
        cout << "Sorted by  rating:\nRating\tTitle\tPrice\n";
        for_each(books.rbegin(), books.rend(), ShowReview);  //  test reverse iterator

        sort(books.begin(), books.end(), cheaperThan);
        cout << "Sorted by price:\nRating\tTitle\tPrice\n";
        for_each(books.begin(), books.end(), ShowReview);
        cout << "Sorted by price:\nRating\tTitle\tPrice\n";
        for_each(books.rbegin(), books.rend(), ShowReview);
 */
/*         random_shuffle(books.begin(), books.end());
        cout << "After shuffling:\nRating\tTitle\tPrice\n";
        for_each(books.begin(), books.end(), ShowReview); 
 */
    }
    else
        cout << "No entries. ";
    cout << "Bye.\n";
    return 0;
}
bool operator<(std::shared_ptr<Review> rl, std::shared_ptr<Review> rr)
{
    if (rl->title < rr->title)
        return true;
    else if (rl->title == rr->title && rl->rating < rr->rating)
        return true;
    else
        return false;
}
bool worseThan(std::shared_ptr<Review> rl, std::shared_ptr<Review> rr)
{
    if (rl->rating < rr->rating)
        return true;
    else
        return false;
}bool cheaperThan(std::shared_ptr<Review> rl, std::shared_ptr<Review> rr)
{
    if (rl->price < rr->price)
        return true;
    else
        return false;
}
bool FillReview(Review & rr)
{
    std::cout << "Enter book title (quit to quit): ";
    std::getline(std::cin, rr.title);
    if (rr.title == "quit")
        return false;
    std::cout << "Enter book rating: ";
    std::cin >> rr.rating;
    if (!std::cin)
        return false;
    std::cout << "Enter book price: ";
    std::cin >> rr.price;
    if (!std::cin)
        return false;
    // get rid of rest of input line
    while (std::cin.get() != '\n')
        continue;
    return true;
}
void ShowReview(std::shared_ptr<Review> rr)
{
    std::cout << rr->rating << "\t" << rr->title <<"\t" << rr->price << std::endl;
}