/*
 * ex-c16-8-2.cpp
 *
 *  Created on: 01.08.2024
 *      Author: peter
 */

//@formatter:off
/*
 *  Created on: 31.07.2024
 *      Author: peter
 *  Mat and Pat want to invite their friends to a party.They ask you to write a program that does the following:
 Allows Mat to enter a list of his friends’ names.The names are stored in a container and then displayed in sorted order.
 Allows Pat to enter a list of her friends’ names.The names are stored in a second container and then displayed in sorted order.
 Creates a third container that merges the two lists, eliminates duplicates, and displays the contents of this container.
 *
 */
#include <iostream>
#include <set>
#include <algorithm>
#include <iterator>
#include <string>

struct Friend
{
  std::string firstname;
  std::string lastname;
};

void Show(std::set<Friend> &fl)
{
  for (auto &l : fl)
	std::cout << l.lastname << ", " << l.firstname << "\n";
}

bool operator<(const Friend& a, const Friend& b)
{
	if (a.lastname == b.lastname)
	  return a.firstname < b.firstname;
	return a.lastname < b.lastname;
}

int main()
{
	std::set<Friend> MatFriends {
	  Friend{"Mike", "Milton"},
	  Friend{"Carly", "Charlton"},
	  Friend{"Frank", "Charlton"},
	  Friend{"Peter", "Peterson"},
	  Friend{"Pat", "Peterson"},
	  Friend{"Balin",  "Brewer"},
  };

  std::set<Friend> PatFriends
  {
	Friend{"Ana", "Arling"},
	Friend{"Frieda", "Arling"},
	Friend{"Balin",  "Brewer"},
	Friend{"Reve", "Riverton"},
	Friend{"Peter", "Peterson"},
	Friend{"Carly", "Charlton"}
  };

//  enter Mat's friends
//  sort and display
  std::cout << " Mat's " << MatFriends.size() << " friends:\n";
  Show(MatFriends);

//  enter Pat's friends
//  sort and display
  std::cout << " Pat's " << PatFriends.size() << " friends:\n";
  Show(PatFriends);

//	merge only uniques
//  (sort, then) display
  std::set<Friend> BothFriends;

  std::set_union( MatFriends.begin(), MatFriends.end(), PatFriends.begin(), PatFriends.end(),
				  std::insert_iterator<std::set<Friend>> (BothFriends, BothFriends.begin() )
				 );

  std::cout << "\n " << BothFriends.size() << " friends combined:\n";
  Show(BothFriends);

  return 0;
}
//@formatter:on
