/*
 * tabletenn1.h
 *
 *  Created on: 23.03.2024
 *      Author: peter
 */

#ifndef TABLETENN1_H_
#define TABLETENN1_H_

class TableTennisPlayer
{
private:
  static const int LIM {20};
  char firstname[LIM];
  char lastname[LIM];
  bool hasTable;
public:
  TableTennisPlayer(const char *fn = "none", const char *ln = "none", bool hasTable = false);

  void Name() const;
  bool HasTable()
  {
	return hasTable;
  }
  void resetTable(bool v)
  {
	hasTable = v;
  }
};

class RatedPlayer : public TableTennisPlayer
{
private:
  unsigned int rating;
public:
  RatedPlayer(unsigned int r = 0, const char *fn = "none", const char *ln = "none", bool ht = false);
  RatedPlayer(unsigned int r, const TableTennisPlayer &tp);
  unsigned int Rating()
  {
	return rating;
  }

  void ResetRating(unsigned int r)
  {
	rating = r;
  }
};

#endif /* TABLETENN1_H_ */
