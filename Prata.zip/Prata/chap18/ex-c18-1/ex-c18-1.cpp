/*
 * ex-c18-1.cpp
 *
 *  Created on: 21 Sept. 2024, 06:07:32
 *      Author: peter
 *
 *   Complete the program by supplying the average_list() function. It should be a
 template function, with the type parameter being used to specify the kind of
 initialized_list template to be used as the function parameter and also to give
 the function return type.
 */
#include <initializer_list>
#include <iostream>

template<typename T>
  T average_list(const std::initializer_list<T> &mylist)
  {
	T res = 0;
//   loop?  use an iterator /pointer
	for (auto p = mylist.begin(); p != mylist.end(); p++)
	  res += *p;    //  add content of pointed to address
	return res / mylist.size();
  }

namespace AVRG
{
  static unsigned short NA = 0;
// definition for 0 parameters
  void add()
  {
	std::cout << "Number of Args: 0" << std::endl;
  }
// definition for 1 parameter
  template<typename T>
	T add(T value)
	{
	  return value;
	}

  template<typename T, typename ... Args>
	T add(T value, Args ... args)
	{
	  NA = (sizeof...(args) + 1) > NA ? (sizeof...(args) + 1) : NA;
	  return (value + add(args...));
	}
}
int main()
{
  using namespace std;
// list of double deduced from list contents
//  auto q = average_list<double>( {11.0, 12.0, 10.});
//  cout << q << endl;
  auto r = AVRG::add(4., 3., 2., 1.) / AVRG::NA;
  cout << "r: " << r << endl;

// list of int deduced from list contents
//  cout << average_list<int>( {20, 30, 19, 17, 45, 38}) << endl;
// forced list of double
//  auto ad = average_list<double>( {'A', 70, 65.33});
//  cout << ad << endl;
  return 0;
}

