/*
 * ex-c18-2.cpp
 *
 *  Created on: 24 Sept. 2024, 07:10:25
 *      Author: peter
 *
 *  The operator+() function should create an object whose qcode and zcode mem-
 bers concatenate the corresponding members of the operands. Provide code that
 implements move semantics for the move constructor and the move assignment
 operator.Write a program that uses all the methods. For testing purposes, make the
 various methods verbose so that you can see when they are used.
 */

#include <iostream>
#include <string>
#include <utility>   //  move()

static unsigned int ct {0};

class Cpmv
{
public:

  struct Info
  {
	std::string qcode;
	std::string zcode;
  };
private:
  Info *ptr;
public:
  Cpmv();    // default constructor
  Cpmv(std::string q, std::string z);    //  intializing constructor
  Cpmv(const Cpmv &cp);    // copy constructor
  Cpmv(Cpmv &&mv);    // move constructor
  ~Cpmv();    //  destructor
  Cpmv& operator=(const Cpmv &cp);    // copy assignment operator
  Cpmv& operator=(Cpmv &&mv);    // move assignment operator
  Cpmv operator+(const Cpmv &obj) const;    // concatenation operator   res=a.operator+(b)
  void Display() const;    //  method
};

Cpmv::Cpmv()    // default constructor
{
  ++ct;
  std::cout << " constructor " << std::endl;
  ptr = new Info;
  ptr->qcode = "";
  ptr->zcode = "";
}

Cpmv::Cpmv(std::string q, std::string z)
{
  std::cout << " constructor with strings \'" << q << "\' and \'" << z << "\'" << std::endl;
  ++ct;
  ptr = new Info;
  ptr->qcode = q;
  ptr->zcode = z;
}

Cpmv::Cpmv(const Cpmv &cp)    // copy constructor
{
  ++ct;
  std::cout << "copy constructor " << std::endl;
  ptr = new Info;
  ptr->qcode = cp.ptr->qcode;
  ptr->zcode = cp.ptr->zcode;
}

/* destructor  */
Cpmv::~Cpmv()
{
  --ct;
  std::cout << ct << "  destructor called " << std::endl;
}

/* copy assignment operator  */
Cpmv& Cpmv::operator=(const Cpmv &cp)
{
  std::cout << " copy assignment operator " << std::endl;
  if (this != &cp)
  {
	ptr = new Info;
	ptr->qcode = cp.ptr->qcode;
	ptr->zcode = cp.ptr->zcode;
  }
  return *this;
}

/*  the move constructor  */
Cpmv::Cpmv(Cpmv &&rval)
{
  std::cout << "move constructor called" << std::endl;
  ++ct;

  ptr = rval.ptr;
  ptr->qcode = rval.ptr->qcode;
  ptr->zcode = rval.ptr->zcode;

  rval.ptr->qcode = "0";
  rval.ptr->zcode = "0";
  rval.ptr = nullptr;
}

/*  the move assignment operator */
Cpmv& Cpmv::operator=(Cpmv &&rval)
{
  std::cout << "move assignment operator  " << std::endl;
  if (this != &rval)
  {
	ptr->qcode = rval.ptr->qcode;
	ptr->zcode = rval.ptr->zcode;
	rval.ptr = nullptr;
  }
  return *this;
}

/*  the concatenation operator (addition)  */
Cpmv Cpmv::operator+(const Cpmv &obj) const
{
  std::cout << "concatenating obj.Info " << std::endl;
  return Cpmv {ptr->qcode + obj.ptr->qcode, ptr->zcode + obj.ptr->zcode};
}
void Cpmv::Display() const
{
  if (ptr)
	std::cout << ct << " \'" << ptr->qcode << "\' , \'" << ptr->zcode << "\'" << std::endl;
  else
	std::cout << "Object is empty!" << std::endl;
}

int main()
{
  Cpmv eins;
  eins.Display();
  Cpmv zwei("XXX", "YYY");
  zwei.Display();

//  testing copy assignment operator
  eins = zwei;
  eins.Display();

// copy constructor
  Cpmv drei(zwei);
  drei.Display();

//  move constructor  ?  No.
  Cpmv five;
  five = eins + eins;
  eins.Display();
  five.Display();

// move assignment?
  Cpmv neu;
  neu = std::move(zwei);
  zwei.Display();
  neu.Display();

}
