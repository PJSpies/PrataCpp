/*
 * ex-c18-4.cpp
 *
 *  Created on: 27 Sept. 2024, 06:01:19
 *      Author: peter
 *
 * Redo Listing 16.15 using lambdas. In particular, replace the outint() function with
 * a named lambda and replace the two uses of a functor with two anonymous lambda expressions.
 */
// functor.cpp -- using a functor
#include <iostream>
#include <list>
#include <iterator>
#include <algorithm>
template<class T>
  // functor class defines operator()()
  class TooBig
  {
  private:
	T cutoff;
  public:
	TooBig(const T &t) : cutoff(t)
	{
	}
	bool operator()(const T &v)
	{
	  return v > cutoff;
	}
  };
//void outint(int n)
//{
//  std::cout << n << " ";
//}

//@formatter:off

int main()
{
  using std::list;
  using std::cout;
  using std::endl;

  list<int> yadayada = {50, 100, 90, 180, 60, 210, 415, 88, 188, 201};
  list<int> etcetera {50, 100, 90, 180, 60, 210, 415, 88, 188, 201};

  cout << "Original lists:\n";
  auto outint = [](int n){ std::cout << n << " ";};   //  named lambda 'outint'

  for_each(yadayada.begin(), yadayada.end(), outint);   cout << endl;
  for_each(etcetera.begin(), etcetera.end(), outint);   cout << endl;

//  TooBig<int> f100(100);    // limit = 100
  int cutoff = 100;
  yadayada.remove_if( [=](int v){ return v > cutoff;} );  //  anonymous lambda using captured 'cutoff'

// use a named function object
//  etcetera.remove_if(TooBig<int>(200));
  etcetera.remove_if( [](int v){ return v > 200;} );

  // construct a function object
  cout << "Trimmed lists:\n";
  for_each(yadayada.begin(), yadayada.end(), outint);
  cout << endl;
  for_each(etcetera.begin(), etcetera.end(), outint);
  cout << endl;
  return 0;
}
//@formatter:on
