/*
 * ex-c18-3.cpp
 *
 *  Created on: 27 Sept. 2024, 05:37:11
 *      Author: peter
 *
 * Write and test a variadic template function sum_values() that accepts an
 * arbitrarily long list of arguments with numeric values (they can be a mixture of types)
 * and returns the sum as a long double value
 *
 */

#include <iostream>

// definition for 0 parameters
void sum_values()
{
}
// definition for 1 parameter
template<typename T>
  long double sum_values(T value)
  {
	return value;
  }
template<typename T, typename ... Args>
  long double sum_values(T value, Args ... args)
  {
	return (value + sum_values(args...));
  }

int main()
{
  std::cout << sum_values(1E-2, 2., 3.1, 4E3, 5L, 6) << std::endl;
  int i = sum_values(1, 2, 3, 4, 5, 6);
  std::cout << i << std::endl;
}

