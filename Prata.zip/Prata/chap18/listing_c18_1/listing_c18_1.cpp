/*
 * listing_c18_1.cpp
 *
 *  Created on: 18 Sept. 2024, 06:26:42
 *      Author: peter
 */
#include <iostream>
inline double f(double tf)
{
  return 5.0 * (tf - 32.0) / 9.0;
}
void Print(int &&value)
{
  std::cout << "Rvalue ref , address: " << value << ", " << &value << std::endl;
}
void Print(const int &value)
{
  std::cout << "Lvalue ref , address: " << value << ", " << &value << std::endl;
}

int main()
{
  using namespace std;

  int x = 10;
  int y = 23;
  int &&r1 = 13;
  int &&r2 = x + y;
  //double && r3 = std::sqrt(2.0);
  cout << "x value and address: " << x << ", " << &x << endl;
  Print(x);
  cout << "r1 value and address: " << r1 << ", " << &r1 << endl;
  Print(r1);

  cout << "r2 value and address: " << r2 << ", " << &r2 << endl;
  Print(20 + 40);
  Print(x + 11 * y);

  double tc = 21.5;
  double &&rd1 = 7.07;
  double &&rd2 = 1.8 * tc + 32.0;
  double &&rd3 = f(rd2);
  cout << " tc value and address: " << tc << ", " << &tc << endl;
  cout << "rd1 value and address: " << rd1 << ", " << &rd1 << endl;
  cout << "rd2 value and address: " << rd2 << ", " << &rd2 << endl;
  cout << "rd3 value and address: " << rd3 << ", " << &rd3 << endl;

  return 0;
}

