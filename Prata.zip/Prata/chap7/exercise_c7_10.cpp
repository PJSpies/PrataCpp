#include<iostream><i

//  Functions to use in calculate
double mal(double a, double b);
double plus(double a, double b);

//   This function calls the other one by pointer 'pfunc'
double calculate(double a, double b,  double (*pfunc)(double, double) );

int main()
{

    std::cout << calculate(2, 3, mal) << "\n";
    std::cout << calculate(2, 3, plus) << "\n";

return 0;
}

//  Function definitions:
double mal(double a, double b){ return a*b; }
double plus(double a, double b){ return a+b; }

double calculate(double a, double b,  double (*pfunc)(double, double) )
{ 
    return (*pfunc)(a,b);
}