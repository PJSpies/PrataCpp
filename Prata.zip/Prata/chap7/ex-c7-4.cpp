/*
 * ex-c7-4.cpp
 *   Prata 6th ed.  p. 374
 *
 *  Created on: 01.02.2024
 *      Author: peter
 */

#include<iostream>

// probability function
long double probability(unsigned numbers, unsigned picks);

int main(){
  double total, choices;
//  std::cout << "Enter total number of choices and\n"
//			   "the number of picks: \n";
//  while((std::cin >> total >> choices) && choices <= total)
//	{
  choices = 5;
  total = 47;
  std::cout << "Chance of winning is 1/ " << probability(total, choices) * probability(27, 1);
	  //	  std::cout << "\nenter next two numbers (q to quit): ";
//	}
  std::cout << "\nbye.\n";
  return 0;
}

long double probability(unsigned numbers, unsigned picks)
{
  long double res = 1.;
  long double n;
  unsigned p;
  for (n=numbers, p=picks; p>0; n--, p--)
	res = res * n/p;
  return res;
}
