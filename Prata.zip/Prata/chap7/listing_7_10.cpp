/*  
    Prata 6th ed., Chapter 7,  p.342
    Pointer to a string returned from a function 
*/
#include<iostream>
char * buildstr(char c, int n);   // prototype for function; returns a pointer
int main(){

    std::cout << "Enter a letter: ";
    char ch;
    std::cin >> ch;
    std::cout << "Enter an integer: ";
    int num;
    std::cin >> num;
    char* ps = buildstr(ch, num);  // ps points to the created string in memory ("picks" its value up there)
    std::cout << ps << std::endl;
    delete [] ps;
    ps = buildstr('+', num/2  -4);  // final string of of size 8 gets centered
    std::cout << ps << "  DONE  " << ps << std::endl;
    delete [] ps;

return 0;
}
char * buildstr(char c, int n)    //  return VALUE is a pointer to the (first char of the) string created
{
    char * pstr = new char[n+1];
    pstr[n] = '\0';
    while (n-- >0)  // decrement n only after using it: final loop compares n==1 with 0, then decrements n to 0 and set pstr[0]
    {               // filling from back to front avoids using a third variable.
        pstr[n] = c;
    }
    
    return pstr;  // leaving the function, pstr memory is freed up, but not the string itself.
}
