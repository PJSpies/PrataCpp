/*  function with pointer to structures  */
#include<iostream>

struct simple
{
    int a;
    float b;
};

void show_simple_value(const simple s);
void show_simple_ptr(const simple * ps);

int main () {
    simple s {1, 3.1415};
    show_simple_value(s);

    show_simple_ptr(&s);

    return 0;
}

void show_simple_value(const simple s)
{
    std::cout << s.a << " " << s.b << "\n";
}
void show_simple_ptr(const simple * ps)
{
    std::cout << ps->a << " " << ps->b << "\n";
}

