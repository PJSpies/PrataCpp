#include<iostream>
#include<string>
#include<functional>

//  Functions to use in calculate
double mal(double a, double b);
double plus(double a, double b);
double minus(double a, double b);
double durch( double a, double b);

//   This function calls the other one by pointer 'pfunc'
double calculate(double a, double b,  double (*pfunc)(double, double) );

double calc(double a, double b, std::function<double(double, double)> func)
{
    return func(a,b);
};

int main()
{
    // array of four function pointers.
    double (*pf[4])(double, double) {mal, plus, minus, durch};
//    char * fc[4] = {"mal", "plus", "minus", "durch"};  //  non-ISO version.  Use <string>-object instead:
    std::string fc[4] { "mal","plus", "minus", "durch" };

    double a, b;
    std::cout << "enter a, b: ";
    std::cin >> a >> b;

    while (std::cin && std::cin.good())
    {
      //  individual function calls:
        std::cout << "  mal: " << calculate(a, b, mal)   << "  ";
        std::cout << " plus: " << calculate(a, b, plus)  << "  ";
        std::cout << "minus: " << calculate(a, b, minus) << "  ";
        std::cout << "durch: " << calculate(a, b, durch) << "\n";

        //   calling f() from the array of function pointers...

        std::cout << "From an array of function pointers ...\n";
        for (int i {0}; i<3; i++)
            std::cout << a<< " "<< fc[i]<<" " <<b<<" = " << calculate(a, b, pf[i]) << " ,   ";
        std::cout << a<< " "<< fc[3]<<" " <<b<<" = " << calculate(a, b, pf[3])<< "\n";
//            std::cout << " f("<<i<<")= " << calculate(a, b, pf[i]) << "   ";
/*
        Now try <functional> 
*/
        std::cout << "<functional> objects in an array...\n";
        for (int i {0}; i<3; i++)
            std::cout << a<< " "<< fc[i]<<" " <<b<<" = " << calc(a, b, pf[i]) << " ,   ";
        std::cout << a<< " "<< fc[3]<<" " <<b<<" = " << calc(a, b, pf[3])<< "\n";


        std::cout << "\nenter a, b: ";
        std::cin >> a >> b;
    }
return 0;
}

//  Function definitions:
double mal(double a, double b){ return a*b; }
double plus(double a, double b){ return a+b; }
double minus(double a, double b){ return a-b; }
double durch(double a, double b)
{ 
//    double res = b !=0 ? a/b : 0.;  // div durch 0 liefert standardmäßig "inf"
//    return res;
    return a/b;
}

double calculate(double a, double b,  double (*pfunc)(double, double) )
{ 
    return (*pfunc)(a,b);
}