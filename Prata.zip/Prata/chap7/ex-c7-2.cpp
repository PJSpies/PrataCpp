#include<iostream>
constexpr int SZ = 3;
double average(double scores[SZ], int n);

int main(){

    std::cout << "Average of up to "<< SZ << " scores\n";
    double scores[SZ] ;
    int i{0};

    std::cout << "Enter score #" << i+1 << ": ";
    std::cin >> scores[i];
    while (std::cin && i< SZ-1 )
    {
        i++;
        std::cout << "Enter score #" << i+1 << ": ";
        std::cin >> scores[i];
    }

    std::cout << " Your scores: " << std::endl;
    for (int j=0; j<= i; j++) 
        if (scores[j]>0.) std::cout << scores[j] << ", ";
    std::cout << "\n";

    if (i>0) 
        std::cout << "Average=" << average(scores,i) << std::endl;
    else
        std::cout << "No average calculated.\n";
    std::cout << "\n";

return 0;
}

double average(double scores[SZ], int n){
    double result{0};
    for (int i=0; i<=n; i++)
        result += scores[i];
    return result / (n+1);
}
