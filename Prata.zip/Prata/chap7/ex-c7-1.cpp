#include<iostream>

double harmonic(double, double);

int main(){
    double x, y;
    std::cout << "Enter x, y: (at least one '0' stops) ";
    std::cin >> x >> y;
    
    while (x != 0. && y != 0.)
    {
        std::cout << "harmonic("<<x<<" , " << y<< ")= " << harmonic(x,y) <<  std::endl;
        std::cout << "Enter x, y: ";
        std::cin >> x >> y;
    }    
    std::cout << "Program ends. \n\n";
    return 0;
}

double harmonic(double x, double y)
{
    return 2.0f * x *y / (x+y);
}