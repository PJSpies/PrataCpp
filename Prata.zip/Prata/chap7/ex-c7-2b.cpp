#include<iostream>
constexpr int SZ = 10;

int n;

int input(double* scores, int SZ);
double average(const double scores[], int SZ);
void display(const double scores[], int SZ, double av);

int main(){
    double scores[SZ];
    n=input(scores, SZ);
    if (n<=0)
    {
        std::cout << "No numbers given. Stop.\n";
        return 1;
    }
    double av;
    av = average(scores, n);

    display(scores, n, av);

return 0;
}

int input(double* scores, int SZ)
{
    char c;
    int i{0};
    std::cout << "Enter up to " << SZ << " numbers\n" ;
    std::cout << "Enter score #" << i+1 << ": ";
    while (i< SZ && std::cin >> scores[i] )
    {
        if (++i < SZ)
            std::cout << "Enter score #" << i+1 << ": ";
    }
    return i;  // return size of [scores]
}

double average(const double scores[], int SZ){
    double result{0};
    for (int i=0; i<SZ; i++)
        result += scores[i];
    return result / SZ;
}

void display(const double scores[], int n, double av)
{
    std::cout << " Your scores: " << std::endl;
    for (int j=0; j< n; j++) 
        if (scores[j]>0.) std::cout << scores[j] << ", ";

    std::cout << "Average=" << av << std::endl;
}