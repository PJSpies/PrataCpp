#include<iostream>

double* fill_ar(  double* b,  double* e );
void show_array(const double * b, const double* e);
void mod_array( double * b, double* e, double r);
void reverse(double * b, double* e, int offset);

int main()
{
    const int Max {5};
    double ar[Max];
    double* last = fill_ar(ar, ar+Max);
    
    show_array(ar, last);

    mod_array(ar, last, 1.1);  // apply facor 1.1 to all elements
    show_array(ar, last);

    reverse(ar, last, 1); //  reverse, skip offset from begin and end
    show_array(ar, last);

return 0;
}

void reverse(double * b, double* e, int offset=0)
{
    double* j = e-offset;
    double* i = b+offset;
    double temp;

    double* half;
    half = b+(e-b)/2 ;

    while (i < half)
    {
        temp = *i;
        *i = *j;
        *j = temp;
        j--; i++;
    }
}
void show_array(const double * b, const double* e)
{
    const double* p;

    for (p=b; p!=e; p++)
        std::cout << *p << " ";
    std::cout << std::endl;
}

void mod_array( double * b, double* e, double r)
{
    double* p;

    for (p=b; p!=e; p++)
        *p *= r;
}

double* fill_ar(  double* b,  double* e )
{
    double* p=b;

    std::cout << "Enter values max " << int(e-b) << " numbers for ar:\n";
    
    while( p!=e && std::cin.good() )   //  use inequality check to compare pointers, not 'p<e'
    {
        std::cin >> *p;
        p++;
    }
    if (p <= e)
        p--;
    return p;
}
