/*
 * ex-c7-5.cpp
 *
 *  Created on: 01.02.2024
 *      Author: peter
 */

#include<iostream>

long int factorial(long int n)
{
  long int fact = 1;   // factorial (0) = 1
  if (n>1)
	  fact = n * factorial(n-1);
  return fact;
}

int main()
{
  long int n  ;
  std::cout << "enter n:" ;

  while ((std::cin >> n) && n>=0 )
	{
	  std::cout << "Factorial n = " << factorial(n) << std::endl;
	}
  std::cout << "bye.\n";
}
