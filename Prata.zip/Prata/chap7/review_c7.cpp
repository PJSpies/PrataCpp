#include<iostream>

void func(const int a[], int n);
void func2(const int b[][4], int n);

int main(){
    constexpr int sz = 4;

//  a 1-D array
    int iar1[sz] {9,8,7,6};
    std::cout << "&iar1 " << &iar1
              << " iar1 " << iar1 << "\n";
    func(iar1, sz);

//  A 2-D  array: (3 entries of pointers to 4-arrays )
    int iar2[3][4] { {1, 2, 3, 4} 
                    ,{5, 6, 7, 8} 
                    ,{9,10,11,12} 
                    };
    std::cout << "&iar2 " << &iar2
              << " iar2 " << iar2 << "\n";
    func2(iar2, 3);  //  give number of rows, not columns. pointers iar2[...][4] point to pointers of 4-arrays.

return 0;
}

void func(const int a[], int n)
//  for the one-dimensional array
{
    std::cout << "&a    " << &a  <<"  \n";
    std::cout << "*(&a)    " << *(&a)  <<"  \n";
    std::cout << " a    " << a  <<"  \n";
    for (int i=0; i<n;i++)
        std::cout << "&a["<<i << "] " << &a[i] << 
                     " a["<<i << "] " << a[i] <<
                     "  *(a+" << i<<") " << *(a+i) << "\n";
}
void func2(const int a[][4], int n)
//  for the two-dimensional array
{
    std::cout << "&a    " << &a  <<"  \n";
    std::cout << "*(&a)    " << *(&a)  <<"  \n";
    std::cout << " a    " << a  <<"  \n";
    for (int r=0; r<n;r++)      // r=rows
        for (int c=0;c<4;c++)   // c=columns
            std::cout << "&a["<<r<< "]["<<c<<"] " << &a[r][c] 
                      << " a["<<r<< "]["<<c<<"] " << a[r][c]  //  ==  *(*(a +r) )+c
                      << "\n"   ;
    for (int r=0; r<n;r++)      // r=rows
        {
        for (int c=0;c<4;c++)   // c=columns
            std::cout << a[r][c] << " ";
        std::cout << "\n"; 
        }
    std::cout << std::endl;
}