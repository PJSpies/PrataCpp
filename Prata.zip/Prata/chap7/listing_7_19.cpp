/*  array of function pointers  */

#include<iostream>

int main()
{
    const double * f1(const double ar[], int n);
    const double * f2(const double [], int n);
    const double * f3(const double * , int n);
    double av[3] {100., 200., 300.};

//  pointer to a function
    const double *(*p1)(const double *, int ) = f1;
    auto p2 = f2;
//  alternative from C++98
//  const double *(*p2)(const double *, int ) = f2;

    std::cout << "using pointers to functions.\n";
    std::cout << "address       value\n";
    std::cout << (*p1)(av,3) << " : " << *(*p1)(av,3) << "\n";
    std::cout << p2(av,3) << " : " << *p2(av,3) << "\n";

// pa to an array of pointers
    const double *(*pa[3])(const double *, int) = {f1, f2, f3};
    auto pb = pa;
//  pre-C++11 syntax is:
//  const double *(**bp)(const double *, int) = pa;
    std::cout << "using an array of pointers to functions.\n";
    std::cout << "address       value\n";
    for (int i=0; i<3; i++)
        std::cout << pa[i](av,3) << " : " << *pa[i](av,3) << "\n";
    std::cout << "using a pointer to a pointers to functions.\n";
    std::cout << "address       value\n";
    for (int i=0; i<3; i++)
        std::cout << pb[i](av,3) << " : " << *pb[i](av,3) << "\n";

    //  pointer to an array of function pointers
    auto pc = &pa;
// pre-C++11:
//    const double *(*(*pc)[3])(const double *, int) = &pa; 
    std::cout << "using a pointer to an array of pointers.\n";
    std::cout << "address       value\n";
    for (int i=0; i<3; i++)
        std::cout << (*pc)[i](av,3) << " : " << *(*pc)[i](av,3) << "\n";
    

return 0;
}

const double * f1(const double ar[], int n)
{
    return ar;
}
const double * f2(const double ar[], int n)
{
    return ar+1;
}
const double * f3(const double ar[], int n)
{
    return ar+2;
}