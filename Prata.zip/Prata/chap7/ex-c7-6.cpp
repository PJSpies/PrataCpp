/*
    Prata 6ed., Ch 7 , Exc-6
    array functions
*/
#include<iostream>
void show_array(const double arr[], int n);
int fill_array(double arr[], int limit);
void reverse(double arr[], int n, int off);

int main(){
    const int Max = 5;
    double arr[Max];

    int size = fill_array(arr, Max);  //  enter values, return actual size
    show_array(arr, size);  //  show array
 
    reverse(arr,size, 0);   //  reverse order in array
    show_array(arr,size);
    reverse(arr,size, 0);   //  change back to input

    reverse(arr,size, 1);   //  reverse, skip offset from begin and end
    show_array(arr,size);

return 0;
}

void show_array(const double arr[], int n)
{
    for (int i {0}; i<n; i++)
        std::cout << arr[i] << " ";
    std::cout << std::endl;
}

int fill_array(double arr[], int limit)
{
    int i {0};
    std::cout << "Enter values max " << limit << " numbers for arr:\n";
    
    while( i< limit && std::cin.good() ) 
    {
        std::cin >> arr[i];
        i++;
    }
    if (i<limit)
        i--;
    return i;
}

void reverse(double arr[], int n, int offset=0)
{
    int j = n-1-offset;
    int i = offset;
    double temp;
    while (i<n/2)
    {
        temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
        j--; i++;
    }
}