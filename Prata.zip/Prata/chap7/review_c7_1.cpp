/*  Prata 6th ed.,  Review questions  chapter 7 */
#include<iostream>
int replace(char * str, char c1, char c2);
int replace2(char str[], char c1, char c2);

int judge( int (*pf)(const char *c) );  //  Question #11

int main()
{
//  Q2 d.)
    long larr[4];   //  a long array
    long lsum(long* larr[], int sz);   // prototype for long(long) function
//  e.)
    double doc(const std::string str);
//  f.)

    struct boss
    {
        int a;
        float b;
    };
    boss b {1,2.2};
    void ofcourse(boss b);
//    void ofcourse(boss* b);
//  g.)
    struct map{
        short s;
        int i;
    };
    std::string plot(map* pmap);

    constexpr int sz = 5;
    int iarr[sz];
    void fill_arr(int iarr[], int sz, int n);

    void fill_ar(const int* b, const int* e, int n );

//    char *word = "Roggenvollkornschrotmehl";    //  not ISO C++
    char word[25] = "Roggenvollkornschrotmehl";
    std::cout << "word: " << word << "\n";
    std::cout << "replaced " << replace2(word, 'o', 'u') << " characters\n";
    std::cout << "word: " << word << "\n";

return 0;
}
//  function definitions
void fill_arr(int a[], int size, int number)
{
    for (int i=0; i<size; i++)
        a[i] = number;
}
void fill_ar( int* begin,  int* end, int number)  //  parameter nicht const!!!
{
    int* pt;
    for (pt=begin; pt != end; pt++)
        *pt = number;
}
/*  pointer-to-char notation  */
int replace(char * str, char c1, char c2)
{
    int cnt {0};
    int i=0;
    while (*str )  // str[i] !='\0'
    {
        if (*str == c1)
        {
            *str = c2;
            cnt++;
        }
        str++;
    }    
    return cnt;
}

/*  char array notation */
int replace2(char str[], char c1, char c2)
{
    int cnt {0};
    int i=0;
    while (str[i] !='\0')
    {
        if (str[i] == c1)
        {
            str[i] = c2;
            cnt++;
        }
        i++;
    }    
    return cnt;
}
