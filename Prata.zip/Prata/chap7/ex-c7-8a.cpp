/*
 * ex-c7-8a.cpp
 *
 *  Created on: 02.02.2024
 *      Author: peter
 */
/*
 * ex-c7-8.cpp
 *
 *  Created on: 02.02.2024
 *      Author: peter
 */
#include <iostream>
#include <string>
const int Seasons = 4;
const char * snames[Seasons] {"Spring", "Summer", "Autumn", "Winter"};

int fill_array(double ar[], int n);
void show_array(const double ar[], int n);

int main()
{
  double expenses[Seasons];
  int size = fill_array(expenses, Seasons);

  show_array(expenses, size);
  std::cout << "\n" << std::endl;
  return 0;
}

void show_array(const double ar[], int n)
{
	std::cout << "Data entered:\n";
    for (int i=0; i<n-1;i++)
        std::cout << snames[i] <<": "<< ar[i] <<" , " ;
    std::cout << snames[n-1] <<": "<< ar[n-1] <<"\n" ;
}

int fill_array(double arr[], int limit)
{
    int i {0};
    std::cout << "Enter values, max " << limit << " numbers for arr:\n";

    while( i< limit && std::cin.good() )
    {
        std::cout << snames[i] << ": ";
        std::cout << std::endl;
        std::cin >> arr[i];
        i++;
    }
    if (i<limit)
        i--;
    return i;
}




