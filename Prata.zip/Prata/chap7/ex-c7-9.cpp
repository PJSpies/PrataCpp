/*
 * ex-c7-9.cpp
 *
 *  Created on: 03.02.2024
 *      Author: peter
 */
#include <iostream>
const int SLEN = 30;

struct student {
  char fullname[SLEN];
  char hobby[SLEN];
  int ooplevel;
};

int getinfo(student pa[], int n);
void display1(student st);
void display2(const student* ps);
void display3(student pa[], int n);

int main()
{
  std::cout << "Enter class size: ";
  int class_size;
  std::cin >> class_size;

  while(std::cin.get() != '\n'){
	  continue;
  }
  student* ptr_stu = new student[class_size];
  int entered = getinfo(ptr_stu, class_size);
  
  std::cout << std::endl;
  for (int i=0; i<entered;i++)
	{
	  display1(ptr_stu[i]);
	  display2(&ptr_stu[i]);
	}
  std::cout<<std::endl;

  display3(ptr_stu, entered);

  delete [] ptr_stu;

  std::cout << "Prg ends.\n";

  return 0;
}

int getinfo(student pa[], int limit){
  int i {0};
  std::cout << "Enter up to " << limit << " students\n";
  while (i < limit && std::cin.good())
	{
	  std::cout << "------------------\n";
	  std::cout << "#"<< i+1<<" Full name: "; std::cin >> pa[i].fullname;
	  std::cout << "#"<< i+1<<"     Hobby: "; std::cin >> pa[i].hobby;
	  std::cout << "#"<< i+1<<"  ooplevel: ";	  std::cin >> pa[i].ooplevel;
	  i++;
	};
  if (i<limit)
	 i--;
  return i;
}
void display1(student st)
{
  std::cout << "1Name: " << st.fullname << "\thobby: " <<  st.hobby << "\tooplevel: " << st.ooplevel << "\n";
}

void display2(const student* ps)
{
  std::cout << "2Name: " << ps->fullname << "\thobby: " <<  ps->hobby << "\tooplevel: " << ps->ooplevel << "\n";
}
void display3(student pa[], int n)
{
  for (int i {0}; i<n; i++)
    std::cout << "3Name: " << pa[i].fullname << "\thobby: " <<  pa[i].hobby << "\tooplevel: " << pa[i].ooplevel << "\n";
}
