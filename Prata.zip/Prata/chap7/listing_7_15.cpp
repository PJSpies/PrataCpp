#include<iostream>
#include<array>
#include<string>

void show(const std::array<double, 4> da);
void fill(std::array<double, 4> * pa);

int main(){
    std::array<double, 4> expenses;
    expenses = {1.,2.,3.,4.};
    fill(&expenses);
    show(expenses);

return 0;
}
void show(std::array<double, 4> da)
{
    for (int i=0; i<4;i++)
        std::cout << da[i] << ", ";
    std::cout << std::endl;
}
void fill(std::array<double, 4> * pa)
{
    for (int i=0; i<4; i++)
    {
        std::cout << "enter val.# " << i+1;
        std::cin >> pa->at(i);
    }
}

