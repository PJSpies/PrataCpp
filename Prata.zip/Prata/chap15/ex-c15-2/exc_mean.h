/*
 * exc_mean.h
 *
 *  Created on: 14.06.2024
 *      Author: peter
 */

#ifndef EXC_MEAN_H_
#define EXC_MEAN_H_
//@formatter:off

#include <iostream>
#include <exception>

class bad_hmean : public std::exception
{
public:
  const char* what()  {return "bad args in hmean(): a == -b ";}
};

class bad_gmean : public std::exception
{
public:
  const char* what()  {	return "bad args in gmean()  arguments should be >= 0\n"; }
};
//@formatter:on

#endif /* EXC_MEAN_H_ */
