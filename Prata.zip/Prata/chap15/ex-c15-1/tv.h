/*
 * tv.h
 *
 *  Created on: 10.06.2024
 *      Author: peter
 */

#ifndef TV_H_
#define TV_H_

//@formatter:off
//
class Tv
{
private:
  int state;
  int volume;
  int maxchannel;
  int channel;
  int mode;
  int input;
public:
  friend class Remote;  //  Remote can access Tv private section
  enum {Off, On };
  enum {MinVal, MaxVal=20 };
  enum {Antenna, Cable };
  enum {TV, VCR };

  Tv( int s = Off, int mc=100)
	: state(s), volume(5), maxchannel(mc), channel(2), mode(Cable), input(TV) { }
  void onoff() {state = (state==On)? Off:On;}
  bool ison() const  {return state==On;}
  bool volup();
  bool voldown();
  void chanup();
  void chandown();
  void set_mode() {mode = (mode==Antenna)? Cable: Antenna;}
  void set_input() {input = (input==TV)? VCR:TV;}
  void settings() const;

};

class Remote
{
private:
  int mode;
  std::string r_state;
public:
  friend class Tv;  			//  Tv can access Remote private section (which is only 'mode')
  enum {interactive, normal};  	//  state of remote control
  Remote(int m=Tv::TV, std::string rst="normal")
	  : mode(m), r_state(rst) {}
  bool volup(Tv & t) {return t.volup();}
  bool voldown(Tv & t) {return t.voldown();}
//   toggle remote's state if TV is on.
  void toggle_state(Tv & t)
  {
//	if (t.state == 1) //  uses Tv private member 'state'.  Cannot use Tv's enum 'On'
	if (t.ison())     //  uses Tv  object's  bool function ison().
	  r_state = (r_state=="interactive" ) ? "normal" : "interactive"  ;
	else
	  std::cout << "not allowed!\n ";
  }
  void onoff(Tv & t) {t.onoff();}
  void chanup(Tv & t) {t.chanup();}
  void chandown(Tv & t) {t.chandown();}
  void set_chan(Tv & t, int c) {t.channel=c;}
  void set_mode(Tv & t) {t.set_mode();}
  void set_input(Tv & t) {t.set_input();}
  void show_mode(){std::cout << "Remote control is in " << r_state << " state.\n";}
};

//@formatter:on

#endif /* TV_H_ */
