/*
 *  exc_mean.h
 *	Prata 6th edition Ch 15  exercise 3
 *  Created on: 14.06.2024
 *  modified:  30 June 2024
 *
 *      Author: peter
 */

#ifndef EXC_MEAN_H_
#define EXC_MEAN_H_
//@formatter:off

#include <iostream>
#include <string>
#include <exception>

class bad_input : public std::logic_error
{
public:
  double v1, v2;
  bad_input(double a, double b, const std::string s="")
	: v1(a), v2(b), std::logic_error(s) {};

  virtual const std::string what()
  {
	return "**  Exception  ***";
  }
};

class bad_hmean : public bad_input
{
public:
  bad_hmean(double a, double b, const std::string &s= "")
	: bad_input(a, b, s) {}

  std::string st = "***  Exception! Bad args in hmean(): a == -b !  v1= " + std::to_string(v1) + " v2= " +std::to_string(v2);
  const std::string what()
  {
	return st;
  }
};

class bad_gmean : public bad_input
{
public:
  bad_gmean(double a, double b, const std::string &s= "")
	: bad_input(a, b, s) {}

  std::string st = "***  Exception! Bad args in gmean(): a*b <0 !  v1= " + std::to_string(v1) + " v2= " +std::to_string(v2);
  const std::string what()
  {
	return st;
  }
};


//@formatter:on

#endif /* EXC_MEAN_H_ */
