/*
 *   this was  error4.cpp
 *
 *  Created on: 30 June 2024
 *      Author: peter
 */

#include <iostream>
#include <cmath>
#include "exc_mean.h"

#include <stdexcept>

// function prototypes
double hmean(double a, double b) throw (bad_hmean);
double gmean(double a, double b) throw (bad_gmean);

int main(int argc, char **argv)
{
  using std::cout;
  using std::cin;
  using std::endl;

  double x, y;
//   test  base class:
//   throw bad_input(x, y);

  cout << "Enter two numbers: ";
  while (cin >> x >> y)
  {
	try
	{
	  cout << "The harmonic mean of " << x << " and " << y << " is " << hmean(x, y) << endl;
	  cout << "The geometric mean of " << x << " and " << y << " is " << gmean(x, y) << endl;

	  cout << "Enter next set of numbers <q to quit>: ";
	}    // end of try block
	catch (bad_input &binput)
	{
	  cout << binput.what() << endl;
	  break;
	}

  }
//  end of while

  cout << "Bye!";
  return 0;
}

double hmean(double a, double b) throw (bad_hmean)
{
  if (a == -b) throw bad_hmean(a, b);
  return 2. * a * b / (a + b);
}
double gmean(double a, double b) throw (bad_gmean)
{
  if (a < 0 || b < 0) throw bad_gmean(a, b);
//  if ((a * b) < 0) throw bad_gmean;
  return std::sqrt(a * b);
}

