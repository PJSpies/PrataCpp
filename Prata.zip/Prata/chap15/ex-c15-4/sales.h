/*
 * sales.h
 *
 *  Created on: 14.06.2024
 *      Author: peter
 */
//@formatter:off

#ifndef SALES_H_
#define SALES_H_

#include <cstring>
#include <stdexcept>

class Sales
{
public:
  static const int MONTHS = 12;
  class bad_index : public std::logic_error
  {
  private:
	int bi;    // bad index value
  public:
	explicit bad_index(int ix, const char *s = "Index error in Sales object\n");
	int bi_val() const 	{ return bi;}
  };
  explicit Sales(int yy = 0);
  Sales(int yy, const double *gr, int n);
  virtual ~Sales()   {   }
  int Year() const   {	return year;  }

#if __cplusplus < 201103L
  virtual double operator[](int i) const throw (std::logic_error);    // dynamic exception! deprecated in C++11
  virtual double& operator[](int i) throw (std::logic_error);
#else
  virtual double operator[](int i) const ;
  virtual double& operator[](int i) ;
#endif

private:
  double gross[MONTHS];
  int year;
};

class LabeledSales : public Sales
{
public:
  static const int STRLEN = 50;
  class nbad_index : public Sales::bad_index
  {
  private:
	char lbl[STRLEN];
  public:
	nbad_index(const char *lb, int ix, const char *s = "Index error in LabeledSales object\n");
	const char* label_val()	{  return lbl;	}
  };
  explicit LabeledSales(const char *lb = "none", int yy = 0);
  LabeledSales(const char *lb, int yy, const double *gr, int n);
  virtual ~LabeledSales()   {  }
  const char* Label() const   {	return label;  }

#if __cplusplus < 201103L
  virtual double operator[](int i) const throw (std::logic_error);
  virtual double& operator[](int i) throw (std::logic_error);
#else
  virtual double operator[](int i) const ;
  virtual double& operator[](int i);
#endif

private:
  char label[STRLEN];
};

#endif /* SALES_H_ */
//@formatter:on
