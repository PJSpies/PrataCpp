/*
 * use_sales.cpp
 * compile with C++11 -- uses deprecated and removed throw specification
 *  Created on: 4.7.2024
 *      Author: peter
 */
#include <iostream>
#include "sales.h"

#if __cplusplus < 201103L
#include <typeinfo>   // for typeid()
#endif

//@formatter:off

int main(int argc, char **argv)
{
  using std::cout;
  using std::cin;
  using std::endl;

  double vals1[12] = {1220, 1100, 1122, 2212, 1232, 2334, 2884, 2393, 3302, 2922, 3002, 3544};
  double vals2[12] = {12, 11, 22, 21, 32, 34, 28, 29, 33, 29, 32, 35};

  Sales sales1(2004, vals1, 12);
  LabeledSales sales2("Blogstar", 2005, vals2, 12);

  cout << "First try block:\n";
  try
  {
	cout << "Year = " << sales1.Year() << endl;
	for (int i=0; i < 12; ++i)
	{
	  cout << sales1[i] << ' ';
	  if (i % 6 == 5) cout << endl;
	}
	cout << "Year = " << sales2.Year() << endl;
	cout << "Label = " << sales2.Label() << endl;
	for (int i=0; i < 13; ++i)
	{
	  cout << sales2[i] << ' ';
	  if (i % 6 == 5) cout << endl;
	}
	cout << "End of try block #1.\n";
  }
  /*
   * How to use dynamic_cast from Sales::bad_index to daughter class LabeledSales::nbad_index
   */
  catch (Sales::bad_index &bad)
//  catch (LabeledSales::nbad_index &bad)
  {
	LabeledSales::nbad_index *pl;
	Sales::bad_index *ps = &bad;

//**	if (typeid(LabeledSales::nbad_index) == typeid(bad))  // is true and redundant. Dynamic cast evaluation is sufficient
//**	{
	  pl = dynamic_cast<LabeledSales::nbad_index*>(ps);		//  assign address of exception to pl

#if __cplusplus >= 201103L
	if ( nullptr != pl )									//  can I convert to LabeledSales? nullptr:  >C++11
#else
	if (NULL != pl)
#endif
		  cout << "Company: " << pl->label_val() << endl;		//  pl is uninitialized?
//**	}

	  cout << "bad index: " << bad.bi_val() << endl;
  }


  cout << "next try block\n";
  try
  {
	sales2[13] = 37.5;    // this triggers the throw in LabeledSales index operator
	sales1[2] = 23345;
	cout << "end of try block #2\n";
  }
  catch (Sales::bad_index &bad)
//  catch (LabeledSales::nbad_index &bad)
  {
	if (typeid(LabeledSales::nbad_index) == typeid(bad))  //  requires  #include <typeinfo>  if dialect is < C++11
	{
	  LabeledSales::nbad_index *pl;
	  Sales::bad_index *ps = &bad;
	  if ( pl = dynamic_cast<LabeledSales::nbad_index*>(ps) )  //  causes a grammar Warning. Better: see above!
		cout << "Company: " << pl->label_val() << endl;        //  access member function of exception class
	  //cout << "Company: " << bad.label_val() << endl;
	}
	cout << "bad index: " << bad.bi_val() << endl;
  }
  cout << "Done.\n";

  return 0;
}
//@formatter:on
