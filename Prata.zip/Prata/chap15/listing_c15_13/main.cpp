/*
 * main.cpp
 *
 *  Created on: 14.06.2024
 *      Author: peter
 */

#include <iostream>
#include <new>
#include <cstdlib>

using namespace std;

struct Big
{
  double stuff[20000];
};

int main(int argc, char **argv)
{
  Big *pb;
  try
  {
	cout << "Trying to get a big chunk of memory...\n";
	pb = new Big[1000000];
	cout << "got past the new request:\n";
  }
  catch (bad_alloc &ba)
  {
	cout << "Caught this exception: " << ba.what() << endl;
	exit(EXIT_FAILURE);
  }
  if (pb != 0)
  {
	pb[0].stuff[0] = 4;
	cout << pb[0].stuff[0] << endl;
  }
  else
  {
	cout << "pb is null pointer.\n";
  }
  delete[] pb;
  return 0;
}

