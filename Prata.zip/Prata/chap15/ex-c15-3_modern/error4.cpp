/*
 *   	playing with modern ways to handle exceptions
 *
 *  	Created on: 30 June 2024
 *  	modified  1 July 2024
 *      Author: peter
 */

#include <iostream>
#include <cmath>   //  sqrt()

#include <stdexcept>   //  std::logic_error

// declare function prototypes
double hmean(double a, double b);
double gmean(double a, double b);

int main(int argc, char **argv)
{
  using std::cout;
  using std::cin;
  using std::endl;

  double x, y;

  cout << "Enter two numbers: ";
  while (cin >> x >> y)
  {
	try
	{
	  cout << "The harmonic mean of " << x << " and " << y << " is " << hmean(x, y) << endl;
	  cout << "The geometric mean of " << x << " and " << y << " is " << gmean(x, y) << endl;

	  cout << "Enter next set of numbers <q to quit>: ";
	}    // end of try block
	catch (std::logic_error &le)
	{
	  cout << le.what() << endl;
	  break;
	}
	catch (...)
	{
	  cout << "*** uncaught exception! ***" << endl;
	  break;
	}

  }
//  end of while

  cout << "Bye!";
  return 0;
}

double hmean(double a, double b)
{
  if (a == -b) throw std::logic_error("** Exception: a == - b **");
  return 2. * a * b / (a + b);
}
double gmean(double a, double b)
{
  if (a < 0 || b < 0) throw std::logic_error("** Exception: a*b < 0 **");
//  if ((a * b) < 0) throw bad_gmean;
  return std::sqrt(a * b);
}

