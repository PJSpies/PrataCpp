/*
 * use_tv.cpp
 *
 *  Created on: 10.06.2024
 *      Author: peter
 */

#include <iostream>
#include "tv.h"

int main(int argc, char **argv)
{
  using std::cout;
  Tv s27;
  cout << "Initial settings for 27\" TV:\n";
  s27.settings();
  s27.onoff();
  s27.chanup();
  cout << "New settings for 27\" TV:\n";
  s27.settings();

  Remote remote;

  remote.set_chan(s27, 10);
  remote.volup(s27);
  remote.volup(s27);
  remote.set_chan(s27, 2);
  cout << "Settings for 27\" TV after using Remote control:\n";
  s27.settings();

  Tv s32(Tv::On);
  s32.set_mode();
  remote.set_chan(s32, 28);
  cout << "\n32\" settings:\n";
  s32.settings();

  return 0;
}

