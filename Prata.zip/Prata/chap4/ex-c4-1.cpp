/* 
    Prata 6th ed. chapter 4.
    Programming exercises
*/
#include<iostream>
#include<string>
#include<vector>
#include<array>

int main()
{
//  starting with exercise No.1

    std::cout << "What is your first name? ";
    std::string firstname;
    std::cin >> firstname;

    std::cout << "What is your last name? ";
    std::string lastname;
    std::cin >> lastname;

//  variant for No.3
    std::string fullname;
    fullname = lastname + ", " + firstname;  //  concatenation of string objects uses operator+
    std::cout << "Full name (reversed): " << fullname << std::endl;

//  continue exercise 1
    std::cout << "What grade do you deserve? ";
    char grade;
    std::cin >> grade;

    std::cout << "What is your age? ";
    int age;
    std::cin >> age;

    std::cout << "Name : " << lastname + ", " + firstname << "\n";
    
    std::cout << "Grade: " << char(int(grade) + 1) << "\n";
    std::cout << "Age  : " << age << "\n\n" << std::endl;

//  exercise No. 5
    struct CandyBar
    {
        std::string brandname;
        float weight;
        int calories;
    };

    CandyBar snack {"Mocha Munch", 2.3, 350};
    std::cout << "Brand: " << snack.brandname << " , weight: " << snack.weight << ",  calories: " << snack.calories << std::endl;

//  exercise No.6
    std::array<CandyBar, 3> Candies 
    {
        "Smacky", 2.5, 200, 
        "Munchy", 3.1, 400,
        "DeathByChocolate", 4.5, 500
    };

    for (int i = 0; i<3; i++)
        std::cout << Candies[i].brandname << " : " << Candies[i].weight << "oz " << Candies[i].calories << "kcal" << std::endl;
    
    

return 0;
}