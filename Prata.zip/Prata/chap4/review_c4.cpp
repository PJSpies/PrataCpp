/*  programming exercises Prata 6th ed.
 *  Chapter 4
 *  pp. 191
 */

#include<iostream>
#include<vector>
#include<array>   // C++11 
#include<string>
#include<cstring>

int main()
{
//  page 191 - No.1
    std::array<char, 30> actors;
    std::vector<short> betsie(100);
    std::vector<float> chuck(13);
    std::vector<long double> dipsea(64);

//  page 191 - No.3
    std::array<int, 5> ia5 {1,3,5,7,9};

//  page 191 - No.4
    int even = 0;
    even = ia5[0] + ia5[4];

    int even_sum =0;
    for (int j=0; j<5; j++) 
    {
        even_sum = even_sum + ia5[j];
        std::cout << " ia5["<< j <<"]: " << ia5[j] << std::endl ;
    };
    std::cout <<"even_sum: " << even_sum << std::endl;

//  page 191 - No.6 and 7
    char carray[6] {'C','h', 'e', 'e', 's', 'e'};    // not a string, just an array of chars
    const char c[7] = {'C','h', 'e', 'e', 's', 'e', '\0'};  // C-style string because of ending \0! 
    const char* cs = "Käse";      //  cstring
    std::string s {"burger"};

//  page 191 - No.8 and 9
    struct fish
    {
        std::string kind;  // species
        int weight;        // whole ounces
        float length;      // fractions of inch
    };
    fish catchoftheday {"trout", 10, 10.1};

//  page 191 - No.10
    enum Response {yes = 1, no, maybe};

//  page 191 - No.11
    double ted {2000.};
    double* pted = &ted;
    std::cout << "ted: " << *pted << std::endl;

//  page 191 - No.12
    float treacle[10] {1.,2.,3.,4.,5.,6.,7.,8.,9.,10.};   //  10 * 4B = size is 40
    float* ptreacle = &treacle[0];
    std::cout << "treacle[0]= " << *ptreacle << "   treacle[9]= " << *ptreacle+9 << std::endl;
    int sz = sizeof(treacle) / 4; 
    std::cout << "sz : " << sz << std::endl;
    std::cout << "treacle[0]= " << treacle[0] << "   treacle[9]= " << treacle[sz-1] << std::endl;  //  
    std::cout << "treacle[0]= " << *ptreacle << "   treacle[9]= " << *ptreacle+sizeof(treacle)/4-1 << std::endl;  //
    
//  page 191 - No.13
    std::cout << "Enter size:";
//...    std::cin >> sz;
    sz = 2;
    int* piarr = new int[sz];    //  dynamic sizing of an int-array: pointed to by int* 
    std::cout << "Created int array [" << sz << "] on heap.\n";
    delete piarr;
    std::cout << "deleted int array.\n";

    std::vector<int> iarr(sz);
    std::cout << "Created  vector<int> iarr(sz)\n";

//  page 192 - No.14
    std::cout << (int *) "home of ..." << std::endl;   //  0x40507f

//  page 192 - No.15
    fish* pcatch2 = new fish {"bass", 5, 5.3};
    std::cout << "Today's pointer: " << pcatch2 << " \n";  //  0x41c800 
    std::cout << "Today's catch: " << pcatch2->kind << " \n";
    std::cout << "Yesterday's catch: " << catchoftheday.kind << " \n";
    delete pcatch2;

//  page 192 - No.16    ( getline is doesn't like mixing int and char )
    std::cout << "Enter an integer (and return):";
    int i;
    std::cin >> i;   //  value into i, but <newline> remains in input queue.

// old cure    std::cin.get();  // cure:  get() the remaining character from queue.
    std::cout << "Enter string (and return):";
    char street[80]; 
// old wrong   std::cin.getline(street,80);  // ...without cure: continues to read from input queue: <newline> is the whole string!

    std::cin >> street;    //  much better!  cin into a string or char[]
    std::cout << "Entered street:" << street << std::endl;

//  page 192 - No.17
    const short size {10};
    std::vector<std::string> sobject(size);
    std::array<std::string, size> aobject;

return 0;
}