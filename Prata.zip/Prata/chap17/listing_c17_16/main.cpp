/*
 * main.cpp
 *
 *  Created on: 15 Aug. 2024, 07:07:07
 *      Author: peter
 */

#include <iostream>
#include <string>
#include <fstream>

int main(int argc, char **argv)
{
  using namespace std;
  string filename;
  cout << "Enter name for new file: ";
  cin >> filename;
  ofstream fout(filename.c_str());

  fout << "writing this text to file...\n";
  cout << "enter a number: ";
  float fnum;
  cin >> fnum;
  fout << "you gave " << fnum << " for value." << endl;
  fout.close();

  ifstream fin(filename);
//  ifstream fin(filename.c_str());
  cout << "contents of " << filename << ":\n";
  char ch;
  while (fin.get(ch))
	cout << ch;
  cout << "Done!\n";
  fin.close();

  return 0;
}

