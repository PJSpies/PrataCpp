/*
 * haupt.cpp
 *
 *  Created on: 14 Sept. 2024, 16:52:22
 *      Author: peter
 */

// get_fun.cpp -- using get() and getline()
#include <iostream>
const int Limit = 255;
int main()
{
  using std::cout;
  using std::cin;
  using std::endl;

  char input[Limit];
  cout << "Enter a string for getline() processing:\n";
  cin.getline(input, Limit, '#');
  cout << "Here is your input:\n";
  cout << input << "\nDone with phase 1\n";

  char ch;
  cin.get(ch);
  cout << "The next input character is " << ch << endl;
  if (ch != '\n') cin.ignore(Limit, '\n');
// discard rest of line

  cout << "Enter a string for get() processing:\n";
  cin.get(input, Limit, '#');
  cout << "Here is your input:\n";
  cout << input << "\nDone with phase 2\n";
  cin.get(ch);
  cout << "The next input character is " << ch << endl;

  char str[Limit];
  cout << "Enter a string for getline() processing:\n";
  cin.getline(str, Limit);
  cout << "you typed: \'" << str << "\' \nEnter a char: ";

  cin.get(ch);
  cout << "Char in buffer: \'" << ch << "\'" << std::flush;
  cin.get(ch);    // reads \n from last input.

  int i = 0;
  cout << "start typing: ";
  while ((ch = cin.peek()) != '.' && ch != '\n')
	cin.get(str[i++]);
  str[i] = '\0';
  cout << "I stored: \'" << str << "\'" << std::flush;

  return 0;
}
