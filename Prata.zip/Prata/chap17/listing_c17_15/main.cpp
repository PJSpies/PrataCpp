/*
 * main.cpp
 *
 *  Created on: 15 Aug. 2024, 06:57:38
 *      Author: peter
 */

#include <iostream>
const int SLEN = 10;
inline void eatline()
{
  while (std::cin.get() != '\n')
	continue;
}
int main(int argc, char **argv)
{
  using std::cin;
  using std::cout;
  using std::endl;

  char name[SLEN];
//  char title[SLEN];
  cout << "enter your name: ";
  cin.get(name, SLEN);
  if (cin.peek() != '\n') cout << "truncated your input to " << name << endl;
  eatline();
  return 0;
}

