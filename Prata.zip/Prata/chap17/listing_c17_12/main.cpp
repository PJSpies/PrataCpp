/*
 * main.cpp
 *
 *  Created on: 15 Aug. 2024, 06:23:48
 *      Author: peter
 */

#include <iostream>
#include <exception>

int main(int argc, char **argv)
{
  using namespace std;
  // have failbit cause an exception
  cin.exceptions(ios_base::failbit);
  cout << "enter numbers: ";
  int sum = 0;
  int input;
  try
  {
	while (cin >> input)
	{
	  sum += input;
	}
  }
  catch (ios_base::failure &bf)
  {
	cout << bf.what() << endl;
	cout << " oops !";
  }

  cout << "last value entered = " << input << endl;
  cout << "Sum = " << sum << endl;
  return 0;
}

