/*
 * main.cpp
 *
 *  Created on: 01 Sept. 2024, 15:40:46
 *      Author: peter
 */
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdlib>

const int LIM {20};

inline void eatline()
{
  while (std::cin.get() != '\n')
	continue;
}
struct Planet
{
  char name[LIM];
  double population;
  double g;
};

const char *file = "planets.dat";
int main(int argc, char **argv)
{
  using namespace std;
  Planet pl;
  cout << fixed << right;
  fstream finout;
  finout.open(file, ios_base::in | ios_base::out | ios_base::binary);

  int cnt {0};
  if (finout.is_open())
  {
	finout.seekg(0);
	cout << "current content of file " << file << '\n';
	while (finout.read((char*) &pl, sizeof pl))
	{
	  cout << cnt++ << setw(LIM) << pl.name << ": " << setprecision(0) << setw(12) << pl.population << setprecision(2) << setw(6)
		  << pl.g << endl;
	}
	if (finout.eof())
	{
	  finout.clear();
	}
	else
	{
	  cerr << "Error reading from " << file << " !\n";
	  exit(EXIT_FAILURE);
	}
  }
  else
  {
	cerr << "Could not open file " << file << " -- Bye!\n";
	exit(EXIT_FAILURE);
  }

  cout << "Enter a record number to change: ";
  long rec;
  cin >> rec;
  eatline();
  if (rec < 0 || rec >= cnt)
  {
	cerr << "Invalid record number! -- bye!";
	exit(EXIT_FAILURE);
  }
  streampos place = rec * sizeof pl;
  finout.seekg(place);
  if (finout.fail())
  {
	cerr << "Error on attempted seek! -- bye!";
	exit(EXIT_FAILURE);
  }

  finout.read((char*) &pl, sizeof pl);
  cout << "Your selection:\n";
  cout << rec << ": " << setw(LIM) << pl.name << ": " << setprecision(0) << setw(12) << pl.population << setprecision(2) << setw(6)
	  << pl.g << endl;
  if (finout.eof()) finout.clear();
  cout << "Enter planet name (empty line to quit): \n";
  cin.get(pl.name, LIM);
  eatline();
  cout << "enter population:\n";
  cin >> pl.population;
  cout << "enter accelation of gravity:\n";
  cin >> pl.g;
  finout.seekp(place);
  finout.write((char*) &pl, sizeof pl) << flush;
  if (finout.fail())
  {
	cerr << "Error on attempted write. -- Bye!";
	exit(EXIT_FAILURE);
  }
  cnt = 0;
  finout.seekg(0);
  cout << "Review content of file " << file << '\n';
  while (finout.read((char*) &pl, sizeof pl))
  {
	cout << cnt++ << ": " << setw(LIM) << pl.name << ": " << setprecision(0) << setw(12) << pl.population << setprecision(2)
		<< setw(6) << pl.g << endl;
  }
  finout.close();
  cout << "Done!\n";
  return 0;
}

